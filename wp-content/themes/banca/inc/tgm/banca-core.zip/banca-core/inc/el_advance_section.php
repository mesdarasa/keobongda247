<?php
/**
 * Elementor Advance Section
 *
 * @package Banca_Core
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * @param \Elementor\Controls_Stack $element    The element type.
 * @param string                    $section_id Section ID.
 * @param array                     $args       Section arguments.
 */

add_action( 'elementor/element/after_section_end', 'banca_el_advance_tab_control', 10, 2 );


function banca_el_advance_tab_control( $section, $section_id ) {

    if ( 'section_advanced' === $section_id || '_section_style' === $section_id ) {

        #Start Custom Settings Section
        $section->start_controls_section(
            'dark_mode_sec',
            [
                'label' => __( 'Dark Mode Color', 'hostim-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_ADVANCED,
            ]
        );

        /*$section->add_control(
            'dark_mode_text_color',
            [
                'label' => esc_html__('Text Color', 'hostim-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '.body_dark {{WRAPPER}}.elementor-widget-hostim-button .hostim-btn-wrapper .hostim-btn span' => 'color: {{VALUE}}',
                ],
            ]
        );*/

        $section->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'dark_mode_bg_color',
                'types' => ['classic', 'gradient'],
                'selector' => '
                    .body_dark {{WRAPPER}}.elementor-section, 
                    .body_dark {{WRAPPER}} .dark_mode_sec_wrap, 
                    .body_dark {{WRAPPER}}.elementor-column > .elementor-element-populated,
                    .body_dark {{WRAPPER}} >.elementor-widget-container,
                    .body_dark {{WRAPPER}} .elementor-column > .elementor-widget-container,
                    .body_dark {{WRAPPER}}.elementor-column > .elementor-widget-container .elementor-button,
                    .body_dark {{WRAPPER}} > .elementor-widget-container > .elementor-icon-wrapper > .elementor-icon
                ',
            ]
        );

        $section->add_control(
            'dark_mode_border_color',
            [
                'label' => esc_html__('Border Color', 'hostim-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '.body_dark {{WRAPPER}}> .elementor-element-populated' => 'border-color: {{VALUE}}',
                ],
                'separator' => 'before'
            ]
        );

        $section->add_control(
            'dark_mode_svg_img_color',
            [
                'label' => esc_html__('SVG (Image) Color', 'hostim-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '.body_dark {{WRAPPER}} svg path' => 'fill: {{VALUE}}',
                ],
                'separator' => 'before'
            ]
        );


        #End Custom Settings Section
        $section->end_controls_section();
    }

}