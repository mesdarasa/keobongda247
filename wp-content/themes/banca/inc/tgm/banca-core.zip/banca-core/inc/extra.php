<?php

/**
 * Add Custom Image Size
 */
add_image_size('banca_70x70', 70, 70, true); // Recent Post Sidebar



// Category array
function banca_cat_array($term = 'category') {
    $cats = get_terms(array(
        'taxonomy' => $term,
        'hide_empty' => true
    ));
    $cat_array = [];
    foreach ($cats as $cat) {
        $cat_array[$cat->slug] = $cat->name;
    }
    return $cat_array;
}

// Get Left Right arrow icons for rtl demo
function banca_core_get_arrow_icon() {
    $arrow_icon = is_rtl() ? 'left' : 'right';
    return $arrow_icon;
}


/**
 * Limit latter
 * @param $string
 * @param $limit_length
 * @param string $suffix
 */
// Limit latter
function banca_core_limit_latter($string, $limit_length, $suffix = '...') {
    if (strlen($string) > $limit_length) {
        echo strip_shortcodes(substr($string, 0, $limit_length) . $suffix);
    } else {
        echo strip_shortcodes(esc_html($string));
    }
}


/**
 * Day link to archive page
 **/
function banca_core_day_link() {
    $archive_year = get_the_time('Y');
    $archive_month = get_the_time('m');
    $archive_day = get_the_time('d');
    echo get_day_link($archive_year, $archive_month, $archive_day);
}


/**
 * Elementor Title tags
 */
function banca_el_title_tags() {
    return [
        'h1' => 'H1',
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
        'h5' => 'H5',
        'h6' => 'H6',
        'div' => 'div',
        'span' => 'span',
        'p' => 'p',
    ];
}


/**
 * Get Default Image Elementor
 * @param $settins_key
 * @param string $class
 * @param string $alt
 */
function banca_el_image($settings_key = '', $alt = '', $class = '', $data = '') {
    global $banca_opt;
    if (!empty($settings_key['id'])) {
        echo wp_get_attachment_image($settings_key['id'], 'full', '', array('class' => $class));
    } elseif (!empty($settings_key['url']) && empty($settings_key['id'])) {
        $class = !empty($class) ? "class='$class'" : '';
        echo "<img src='{$settings_key['url']}' $class alt='$alt'>";
    }
}


function banca_animate_css_classes_array() {
    $animations = array(
        'bounce' => 'bounce',
        'flash' => 'flash',
        'pulse' => 'pulse',
        'rubberBand' => 'rubberBand',
        'shake' => 'shake',
        'swing' => 'swing',
        'tada' => 'tada',
        'wobble' => 'wobble',
        'jello' => 'jello',
        'bounceIn' => 'bounceIn',
        'bounceInDown' => 'bounceInDown',
        'bounceInUp' => 'bounceInUp',
        'bounceOut' => 'bounceOut',
        'bounceOutDown' => 'bounceOutDown',
        'bounceOutLeft' => 'bounceOutLeft',
        'bounceOutRight' => 'bounceOutRight',
        'bounceOutUp' => 'bounceOutUp',
        'fadeIn' => 'fadeIn',
        'fadeInDown' => 'fadeInDown',
        'fadeInDownBig' => 'fadeInDownBig',
        'fadeInLeft' => 'fadeInLeft',
        'fadeInLeftBig' => 'fadeInLeftBig',
        'fadeInRightBig' => 'fadeInRightBig',
        'fadeInUp' => 'fadeInUp',
        'fadeInUpBig' => 'fadeInUpBig',
        'fadeOut' => 'fadeOut',
        'fadeOutDownBig' => 'fadeOutDownBig',
        'fadeOutLeft' => 'fadeOutLeft',
        'fadeOutLeftBig' => 'fadeOutLeftBig',
        'fadeOutRightBig' => 'fadeOutRightBig',
        'fadeOutUp' => 'fadeOutUp',
        'fadeOutUpBig' => 'fadeOutUpBig',
        'flip' => 'flip',
        'flipInX' => 'flipInX',
        'flipInY' => 'flipInY',
        'flipOutX' => 'flipOutX',
        'flipOutY' => 'flipOutY',
        'fadeOutDown' => 'fadeOutDown',
        'lightSpeedIn' => 'lightSpeedIn',
        'lightSpeedOut' => 'lightSpeedOut',
        'rotateIn' => 'rotateIn',
        'rotateInDownLeft' => 'rotateInDownLeft',
        'rotateInDownRight' => 'rotateInDownRight',
        'rotateInUpLeft' => 'rotateInUpLeft',
        'rotateInUpRight' => 'rotateInUpRight',
        'rotateOut' => 'rotateOut',
        'rotateOutDownLeft' => 'rotateOutDownLeft',
        'rotateOutDownRight' => 'rotateOutDownRight',
        'rotateOutUpLeft' => 'rotateOutUpLeft',
        'rotateOutUpRight' => 'rotateOutUpRight',
        'slideInUp' => 'slideInUp',
        'slideInDown' => 'slideInDown',
        'slideInLeft' => 'slideInLeft',
        'slideInRight' => 'slideInRight',
        'slideOutUp' => 'slideOutUp',
        'slideOutDown' => 'slideOutDown',
        'slideOutLeft' => 'slideOutLeft',
        'slideOutRight' => 'slideOutRight',
        'zoomIn' => 'zoomIn',
        'zoomInDown' => 'zoomInDown',
        'zoomInLeft' => 'zoomInLeft',
        'zoomInRight' => 'zoomInRight',
        'zoomInUp' => 'zoomInUp',
        'zoomOut' => 'zoomOut',
        'zoomOutDown' => 'zoomOutDown',
        'zoomOutLeft' => 'zoomOutLeft',
        'zoomOutUp' => 'zoomOutUp',
        'hinge' => 'hinge',
        'rollIn' => 'rollIn',
        'rollOut' => 'rollOut'
    );
    return $animations;
}


/**
 *
 * @param String
 * Return Publish Post
 * Posts Count
 */
function bancaCore_count_posts() {

    $count_posts = wp_count_posts('job');
    $total_posts = $count_posts->publish;
    $default_zero = esc_html__('0', 'banca');

    if ($total_posts == 0) {
        $text_post = esc_html__('No job available', 'banca');
    } elseif ($total_posts <= 9) {
        $text_post = $default_zero . $total_posts;
    } elseif ($total_posts > 9) {
        $text_post = $total_posts;
    }

    return $text_post;

}

/**
 * Banca Core RTL
 */
function banca_core_rtl() {
    $is_rtl = is_rtl() ? 'true' : 'false';
    return $is_rtl;
}


/**
 * @return float|int
 * Get Category Count
 * Total Category count posts by array
 */
function banca_get_cats_count_all($term = 'category') {

    $cats = get_terms(array(
        'taxonomy' => $term,
        'hide_empty' => true
    ));

    $cats_count = [];
    foreach ($cats as $cat) {
        $cats_count[$cat->slug] = $cat->count;
    }

    $total_cats_count = array_sum($cats_count);

    return $total_cats_count;

}



/**
 * @param $mimes
 * @return mixed
 * Support SVG Image
 */
function banca_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}

add_filter('upload_mimes', 'banca_mime_types');


/**
 * @param string $content Text content to filter.
 * @return string Filtered content containing only the allowed HTML.
 * */
if (!function_exists('banca_core_kses_post')) {
    function banca_core_kses_post($content)
    {
        $allowed_tag = array(
            'strong' => [],
            'br' => [],
            'p' => [
                'class' => [],
                'style' => [],
            ],
            'i' => [
                'class' => [],
                'style' => [],
            ],
            'ul' => [
                'class' => [],
                'style' => [],
            ],
            'li' => [
                'class' => [],
                'style' => [],
            ],
            'span' => [
                'class' => [],
                'style' => [],
            ],
            'a' => [
                'href' => [],
                'class' => [],
                'title' => []
            ],
            'div' => [
                'class' => [],
                'style' => [],
            ],
            'h1' => [
                'class' => [],
                'style' => []
            ],
            'h2' => [
                'class' => [],
                'style' => []
            ],
            'h3' => [
                'class' => [],
                'style' => []
            ],
            'h4' => [
                'class' => [],
                'style' => []
            ],
            'h5' => [
                'class' => [],
                'style' => []
            ],
            'h6' => [
                'class' => [],
                'style' => []
            ],
            'img' => [
                'class' => [],
                'style' => [],
                'height' => [],
                'width' => [],
                'src' => [],
                'srcset' => [],
                'alt' => [],
            ],

        );
        return wp_kses($content, $allowed_tag);
    }
}