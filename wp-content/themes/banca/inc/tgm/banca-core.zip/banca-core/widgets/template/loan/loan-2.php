<div class="loan-apply-widget wow fadeInRight" data-wow-delay="0.3s">
    <div class="icon">
        <?php
        echo !empty($settings['image1']['id']) ? wp_get_attachment_image($settings['image1']['id']) : '';
        echo !empty($settings['image2']['id']) ? wp_get_attachment_image($settings['image2']['id']) : '';
        ?>
    </div>
    <div class="apply-content">
        <?php
        if ( !empty($settings['title']) ) { ?>
            <span class="title"><?php echo esc_html($settings['title']) ?></span>
            <?php
        }
        if ( !empty($settings['loan_types']) ) { ?>
            <select name="select-loan-type" id="select-loan-type">
                <option><?php esc_html_e( 'Select your Loan', 'banca-core' ); ?></option>
                <?php
                foreach ( $settings['loan_types'] as $loan_type ) {
                    ?>
                    <option value="<?php echo esc_attr($loan_type['loan_type']) ?>">
                        <?php echo esc_html($loan_type['loan_type']) ?>
                    </option>
                    <?php
                }
                ?>
            </select>
            <?php
        }
        ?>
    </div>
</div>