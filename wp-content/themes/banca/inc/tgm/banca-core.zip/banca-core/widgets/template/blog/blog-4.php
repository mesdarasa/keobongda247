<div class="row gy-4">
    <?php
    $delay_time = 0.1;
    while ($posts->have_posts()) : $posts->the_post();
        ?>
        <div class="col-lg-<?php echo esc_attr($column) ?> col-md-6">
            <div class="blog-widget-1 dark_mode_sec_wrap wow fadeInUp" data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                <div class="blog-content">
                    
                    <h6>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                            <?php echo Banca_Core_Helper()->get_the_title_length($settings, 'title_length') ?>
                        </a>
                    </h6>
                    <div class="cats">
                        <i class="far fa-calendar"></i> 
                        <?php echo get_the_date() ?>
                        
                        <i class="far fa-user-circle"></i>
                        <a href="<?php echo Banca_Core_Helper()->get_the_first_taxonomy_link(); ?>">
                            <?php echo Banca_Core_Helper()->get_the_first_taxonomy(); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $delay_time = $delay_time + 0.2;
        wp_reset_postdata();
    endwhile;
    ?>
</div>

