<div class="loan-apply-widget wow fadeInRight" data-wow-delay="0.1s">
    <div class="icon">
        <?php
        echo !empty($settings['image1']['id']) ? wp_get_attachment_image($settings['image1']['id']) : '';
        echo !empty($settings['image2']['id']) ? wp_get_attachment_image($settings['image2']['id']) : '';
        ?>
    </div>
    <div class="apply-content">
        <?php
        if ( !empty($settings['title']) ) { ?>
            <span class="title"><?php echo esc_html($settings['title']) ?></span>
            <?php
        }
        if ( !empty($settings['loan_amount']) ) { ?>
            <p class="d-flex"><?php echo esc_html($settings['currency']) ?>
                <input class="w-100" type="text" value="<?php echo esc_attr($settings['loan_amount']) ?>">
            </p>
            <?php
        }
        ?>
    </div>
</div>