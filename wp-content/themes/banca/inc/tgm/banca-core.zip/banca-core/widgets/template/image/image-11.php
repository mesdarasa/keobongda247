<section class="app-showcase-area">
    <div class="app-showcase-item box-three">
        <div class="img wow fadeInRight" data-wow-delay="0.4ss">
            <?php echo wp_get_attachment_image($settings['parallax_image']['id'], 'full', ''); ?>
            <div class="app_shap_img one">
                <?php echo wp_get_attachment_image($settings['parallax_img_01']['id'], 'full', '', array( 'data-parallax' => '{"x": 0, "y": -80}')); ?>
            </div>
            <div class="app_shap_img two">
                <?php echo wp_get_attachment_image($settings['parallax_img_02']['id'], 'full', '', array('data-parallax' => '{"x": 0, "y": 50}')); ?>
            </div>
        </div>
    </div>
</section>