<section class="banner-area-3 pt-90 banca-hero dark_mode_sec_wrap">
	<div class="bg-slides">
        <?php
        if ( !empty( $settings['shape1']['id'] ) ) { ?>
            <div class="slide" data-parallax='{"x": 220, "y": 0, "rotateZ":0}'>
                <?php echo wp_get_attachment_image( $settings['shape1']['id'], 'full', false, array( 'class' => 'wow slideInRight', 'data-wow-delay' => '0.2s' ) ); ?>
            </div>
            <?php
        }
        if ( !empty( $settings['shape2']['id'] ) ) { ?>
            <div class="slide" data-parallax='{"x": 270, "y": 0, "rotateZ":0}'>
                <?php echo wp_get_attachment_image( $settings['shape2']['id'], 'full', false, array( 'class' => 'wow slideInRight', 'data-wow-delay' => '0.6s' ) ); ?>
            </div>
	        <?php
        }
        if ( !empty( $settings['shape3']['id'] ) ) { ?>
            <div class="slide" data-parallax='{"x": 330, "y": 0, "rotateZ":0}'>
                <?php echo wp_get_attachment_image( $settings['shape3']['id'], 'full', false, array( 'class' => 'wow slideInRight', 'data-wow-delay' => '1.3s' ) ); ?>
            </div>
	        <?php
        }
        ?>
	</div>
	<div class="container">
		<div class="row align-items-end">
			<div class="col-lg-7 pt-100 pt-lg-200 pb-lg-200 pb-100">
				<div class="banner-content pb-20 pt-20">
                    <?php
                    if ( !empty( $settings['title'] ) ) { ?>
                        <h1 class="__title wow fadeInUp" data-wow-delay="0.1s">
                            <?php echo esc_html($settings['title']) ?>
                        </h1>
                        <?php
                    }

                    if ( !empty($settings['buttons']) ) {
	                    foreach ( $settings['buttons'] as $button ) { ?>
                            <a <?php Banca_Core_Helper()->the_button($button['btn_url']) ?> class="wow fadeInUp mt-50 theme-btn theme-btn-rounded-2 theme-btn-lg theme-btn-alt elementor-repeater-item-<?php echo $button['_id'] ?>" data-wow-delay="0.3s">
			                    <?php echo esc_html($button['btn_label']) ?>
                                <?php \Elementor\Icons_Manager::render_icon( $button['btn_icon'] ); ?>
                            </a>
		                    <?php
	                    }
                    }
                    ?>
				</div>
			</div>
			<?php if ( !empty( $settings['f_img']['id'] ) ) : ?>
                <div class="col-lg-5 d-none d-lg-block position-relative">
                    <?php echo wp_get_attachment_image( $settings['f_img']['id'], 'full', false, array( 'class' => 'person-img' ) ); ?>
                </div>
            <?php endif; ?>
		</div>
	</div>
</section>