<?php
while ($jobs->have_posts()) : $jobs->the_post();

    $excerpt_length = !empty($settings['excerpt_length']) ? $settings['excerpt_length'] : 12;

    ?>
    <div class="feature-job-description wow fadeInUp" data-wow-delay="0.1s">
        <h6 class="job-title">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                <?php the_title() ?>
            </a>
        </h6>
        <div class="d-flex flex-wrap">
            <div class="job-location me-3"><i class="icon_pin_alt"></i>
                <?php echo Banca_Core_Helper()->get_the_first_taxonomy('job_location'); ?>
            </div>
            <div class="job-catagory">
                <span><?php echo Banca_Core_Helper()->get_the_first_taxonomy('job_cat'); ?></span>
                | <?php echo Banca_Core_Helper()->get_the_first_taxonomy('job_type'); ?>
            </div>
        </div>
        <?php echo force_balance_tags(html_entity_decode(wp_trim_words(htmlentities(wpautop(get_the_content())), $excerpt_length, ''))); ?>
        <a href="<?php the_permalink(); ?>" class="theme-btn theme-btn-lg mt-70 mb-25">
            <?php echo esc_html($settings['btn_title']) ?>
            <i class="arrow_right"></i>
        </a>
    </div>
<?php
endwhile;
wp_reset_postdata();
?>