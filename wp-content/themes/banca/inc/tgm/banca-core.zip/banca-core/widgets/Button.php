<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Group_Control_Background,
    Repeater
};


/**
 * Class Button
 * @package BancaCore\Widgets
 */
class Button extends Widget_Base
{

    public function get_name()
    {
        return 'banca_btn';
    }

    public function get_title()
    {
        return __('Button (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-button';
    }

    public function get_style_depends()
    {
        return ['banca-button'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {

        $this->start_controls_section(
            'section_btn', [
                'label' => __('Button', 'banca-core'),
            ]
        );

        $this->add_control(
            'btn_style',
            [
                'label' => __('Button Type', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'default_btn' => esc_html__('Default', 'banca-core'),
                    'hover_left2right' => esc_html__('Hover Button', 'banca-core'),
                ],
                'label_block' => true,
                'default' => 'default_btn',
            ]
        );

        $this->add_control(
            'text', [
                'label' => esc_html__('Button Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Learn More'
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => __('Link', 'banca-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __('https://your-link.com', 'banca-core'),
                'default' => [
                    'url' => '#'
                ]
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => __('Alignment', 'banca-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'banca-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'banca-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'banca-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __('Justified', 'banca-core'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'prefix_class' => 'elementor%s-align-',
                'default' => '',
            ]
        );

        $this->add_control(
            'size',
            [
                'label' => __('Size', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'sm',
                'options' => array(
                    'xs' => __('Extra Small', 'banca-core'),
                    'sm' => __('Small', 'banca-core'),
                    'md' => __('Medium', 'banca-core'),
                    'lg' => __('Large', 'banca-core'),
                    'xl' => __('Extra Large', 'banca-core'),
                ),
                'style_transfer' => true,
                'condition' => [
                    'btn_style' => 'default_btn'
                ]
            ]
        );

        $this->end_controls_section(); //End Button Title


        //============================== Button Icon ===============================//
        $this->start_controls_section(
            'btn-icon_sec', [
                'label' => __('Button Icon', 'banca-core'),
                'condition' => [
                    'btn_style' => 'default_btn'
                ]
            ]
        );

        $this->add_control(
            'btn_icon',
            [
                'label' => __('Icon', 'banca-core'),
                'type' => Controls_Manager::ICONS,
            ]
        );

        $this->add_control(
            'icon_align',
            [
                'label' => __('Icon Position', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'right',
                'options' => [
                    'left' => __('Before', 'banca-core'),
                    'right' => __('After', 'banca-core'),
                ],
            ]
        );

        //========================= Icon Indent ==================================== //
        $this->start_controls_tabs('icon_indent_tabs');

        $this->start_controls_tab(
            'icon_indent_normal_tabs', [
                'label' => __('Normal', 'banca-core'),
            ]
        );

        $this->add_control(
            'icon_normal_indent',
            [
                'label' => __('Icon Spacing', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn .elementor-align-icon-right i' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .banca-ub-btn .elementor-align-icon-left i' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_indent_hover_tabs', [
                'label' => __('Hover', 'banca-core'),
            ]
        );

        $this->add_control(
            'icon_hover_indent',
            [
                'label' => __('Icon Spacing', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn:hover .elementor-align-icon-right i' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .banca-ub-btn:hover .elementor-align-icon-left i' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs(); // End Icon indent

        $this->add_control(
            'icon_hover_animation',
            [
                'label' => __('Hover Animation', 'banca-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => banca_animate_css_classes_array(),
                'prefix_class' => 'banca-ub-btn-icon-',
                'default' => 'none',
                'separator' => 'before'
            ]
        );

        $this->end_controls_section(); // End Button Icon


        //================================= Button Effect ===============================//
        $this->start_controls_section(
            'section_btn_effects', [
                'label' => __('Button Effects', 'banca-core'),
                'condition' => [
                    'btn_style' => 'default_btn'
                ]
            ]
        );

        $this->add_responsive_control(
            'hover_animation',
            [
                'label' => __('Hover Effect', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'banca-core'),
                    'left2right' => esc_html__('Left-Right Transition', 'banca-core'),
                ],
                'separator' => 'before',
                'default' => 'none',
            ]
        );

        $this->end_controls_section(); //End Button Effect
    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        /**
         * Button Style
         */
        $this->start_controls_section(
            'style_button', [
                'label' => __('Style Button', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typography_btn',
                'selector' => '
                    {{WRAPPER}} .banca-ub-btn,
                    {{WRAPPER}} .theme-btn-2
                ',
            ]
        );

        $this->start_controls_tabs('tabs_button_style');


        //==================  Button Hover
        $this->start_controls_tab(
            'tab_button_normal', [
                'label' => __('Normal', 'banca-core'),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn' => 'fill: {{VALUE}}; color: {{VALUE}};',
                    '{{WRAPPER}} .theme-btn-2' => 'fill: {{VALUE}}; color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_color',
                'label' => __('Background Color', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '
                    {{WRAPPER}} .banca-ub-btn:not(.three_d_btn), 
                    {{WRAPPER}} .banca-ub-btn:not(.three_d_btn2),
                    {{WRAPPER}} .theme-btn-2::before
                ',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'btn_normal_box_shadow',
                'label' => __('Box Shadow', 'banca-core'),
                'selector' => '
                    {{WRAPPER}} .banca-ub-btn,
                    {{WRAPPER}} .theme-btn-2
                ',
            ]
        );

        $this->end_controls_tab();


        //==================  Button Hover
        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __('Hover', 'banca-core'),
            ]
        );

        $this->add_control(
            'hover_color',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn:not(.ub-animation-left2right):hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .banca-ub-btn:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .banca-ub-btn.ub-animation-left2right::before' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .banca-ub-btn.ub-animation-left2right:hover i' => 'color: {{VALUE}}; transition: margin 0.5s linear, color 0.6s;',
                    '{{WRAPPER}} .theme-btn-2:hover' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'button_background_hover_color',
                'label' => __('Background Color', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '
                    {{WRAPPER}} .banca-ub-btn:not(.three_d_btn):not(.three_d_btn2):not(.ub-animation-left2right):hover, 
                    {{WRAPPER}} .banca-ub-btn.three_d_btn .elementor-button-text:hover, 
                    {{WRAPPER}} .elementor-button.ub-animation-left2right::after,
                    {{WRAPPER}} .theme-btn-2:hover::before
                ',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'btn_hover_box_shadow',
                'label' => __('Box Shadow', 'banca-core'),
                'selector' => '
                    {{WRAPPER}} .banca-ub-btn:hover,
                    {{WRAPPER}} .theme-btn-2:hover
                ',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs(); // End Button Color Style


        $this->add_responsive_control(
            'text_padding',
            [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn:not(.three_d_btn)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .three_d_btn .elementor-button-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section(); // End Button Style


        /**
         * Style Button Icon
         */
        $this->start_controls_section(
            'style_button_icon', [
                'label' => __('Button Icon', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'btn_style' => 'default_btn'
                ]
            ]
        );

        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_box_size',
            [
                'label' => __('Icon Box Size', 'banca-core'),
                'description' => __('The icon box size is square. Will apply the same size on Height and Width.', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn i' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_border_radius',
            [
                'label' => __('Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_bg_color',
            [
                'label' => __('Background Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn i' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Style Border
         */
        $this->start_controls_section(
            'style_border_sec', [
                'label' => __('Border', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'btn_style' => 'default_btn'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .banca-ub-btn',
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .banca-ub-btn.three_d_btn .elementor-button-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_border_style');

        $this->start_controls_tab(
            'tab_border_normal',
            [
                'label' => __('Normal', 'banca-core'),
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .banca-ub-btn',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_border_hover',
            [
                'label' => __('Hover', 'banca-core'),
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_hover_box_shadow',
                'selector' => '{{WRAPPER}} .banca-ub-btn:hover',
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __('Border Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'border_border!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .banca-ub-btn:hover, {{WRAPPER}} .banca-ub-btn:focus' => 'border-color: {{VALUE}};',
                ],
            ]
        );


        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['hover_animation']) || empty($settings['icon_hover_animation'])) {
            wp_deregister_style('animate');
        }

        if (!empty($settings['btn_style'] == 'default_btn')) {

            $this->add_render_attribute('button', 'class', 'banca-ub-btn banca-ub-btn-normal banca-ub-btn-link elementor-button');

            if (!empty($settings['link']['url'])) {
                $this->add_link_attributes('button', $settings['link']);
                $this->add_render_attribute('button', 'class', 'elementor-button-link');
            }

            if (!empty($settings['button_css_id'])) {
                $this->add_render_attribute('button', 'id', $settings['button_css_id']);
            }

            if (!empty($settings['size'])) {
                $this->add_render_attribute('button', 'class', 'elementor-size-' . $settings['size']);
            }

            if (!empty($settings['hover_animation'])) {
                $this->add_render_attribute('button', 'class', 'ub-animation-' . $settings['hover_animation']);
                if ($settings['hover_animation'] == 'left2right') {
                    $this->add_render_attribute('');
                }
            }

            $icon_animation = !empty($settings['icon_hover_animation']) ? $settings['icon_hover_animation'] : '';

            ?>
            <a <?php echo $this->get_render_attribute_string('button') ?>>
                <?php $this->render_text(); ?>
            </a>
            <?php
        }

        //======================= Button Style 02 =============================//
        if (!empty($settings['btn_style'] == 'hover_left2right')) {

            $this->add_render_attribute('button', 'class', 'theme-btn-2 theme-btn-primary');

            if (!empty($settings['link']['url'])) {
                $this->add_link_attributes('button', $settings['link']);
                $this->add_render_attribute('button', 'class', '');
            }

            if (!empty($settings['button_css_id'])) {
                $this->add_render_attribute('button', 'id', $settings['button_css_id']);
            }

            ?>
            <a <?php echo $this->get_render_attribute_string('button') ?>>
                <?php $this->render_hover_btn(); ?>
            </a>
            <?php
        }


        if (!empty($icon_animation)) { ?>
            <script>
                jQuery(document).ready(function () {
                    jQuery('.banca-ub-btn-icon-<?php echo esc_js($icon_animation) ?> .banca-ub-btn').hover(function () {
                        jQuery('.banca-ub-btn-icon-<?php echo esc_js($icon_animation) ?> .banca-ub-btn i').css('animation', '<?php echo esc_js($icon_animation) ?> 0.9s')
                    }, function () {
                        jQuery('.banca-ub-btn-icon-<?php echo esc_js($icon_animation) ?> .banca-ub-btn i').css('animation', 'none')
                    })
                })
            </script>
            <?php
        }
    }

    /**
     * Render button text.
     *
     * Render button widget text.
     *
     * @since 1.5.0
     * @access protected
     */
    protected function render_text()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['icon_align'])) {
            $settings['icon_align'] = $this->get_settings('icon_align');
        }

        $this->add_render_attribute([
            'content-wrapper' => [
                'class' => 'elementor-button-content-wrapper',
            ],
            'icon-align' => [
                'class' => [
                    'elementor-button-icon',
                    'elementor-align-icon-' . $settings['icon_align'],
                ],
            ],
            'text' => [
                'class' => 'elementor-button-text',
            ],
        ]);

        $this->add_inline_editing_attributes('text', 'none');
        ?>

        <span <?php echo $this->get_render_attribute_string('content-wrapper'); ?>>
            <span <?php echo $this->get_render_attribute_string('icon-align'); ?>>
                <?php Icons_Manager::render_icon($settings['btn_icon'], ['aria-hidden' => 'true']); ?>
            </span>
            <span <?php echo $this->get_render_attribute_string('text'); ?>>
                <?php echo esc_html($settings['text']); ?>
            </span>
		</span>
        <?php
    }

    /**
     * Render button text.
     *
     * Render button widget text.
     *
     * @since 1.5.0
     * @access protected
     */
    protected function render_hover_btn()
    {
        $settings = $this->get_settings_for_display();

        if (empty($settings['icon_align'])) {
            $settings['icon_align'] = $this->get_settings('icon_align');
        }

        $this->add_render_attribute([
            'content-wrapper' => [
                'class' => 'elementor-button-content-wrapper',
            ],
            'icon-align' => [
                'class' => [
                    'elementor-button-icon',
                    'elementor-align-icon-' . $settings['icon_align'],
                ],
            ],
            'text' => [
                'class' => 'elementor-button-text',
            ],
        ]);

        $this->add_inline_editing_attributes('text', 'none');
        ?>
        <span class="arrow">
            <span class="horizontal-line"></span>
        </span>
        <?php echo esc_html($settings['text']); ?>
        <?php
    }

}