<section class="app-showcase-area">
    <div class="app-showcase-item">
        <div class="round wow floatingBubbles" data-wow-delay="0.3s"></div>
        <h4 class="wow fadeInUp __title" data-wow-delay="0.6s"><?php echo esc_html($settings['card_title']) ?></h4>
        <p class="wow fadeInUp __content" data-wow-delay="0.7s"><?php echo esc_html($settings['card_content']) ?></p>
        <?php echo wp_get_attachment_image($settings['card_image']['id'], 'full', '', array('class' => 'wow fadeInUp','data-wow-delay' => '0.9s' ));
        ?>
    </div>
</section>