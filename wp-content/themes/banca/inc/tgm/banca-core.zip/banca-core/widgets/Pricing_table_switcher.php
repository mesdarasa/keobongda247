<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};

/**
 * Class Image_hover
 * @package LandpagyCore\Widgets
 */
class Pricing_table_switcher extends Widget_Base {
    public function get_name() {
        return 'banca_pricing_table_switcher';
    }

    public function get_title() {
        return __( 'Pricing Table Switcher', 'banca-core' );
    }

    public function get_icon() {
        return 'eicon-price-table';
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @landpagy
     * Author: spider-themes
     */
    protected function register_controls() {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @landpagy
     * Author: spider-themes
     */
	public function elementor_content_control() {

        //===================== Select Preset ===========================//
        $this->start_controls_section(
            'style_sec', [
                'label' => esc_html__( 'Preset Skins', 'banca-core' ),
            ]
        );

        $this->add_control(
            'style', [
                'label'   => esc_html__( 'Style', 'banca-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__( '01: Pricing Switcher', 'banca-core' ),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Select Style

		//============================ Pricing Table Tab 01 ==================================//
		$this->start_controls_section(
			'pricing_table_tab1_sec', [
				'label' => esc_html__( 'Tab 01', 'banca-core' ),
                'condition' => [
                    'style' => [ '1']
                ]
			]
		);

        $this->add_control(
            'tab1_title', [
                'label'       => esc_html__( 'Title', 'banca-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => 'Monthly',
            ]
        );

		//===== Table 01
		$tab_1 = new \Elementor\Repeater();
		// $tab_1->add_control(
		// 	'table_icon', [
		// 		'label'       => esc_html__( 'Icon', 'banca-core' ),
		// 		'type'        => \Elementor\Controls_Manager::MEDIA,
		// 	]
		// );

		$tab_1->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'STARTER', 'banca-core' ),
				'label_block' => true,
			]
		);

		$tab_1->add_control(
			'subtitle', [
				'label'       => esc_html__( 'Description', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);

		$tab_1->add_control(
			'price', [
				'label'       => esc_html__( 'Price', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '$18.99',
				'label_block' => true,
			]
		);

        $tab_1->add_control(
			'price_per', [
				'label'       => esc_html__( 'Price Per M/Y', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '/month',
				'label_block' => true,
			]
		);

		$tab_1->add_control(
			'features', [
				'label'       => esc_html__( 'Feature', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);

		$tab_1->add_control(
			'btn_label', [
				'label'       => esc_html__( 'Button label', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Buy Plan', 'banca-core' ),
				'label_block' => true,
			]
		);

		$tab_1->add_control(
			'btn_url', [
				'label'   => esc_html__( 'Button URL', 'banca-core' ),
				'type'    => \Elementor\Controls_Manager::URL,
				'default' => [
					'url' => '#'
				],
			]
		);

		$this->add_control(
			'pricing_table_1', [
				'label'       => esc_html__( 'Tab 01 List', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $tab_1->get_controls(),
				'title_field' => '{{{ title }}}',
				'prevent_empty' => false,
                'condition' => [
                    'style' => '1'
                ],
                'separator' => 'before'
			]
		); //End Table Style 01

		$this->end_controls_section(); //End Pricing Table Tabs

        //=========================== Pricing Table Tab 02 =============================//
        $this->start_controls_section(
            'pricing_table_tab2_sec', [
                'label' => esc_html__( 'Tab 02', 'banca-core' ),
                'condition' => [
                    'style' => [ '1' ]
                ],
            ]
        );

        $this->add_control(
            'tab2_title', [
                'label'       => esc_html__( 'Title', 'banca-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => 'Yearly',
            ]
        );

        //====== Table Style 01
        $this->add_control(
            'pricing_table_2', [
                'label'       => esc_html__( 'Tab 02 List', 'banca-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $tab_1->get_controls(),
                'title_field' => '{{{ title }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => '1'
                ],
            ]
        );
        
        $this->end_controls_section(); //End Pricing Table Tab 02

	}

    /**
     * Name: elementor_style_control()
     * Desc: Register style content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @landpagy
     * Author: spider-themes
     */
	public function elementor_style_control () {

        //=============================== Table Contents ===================================//
        $this->start_controls_section(
            'table_content_style', [
                'label' => esc_html__( 'Table Contents', 'banca-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        // Switcher Options
        $this->add_control(
            'switcher_options', [
                'label' => esc_html__( 'Switcher', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'switcher_typo',
                'selector' => '{{WRAPPER}} .pricing_tab_btn span',
            ]
        );

        $this->add_control(
            'switcher_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing_tab_btn .toggle+span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'switcher_active_color', [
                'label' => esc_html__( 'Active Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing_tab_btn.active span' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Item Options
        $this->add_control(
            'item_options', [
                'label' => esc_html__( 'Pricing Item', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'item_margin', [
                'label' => __( 'Margin', 'landpagy-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .saas-pricing-area .price_item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_padding', [
                'label' => __( 'Padding', 'landpagy-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .saas-pricing-area .price_item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(), [
                'name' => 'item_background',
                'label' => __( 'Normal Background', 'landpagy-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .saas-pricing-area .price_item',
            ]
        );

        // Item Hover
        $this->add_control(
            'item_hover_options', [
                'label' => esc_html__( 'Pricing Item Hover', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(), [
                'name' => 'item_hover_background',
                'label' => __( 'Hover Background', 'landpagy-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .saas-pricing-area .price_item:hover',
            ]
        );

        $this->add_control(
            'all_text_hover_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .saas-pricing-area .price_item:hover .__title' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .pricing_inner .price_item:hover .price_header p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .saas-pricing-area .price_item:hover .__price' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .saas-pricing-area .price_item:hover .__price_per' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .saas-pricing-area .price_item:hover .service_list li' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Title Options
        $this->add_control(
            'title_options', [
                'label' => esc_html__( 'Title', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .__title',
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        // content Options
        $this->add_control(
            'contents_options', [
                'label' => esc_html__( 'Content', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'contents_typo',
                'selector' => '{{WRAPPER}} .__content',
            ]
        );

        $this->add_control(
            'contents_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__content' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Pricing Options
        $this->add_control(
            'pricing_options', [
                'label' => esc_html__( 'Pricing', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'pricing_typo',
                'selector' => '{{WRAPPER}} .__price',
            ]
        );

        $this->add_control(
            'pricing_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__price' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Month/Year  Options
        $this->add_control(
            'month_year_options', [
                'label' => esc_html__( 'Month/Year', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'month_year_typo',
                'selector' => '{{WRAPPER}} .__price_per',
            ]
        );

        $this->add_control(
            'month_year_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__price_per' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Features Options
        $this->add_control(
            'features_options', [
                'label' => esc_html__( 'Features', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'features_typo',
                'selector' => '{{WRAPPER}} .pricing_inner .price_item .service_list li',
            ]
        );

        $this->add_control(
            'features_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing_inner .price_item .service_list li' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Button Options
        $this->add_control(
            'button_options', [
                'label' => esc_html__( 'Button', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'btn_typo',
                'selector' => '{{WRAPPER}} .pricing_inner .price_item .price_btn',
            ]
        );

        $this->add_control(
            'btn_color', [
                'label' => esc_html__( 'Normal Color', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing_inner .price_item .price_btn' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section(); //End Section Background

	}


    /**
     * Name: elementor_render()
     * Desc: Render widget output on the frontend.
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @landpagy
     * Author: spider-themes
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        extract($settings); //Array to variable conversation

	    $tables   = isset( $pricing_table_1 ) ? $pricing_table_1 : '';
	    $tables2  = isset( $pricing_table_2 ) ? $pricing_table_2 : '';

	    //Include template parts
	    include "template/pricing_table_switcher/pricing-{$settings['style']}.php";

    }

}