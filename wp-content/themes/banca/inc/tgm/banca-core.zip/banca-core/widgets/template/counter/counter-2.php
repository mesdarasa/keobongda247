<div class="statistics-widget-2 wow fadeInUp">
    <div class="statistics-slider">
        <?php
        if (!empty($settings['counters'])) {
            foreach ($settings['counters'] as $counter) {
                ?>
                <div class="widget-content  widget-1">
                    <h1 class="stat-counter"><?php echo esc_html($counter['counter_text']) ?></h1>
                    <p><?php echo esc_html($counter['title']) ?></p>
                </div>
                <?php
            }
        }
        ?>
    </div>
</div>