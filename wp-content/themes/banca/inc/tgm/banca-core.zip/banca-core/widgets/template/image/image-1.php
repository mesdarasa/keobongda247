<section class="advisor-area banca_images_animation">
    <div class="advisor-img wow fadeInUp" data-wow-delay="0.2s">
        <div class="shape">
            <div class="box">
                <?php echo wp_get_attachment_image($settings['shape']['id'], 'full', '', array('class' => 'layer layer2', 'data-depth' => '0.5')) ?>
            </div>
            <div class="circle-shape"></div>
        </div>
        <?php banca_el_image($settings['f_image'], 'Advisor', 'main-img'); ?>
        <div class="work-time">
            <div class="circle-shape"></div>
            <?php echo !empty($settings['advisor_schedule']) ? banca_core_kses_post($settings['advisor_schedule']) : '' ?>
        </div>
    </div>
</section>