<div class="loan-slider">
    <?php
    if ( !empty($loan_sliders) ) {
        foreach ($loan_sliders as $item) {
            ?>
            <div class="single-slide">
                <div class="icon">
                    <?php echo wp_get_attachment_image($item['img']['id'], 'full' ) ?>
                </div>
                <h4 class="__title"><?php echo esc_html($item['title']) ?></h4>
                <p class="__content"><?php echo esc_html($item['content']) ?></p>
            </div>
            <?php
        }
    }
    ?>
</div>