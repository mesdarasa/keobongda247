<div class="news-area">
    <div class="news-slider pt-30" data-rtl="<?php echo esc_attr(banca_core_rtl()) ?>">
        <?php
        while ($posts->have_posts()) : $posts->the_post();
            ?>
            <div class="blog-widget-1">
                <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                <div class="blog-content">
                    <h4>
                        <a href="<?php the_permalink(); ?>">
                            <?php echo Banca_Core_Helper()->get_the_title_length($settings, 'title_length') ?>
                        </a>
                    </h4>
                    <p><?php echo Banca_Core_Helper()->get_the_excerpt_length($settings, 'excerpt_length') ?></p>
                    <a href="<?php the_permalink(); ?>" class="read-more">
                        <?php echo esc_html($settings['read_more_btn']) ?>
                        <i class="arrow_<?php echo esc_attr(banca_core_get_arrow_icon()) ?>"></i>
                    </a>
                </div>
            </div>
        <?php
        endwhile;
        wp_reset_postdata();
        ?>
    </div>
</div>