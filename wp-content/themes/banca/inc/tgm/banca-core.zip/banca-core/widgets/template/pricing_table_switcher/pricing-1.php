<section class="saas-pricing-area">
    <div class="pricing_tab_btn active text-center">
        <span><?php echo esc_html($settings['tab1_title']) ?></span>
        <span class="toggle"></span>
        <span><?php echo esc_html($settings['tab2_title']) ?></span>
    </div>
    <div class="pricing_inner">
        <div class="price_items month">
            <div class="row justify-content-center">
                <?php
                if (!empty($tables)) {
                    foreach ($tables as $index => $table) {
                        $active = $index == 1 ? ' active' : '';
                        $is_last_key = $table == end($tables) ? ' mx-auto ' : '';
                ?>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="price_item wow fadeInUp">
                                <div class="price_header">
                                    <?php
                                    if (!empty($table['title'])) { ?>
                                        <h6 class="__title"> <?php echo esc_html($table['title']) ?> </h6>
                                    <?php
                                    }

                                    if (!empty($table['subtitle'])) { ?>
                                        <p class="__content"><?php echo esc_html($table['subtitle']) ?> </p>
                                    <?php
                                    }
                                    ?>
                                </div>
                                <?php

                                if (!empty($table['price'])) { ?>
                                    <div class="price __price">
                                        <?php echo esc_html($table['price']) ?>
                                        <sub class="__price_per"><?php echo esc_html($table['price_per']) ?></sub>
                                    </div>
                                <?php
                                }

                                if (!empty($table['features'])) { ?>
                                    <?php echo ($table['features']) ?>
                                <?php
                                }
                                ?>

                                <?php

                                if (!empty($table['btn_label'])) { ?>
                                    <a <?php banca_Core_Helper()->the_button($table['btn_url']) ?> class="price_btn theme-btn theme-btn-alt">
                                        <?php echo esc_html($table['btn_label']) ?>
                                    </a>
                                <?php
                                }
                                ?>
                            </div>
                        </div>

                <?php
                    }
                }
                ?>
            </div>
        </div>
        <div class="price_items year">
            <div class="row justify-content-center">
                <?php
                foreach ($tables2 as $index => $table) {
                    $active     = $index == 1 ? ' active' : '';
                    $is_last_key = $table == end($tables) ? ' mx-auto ' : '';
                ?>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="price_item wow fadeInUp">
                            <div class="price_header">
                                <?php
                                if (!empty($table['title'])) { ?>
                                    <h6 class="__title"> <?php echo esc_html($table['title']) ?> </h6>
                                <?php
                                }

                                if (!empty($table['subtitle'])) { ?>
                                    <p class="__content"><?php echo esc_html($table['subtitle']) ?> </p>
                                <?php
                                }
                                ?>
                            </div>
                            <?php

                            if (!empty($table['price'])) { ?>
                                <div class="price __price">
                                    <?php echo esc_html($table['price']) ?>
                                    <sub class="__price_per"><?php echo esc_html($table['price_per']) ?></sub>
                                </div>
                            <?php
                            }

                            if (!empty($table['features'])) { ?>
                                <?php echo ($table['features']) ?>
                            <?php
                            }
                            ?>

                            <?php
                            if (!empty($table['btn_label'])) { ?>
                                <a <?php banca_Core_Helper()->the_button($table['btn_url']) ?> class="price_btn theme-btn theme-btn-alt">
                                    <?php echo esc_html($table['btn_label']) ?>
                                </a>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</section>