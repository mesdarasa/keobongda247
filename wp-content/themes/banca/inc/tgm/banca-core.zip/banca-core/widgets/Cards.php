<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Group_Control_Background,
    Repeater
};


/**
 * Class Cards
 * @package BancaCore\Widgets
 */
class Cards extends Widget_Base {

    public function get_name()
    {
        return 'banca_cards';
    }

    public function get_title()
    {
        return __('Cards (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-carousel';
    }

    public function get_style_depends()
    {
        return ['slick', 'slick-theme'];
    }

    public function get_script_depends()
    {
        return ['slick'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {


        //========================== Select Style ==========================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'plugin-domain'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('01: Carousel', 'plugin-domain'),
                    '2' => __('02: Card Grid', 'plugin-domain'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Style


        //============================= Cards Style 01 ================================//
        $this->start_controls_section(
            'cards_sec', [
                'label' => __('Cards', 'banca-core'),
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'style', array(
                'label' => __('Select Design', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
                    '1' => __('Style 01', 'banca-core'),
                    '2' => __('Style 02', 'banca-core'),
                    '3' => __('Style 03', 'banca-core'),
                ),
                'default' => '1',
            )
        );

        $repeater->add_control(
            'icon', [
                'label' => __('Icon', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Bank account'
            ]
        );

        $repeater->add_control(
            'content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'separator' => 'after',
            ]
        );

        //===============Shape Images
        $repeater->add_control(
            'shape1', [
                'label' => __('Shape 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape2', [
                'label' => __('Shape 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape3', [
                'label' => __('Shape 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape4', [
                'label' => __('Shape 04', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape5', [
                'label' => __('Shape 05', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => '3'
                ]
            ]
        );

        $repeater->add_control(
            'shape6', [
                'label' => __('Shape 06', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => '3'
                ]
            ]
        );

        $repeater->add_control(
            'shape7', [
                'label' => __('Shape 07', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => '3'
                ]
            ]
        );

        //=== Style
        $repeater->add_responsive_control(
            'item_padding', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before'
            ]
        );

        $repeater->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'bg_color',
                'label' => esc_html__('Background', 'plugin-name'),
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
            ]
        );


        $this->add_control(
            'cards', [
                'label' => __('Add Card', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
                'prevent_empty' => false
            ]
        );

        $this->end_controls_section(); // End Card Style 01


        //============================= Cards Style 02 ================================//
        $this->start_controls_section(
            'cards2_sec', [
                'label' => __('Cards', 'banca-core'),
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'style', [
                'label' => __('Select Design', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('Style 01', 'banca-core'),
                    '2' => __('Style 02', 'banca-core'),
                    '3' => __('Style 03', 'banca-core'),
                ],
                'default' => '1',
            ]
        );

        $repeater->add_control(
            'icon', [
                'label' => __('Icon', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Bank account'
            ]
        );

        $repeater->add_control(
            'content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'separator' => 'after',
            ]
        );

        //===============Shape Images
        $repeater->add_control(
            'shape1', [
                'label' => __('Shape 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape2', [
                'label' => __('Shape 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape3', [
                'label' => __('Shape 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape4', [
                'label' => __('Shape 04', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape5', [
                'label' => __('Shape 05', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'shape6', [
                'label' => __('Shape 06', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['1', '2']
                ]
            ]
        );

        $repeater->add_responsive_control(
            'item_padding', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before'
            ]
        );

        $repeater->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'bg_color',
                'label' => esc_html__('Background', 'plugin-name'),
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
            ]
        );

        $this->add_control(
            'cards2', [
                'label' => __('Add Card', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
                'prevent_empty' => false
            ]
        );

        $this->end_controls_section(); //End Card Style 02

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control() {


        //============================ Title =================================//
        $this->start_controls_section(
            'sec_title_style', [
                'label' => __('Title', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .title',
            ]
        );

        $this->end_controls_section(); // End title


        //============================ Style Contents =============================//
        $this->start_controls_section(
            'style_contents', [
                'label' => __('Contents', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['1']
                ]
            ]
        );

        $this->add_control(
            'contents_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__content' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'contents_typo',
                'selector' => '{{WRAPPER}} .__content',
            ]
        );

        $this->end_controls_section(); // End subtitle

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        extract($settings); // Array to Variable Conversation


        //========== Include Parts
        include "template/cards/card-{$settings['style']}.php";
    }

}