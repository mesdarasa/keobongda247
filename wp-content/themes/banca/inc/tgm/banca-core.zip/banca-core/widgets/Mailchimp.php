<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Mailchimp
 * @package BancaCore\Widgets
 */
class Mailchimp extends Widget_Base
{
    public function get_name()
    {
        return 'banca_mailchimp';
    }

    public function get_title()
    {
        return __('Mailchimp Form (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-mailchimp';
    }

    public function get_script_depends()
    {
        return ['ajax-chimp'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    public function get_keywords()
    {
        return ['Subscriber', 'Mailchimp', 'Form'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {
        //============================ Style ===========================//

        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('01: Style', 'banca-core'),
                    '2' => __('02: Style', 'banca-core'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Style

        // ------------------------------ Title Section ------------------------------
        $this->start_controls_section(
            'title_sec', [
                'label' => __('Title', 'banca-core'),
            ]
        );

        $this->add_control(
            'upper_title', [
                'label' => esc_html__('Upper Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Want to know about our offers first?',
            ]
        );

        $this->add_control(
            'title', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Subscribe our newsletter',
                'separator' => 'before'
            ]
        );

        $this->end_controls_section(); //End Title Area


        // ------------------------------ MailChimp form ------------------------------
        $this->start_controls_section(
            'form_settings', [
                'label' => __('Form settings', 'banca-core'),
            ]
        );

        $this->add_control(
            'email_placeholder', [
                'label' => esc_html__('Email Placeholder', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Email',
            ]
        );

        $this->add_control(
            'action_url', [
                'label' => esc_html__('Action URL', 'banca-core'),
                'description' => __('Enter here your MailChimp action URL. <a href="#" target="_blank"> How to </a>', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'btn_label', [
                'label' => esc_html__('Submit Button', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Subscribe',
            ]
        );

        $this->end_controls_section(); // End Mailchimp Form Action


        //====================== Floating Object Images ===================== //
        $this->start_controls_section(
            'floating_obj_images', [
                'label' => __('Floating Object Images', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => [ '1' ]
                ]
            ]
        );

        $this->add_control(
            'floating_obj1', [
                'label' => esc_html__('Object 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'floating_obj2', [
                'label' => esc_html__('Object 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'floating_obj3', [
                'label' => esc_html__('Object 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'floating_obj4', [
                'label' => esc_html__('Object 04', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'floating_obj5', [
                'label' => esc_html__('Object 05', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'floating_obj6', [
                'label' => esc_html__('Object 06', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section(); // End Floating Object

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        //============================ Style Mailchimp =============================//
        $this->start_controls_section(
            'mailchimp_style', [
                'label' => esc_html__('Content', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //==============  Sub Title
        $this->add_control(
            'mailchipm_sub_title', [
                'label' => esc_html__('Sub Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'sub_title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .cta-content h5' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'sub_title_typo',
                'selector' => '{{WRAPPER}} .cta-3 .cta-content h5',
            ]
        );


        //============== Title
        $this->add_control(
            'mailchipm_title', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-content.text-black h2' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .cta-content.text-black h2',
            ]
        );

        // Input Style

        $this->add_control(
            'mailchipm_input', [
                'label' => esc_html__('Input', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'input_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .form-control' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'input_typo',
                'selector' => '{{WRAPPER}} .cta-3 .form-control',
            ]
        );

        $this->add_control(
            'input_padding',
            [
                'label' => __('Padding', 'plugin-domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .form-control' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'input_border_radius',
            [
                'label' => __('Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .form-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'input_background', [
                'label' => esc_html__('Background', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .form-control' => 'background: {{VALUE}};',
                ]
            ]
        );

        //============== Button Box
        $this->add_control(
            'mailchipm_button_box', [
                'label' => esc_html__('Box', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'button_box_padding',
            [
                'label' => __('Padding', 'plugin-domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .form-control' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_box_border',
                'label' => __('Border', 'plugin-domain'),
                'selector' => '{{WRAPPER}} .cta-3 .form-control',
            ]
        );

        //============== Button
        $this->add_control(
            'mailchipm_button', [
                'label' => esc_html__('Button', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'button_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .cta-content .theme-btn' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'button_typo',
                'selector' => '{{WRAPPER}} .cta-3 .cta-content .theme-btn',
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label' => __('Padding', 'plugin-domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .cta-content .theme-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .cta4.cta-3 .cta-content .theme-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_background', [
                'label' => esc_html__('Background', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-3 .cta-content .theme-btn' => 'background: {{VALUE}};',
                ]
            ]
        );

        $this->end_controls_section(); // End Mailchimp section

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        //================= Include Parts
        include "template/mailchimp/mailchimp-{$settings['style']}.php";
    }
}