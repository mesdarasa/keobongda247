<div class="bank-card-img">
    <div class="bank-card wow fadeInUp" data-wow-delay="0.8s">
        <?php echo wp_get_attachment_image( $settings['parallax_1']['id'], 'full', '', array( 'data-parallax' => '{"x": 0, "y": 90}')) ?>
    </div>
    <div class="bank-card wow fadeInUp" data-wow-delay="0.5s">
        <?php echo wp_get_attachment_image( $settings['parallax_2']['id'], 'full', '', array( 'data-parallax' => '{"x": 0, "y": 50}')) ?>
    </div>
    <div class="bank-card wow fadeInUp" data-wow-delay="0.3s">
        <?php echo wp_get_attachment_image( $settings['parallax_3']['id'], 'full', '') ?>
    </div>
    <?php echo wp_get_attachment_image( $settings['parallax_shape_1']['id'], 'full', '',  array( 'class' => 'shap one' )) ?>
    <?php echo wp_get_attachment_image( $settings['parallax_shape_2']['id'], 'full', '', array( 'data-parallax' => '{"x": 0, "y": 50, "rotateZ": 305}', 'class' => 'shap two')) ?>
    <?php echo wp_get_attachment_image( $settings['parallax_shape_3']['id'], 'full', '', array( 'data-parallax' => '{"x": 0, "y": 0, "rotateZ": 305}', 'class' => 'shap three')) ?>
    <?php echo wp_get_attachment_image( $settings['parallax_shape_4']['id'], 'full', '', array( 'data-parallax' => '{"x": 20, "y": 0, "rotateZ": 305}', 'class' => 'shap four')) ?>
</div>