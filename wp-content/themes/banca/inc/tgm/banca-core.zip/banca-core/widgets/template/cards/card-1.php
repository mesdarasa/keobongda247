<div class="feature-slider" data-rtl="<?php echo esc_attr(banca_core_rtl()) ?>">
    <?php
    $delay_time = 0.1;
    $i = 1;
    if (!empty($settings['cards'])) {
        foreach ($settings['cards'] as $card) {
            ?>
            <div class="feature-card-widget-3 wow fadeInLeft card-<?php echo esc_attr($card['style']) ?> elementor-repeater-item-<?php echo $card['_id'] ?>"
                 data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                <div class="shapes">
                    <?php
                    banca_el_image($card['shape1'], 'shape');
                    banca_el_image($card['shape2'], 'shape');
                    banca_el_image($card['shape3'], 'shape');
                    banca_el_image($card['shape4'], 'shape');
                    banca_el_image($card['shape5'], 'shape');
                    banca_el_image($card['shape6'], 'shape');
                    banca_el_image($card['shape7'], 'shape');
                    ?>
                </div>
                <?php
                banca_el_image($card['icon'], 'icon');
                if (!empty($card['title'])) { ?>
                    <span class="title"><?php echo esc_html($card['title']) ?></span>
                    <?php
                }
                if (!empty($card['content'])) { ?>
                    <h5 class="__content"><?php echo banca_core_kses_post(nl2br($card['content'])) ?></h5>
                    <?php
                }
                ?>
            </div>
            <?php
            $i = ++$i;
            $delay_time = $delay_time + 0.2;
        }
    }
    ?>
</div>