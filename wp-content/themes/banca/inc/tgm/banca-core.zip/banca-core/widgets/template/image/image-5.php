<div class="track-f-progress">
    <div class="img-content">
        <?php
        $data_wow_delay = 0.1;
        if ( $settings['card_images'] ) {
            foreach ( $settings['card_images'] as $index => $image ) {

                switch ($index) {
                    case 0:
                        $align_class = 'bg-img';
                        break;
                    case 1:
                        $align_class = 'track-3 wow fadeInUp';
                        break;
                    case 2:
                        $align_class = 'track-img track-1 wow fadeInRight';
                        break;
                    case 3:
                        $align_class = 'track-img track-2 wow fadeInRight';
                        break;
                    default:
                        $align_class = 'bg-img';
                }

                echo wp_get_attachment_image( $image['image']['id'], 'full', '', array( 'class' => $align_class . ' elementor-repeater-item-'.$image['_id'], 'data-wow-delay' => $data_wow_delay.'s'));

                $data_wow_delay = $data_wow_delay + 0.2;
            }
        }
        ?>
    </div>
</div>