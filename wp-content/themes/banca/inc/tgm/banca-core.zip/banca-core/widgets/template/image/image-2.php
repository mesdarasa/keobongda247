<div class="banner-area-4 banca_images_animation2">
	<div class="hero-img wow fadeInRight">
		<?php
		 if ( !empty($settings['shape_images']) ) {
		    foreach ( $settings['shape_images'] as $shape_image ) {
		        $x_number   = isset( $shape_image['x_number'] ) ? $shape_image['x_number'] : 10;
		        $y_number   = isset( $shape_image['y_number'] ) ? $shape_image['y_number'] : 10;
		        $z_rotate   = isset( $shape_image['z_rotate'] ) ? $shape_image['z_rotate'] : 0;
                $class      = !empty( $shape_image['is_class_layer'] == 'yes' ) ? 'layer' : 'none';
                $data_depth = !empty( $shape_image['data_depth'] ) ? $shape_image['data_depth'] : '-0.06'
		        ?>
			    <div class="shape" data-parallax='{"x": <?php echo esc_attr($x_number) ?>, "y": <?php echo esc_attr($y_number) ?>, "rotateZ":<?php echo esc_attr($z_rotate) ?>}'>
				    <?php echo wp_get_attachment_image( $shape_image['shape_image']['id'], 'full', '', array( 'data-depth' => $data_depth, 'class' => esc_attr($class) ))  ?>
			    </div>
				<?php
		    }
		 }
		 echo wp_get_attachment_image( $settings['f_image']['id'], 'full', '', array( 'data-parallax' => '{"x": 50, "y": -50, "rotateZ":0}', 'class' => 'person-img' ))
		 ?>
	</div>
</div>