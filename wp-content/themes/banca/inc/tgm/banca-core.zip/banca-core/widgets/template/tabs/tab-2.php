<section class="about-tab-area overflow-hidden">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <?php
        foreach ($tabs2 as $index => $item) {
            $tab_count = $index + 1;
            $active = $tab_count == 1 ? ' active' : '';
            $tab_title_setting_key = $this->get_repeater_setting_key('tab_title', 'tabs', $index);
            $this->add_render_attribute($tab_title_setting_key, [
                'class' => ['nav-link', $active],
                'id' => 'freelancer-tab' . $id_int . $tab_count,
                'data-bs-toggle' => 'tab',
                'data-bs-target' => '#freelancer' . $id_int . $tab_count,
                'type' => 'button',
                'role' => 'tab',
                'aria-controls' => 'freelancer' . $id_int . $tab_count,
                'aria-selected' => $tab_count == 1 ? 'false' : 'true',
            ]);
            ?>
            <li class="nav-item" role="presentation">
                <button <?php echo $this->get_render_attribute_string($tab_title_setting_key); ?>>
                    <?php echo esc_html($item['tab_title']) ?>
                </button>
            </li>
            <?php
        }
        ?>
    </ul>
    <div class="tab-content" id="myTabContent">
        <?php
        foreach ($tabs2 as $index => $item) {
            $tab_count = $index + 1;
            $active_show = $tab_count == 1 ? ' show active' : '';
            $tab_content_setting_key = $this->get_repeater_setting_key('tab_content', 'tabs', $index);
            $this->add_render_attribute($tab_content_setting_key, [
                'class' => 'tab-pane fade' . $active_show,
                'id' => 'freelancer' . $id_int . $tab_count,
                'role' => 'tabpanel',
                'aria-labelledby' => 'freelancer-tab' . $id_int . $tab_count,
            ]);
            ?>
            <div <?php echo $this->get_render_attribute_string($tab_content_setting_key); ?>>
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="section-title text-start">
                            <?php
                            if (!empty($item['title'])) { ?>
                                <h1><?php echo Banca_Core_Helper()->kses_post($item['title']) ?></h1>
                                <?php
                            }
                            if (!empty($item['content'])) { ?>
                                <p><?php echo esc_html($item['content']) ?></p>
                                <?php
                            }
                            if (!empty($item['btn_label'])) { ?>
                                <a <?php echo Banca_Core_Helper()->the_button($item['btn_url']) ?>
                                        class="read-more">
                                    <?php echo esc_html($item['btn_label']) ?>
                                    <i class="arrow_right"></i>
                                </a>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <?php echo wp_get_attachment_image($item['image']['id'], 'full', '', ['class' => 'img-fluid']) ?>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</section>