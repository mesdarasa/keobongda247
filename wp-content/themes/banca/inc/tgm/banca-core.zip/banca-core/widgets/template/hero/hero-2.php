<section class="banner-area-2 pt-200 pb-95 banca-hero hero_animation1 dark_mode_sec_wrap">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-6">
				<div class="banner-content">
                    <?php
                    echo wp_get_attachment_image( $settings['shape1']['id'], 'full',false, array( 'data-parallax' => '{"x": 0, "y": 250, "rotateZ":0}', 'class' => 'shape' ));
                    echo !empty($settings['title']) ? '<h1 class="__title wow fadeInUp mb-0">'. esc_html($settings['title']) .'</h1>' : '';
                    echo !empty($settings['subtitle']) ? '<p class="__subtitle wow fadeInUp mt-50">'. esc_html($settings['subtitle']) .'</p>' : '';

                    if ( !empty($settings['buttons']) ) {
	                    foreach ( $settings['buttons'] as $button ) { ?>
                            <a <?php Banca_Core_Helper()->the_button($button['btn_url']) ?> data-wow-delay="0.5s" class="wow fadeInUp theme-btn theme-btn-lg mt-50 elementor-repeater-item-<?php echo $button['_id'] ?>">
			                    <?php echo esc_html($button['btn_label']) ?>
			                    <?php \Elementor\Icons_Manager::render_icon( $button['btn_icon'] ); ?>
                            </a>
		                    <?php
	                    }
                    }
                    ?>
				</div>
			</div>
            <div class=" col-md-6 col-lg-5 offset-lg-1 pt-40">
                <div class="banner-img">
	                <?php banca_el_image($settings['f_img'], 'banner-img', 'main-img img-fluid wow fadeInRight' ); ?>
                    <div class="shapes">
                        <?php
                        echo wp_get_attachment_image( $settings['shape2']['id'], 'full',false, array( 'data-parallax' => '{"x": 0, "y": 130, "rotateZ":0}', 'class' => 'shape-1' ));
                        echo wp_get_attachment_image( $settings['shape3']['id'], 'full',false, array( 'data-parallax' => '{"x": 0, "y": -130, "rotateZ":0}', 'class' => 'shape-2' ));
                        echo wp_get_attachment_image( $settings['shape4']['id'], 'full',false, array( 'data-parallax' => '{"x": 250, "y":0, "rotateZ":0}', 'class' => 'shape-3' ));
                        echo wp_get_attachment_image( $settings['shape5']['id'], 'full',false, array( 'data-parallax' => '{"x": -200, "y": 250, "rotateZ":0}', 'class' => 'shape-4' ));
                        echo wp_get_attachment_image( $settings['shape6']['id'], 'full',false, array( 'class' => 'shape-5' ));
                        echo wp_get_attachment_image( $settings['shape7']['id'], 'full',false, array( 'class' => 'shape-6' ));
                        ?>
                    </div>
                </div>
            </div>
		</div>
	</div>
</section>