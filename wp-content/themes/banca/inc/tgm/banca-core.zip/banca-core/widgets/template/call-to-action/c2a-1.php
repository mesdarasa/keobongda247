<div class="cta cta-bg-primary banca_sec">
    <div class="shapes">
        <?php
        banca_el_image($settings['shape1'], 'shape');
        echo wp_get_attachment_image($settings['shape2']['id'], 'full', false, array( 'data-parallax' => '{"x": 150, "y": 0, "rotateZ":-0}' ));
        banca_el_image($settings['shape3'], 'shape');
        banca_el_image($settings['shape4'], 'shape');
        banca_el_image($settings['shape5'], 'shape');
        echo wp_get_attachment_image($settings['shape6']['id'], 'full', false, array( 'data-parallax' => '{"x": 400, "y": 0, "rotateZ":0}' ));
        ?>
    </div>
    <div class="row align-items-center">
        <div class="col-md-7">
            <div class="cta-content wow fadeInRight">
                <?php
                if ( !empty($settings['title']) ) { ?>
                    <h2 class="mb-10"><?php echo esc_html($settings['title'])  ?></h2>
                    <?php
                }
                if ( !empty($settings['subtitle']) ) { ?>
                    <p><?php echo esc_html($settings['subtitle']) ?></p>
                    <?php
                }
                ?>

            </div>
        </div>
        <?php if ( !empty($settings['btn_title']) ) : ?>
            <div class="col-md-5 text-center text-md-end">
                <div class="cta-content   text-md-end mt-3 mt-md-0">
                    <a <?php Banca_Core_Helper()->the_button($settings['btn_url']) ?> class="theme-btn theme-btn-alt wow fadeInLeft m-0">
                        <?php echo esc_html($settings['btn_title']) ?>
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>