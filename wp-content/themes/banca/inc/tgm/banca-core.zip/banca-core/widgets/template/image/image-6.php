<div class="card-payment">
    <div class="img-content">
        <?php
        $data_wow_delay = 0.1;
        if ( $settings['card_images'] ) {
            foreach ( $settings['card_images'] as $index => $image ) {

                switch ($index) {
                    case 0:
                        $align_class = 'bg-img';
                        break;
                    case 1:
                        $align_class = 'card-1 img-fluid wow fadeInLeft';
                        break;
                    case 2:
                        $align_class = 'card-2 wow fadeInLeft';
                        break;
                    default:
                        $align_class = 'bg-img';
                }

                echo wp_get_attachment_image( $image['image']['id'], 'full', '', array( 'class' => $align_class . ' elementor-repeater-item-'.$image['_id'], 'data-wow-delay' => $data_wow_delay.'s'));

                $data_wow_delay = $data_wow_delay + 0.1;
            }
        }
        ?>
    </div>
</div>