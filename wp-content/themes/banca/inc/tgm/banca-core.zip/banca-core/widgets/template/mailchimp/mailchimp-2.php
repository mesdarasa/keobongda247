<section class="cta4 cta-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="cta-content text-black wow fadeInLeft">
                    <form action="javascript:void(0)" class="mailchimp" data-action-url="<?php echo esc_url($settings['action_url']); ?>" method="post">
                        <div class="input-group">
                            <input type="email" class="form-control memail" name="EMAIL" placeholder="<?php echo esc_attr($settings['email_placeholder']) ?>">
                            <button type="submit" class="input-append theme-btn theme-btn-lg">
                                <?php echo esc_html($settings['btn_label']); ?>
                            </button>
                        </div>
                        <p class="mchimp-errmessage text-center mt-3" style="display: none;"></p>
                        <p class="mchimp-sucmessage text-center mt-3" style="display: none;"></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>