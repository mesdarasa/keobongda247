<section class="customize-card-area banca_images_animation3">
    <div class="row">
        <div class="card-img">
            <?php
            echo wp_get_attachment_image($settings['shape']['id'], 'full', '', array( 'class' => 'img-fluid' ));
            if ( !empty($settings['card_images']) ) {
                $data_delay = 1.0;
                $data_depth = 0.2;
                foreach ( $settings['card_images'] as $index => $card_image ) {
                    switch ($index) {
                        case 0:
                            $align_class = '1';
                            break;
                        case 1:
                            $align_class = '2';
                            break;
                        case 2:
                            $align_class = '3';
                            break;
                        default:
                            $align_class = '1';
                    }
                    ?>
                    <div class="shape-<?php echo esc_attr($align_class) ?>">
                        <?php echo wp_get_attachment_image($card_image['image']['id'], 'full', '',
                            array(
                                'class' => 'layer wow rotateInUpRight',
                                'data-wow-delay' => $data_delay.'s',
                                'data-depth' => $data_depth
                            ));
                        ?>
                    </div>
                    <?php
                    $data_delay = $data_delay + 0.2;
                    $data_depth = $data_depth + 0.2;
                }
            }
            ?>
        </div>
    </div>
</section>