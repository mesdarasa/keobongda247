<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Image
 * @package BancaCore\Widgets
 */
class Image extends Widget_Base
{

    public function get_name()
    {
        return 'banca_images';
    }

    public function get_title()
    {
        return __('Images (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-featured-image';
    }

    public function get_script_depends()
    {
        return ['parallax-scroll', 'parallax',];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {


        //============================ Select Style ===========================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Preset Skin', 'banca-core'),
            ]
        );


        $this->add_control(
            'style', [
                'label' => esc_html__('Skins', 'banca-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    '1' => [
                        'title' => __('01 : Image with Schedule Time', 'banca-core'),
                        'icon' => 'image1',
                    ],
                    '2' => [
                        'title' => __('02 : Multiple Parallax Image', 'banca-core'),
                        'icon' => 'image2',
                    ],
                    '3' => [

                        'title' => __('03 : Image with Logo', 'banca-core'),
                        'icon' => 'image3',
                    ],
                    '4' => [
                        'title' => __('04 : Multiple Parallax Image', 'banca-core'),
                        'icon' => 'image4',
                    ],
                    '5' => [
                        'title' => __('05 : Multiple Images', 'banca-core'),
                        'icon' => 'image5',
                    ],
                    '6' => [
                        'title' => __('06 : Multiple Images', 'banca-core'),
                        'icon' => 'image6',
                    ],
                    '7' => [
                        'title' => __('07 : Multiple Images', 'banca-core'),
                        'icon' => 'image7',
                    ],
                    '8' => [
                        'title' => __('08 : Multiple Images', 'banca-core'),
                        'icon' => 'image8',
                    ],
                    '9' => [
                        'title' => __('09 : Multiple Images Map', 'banca-core'),
                        'icon' => 'image9',
                    ],
                    '10' => [
                        'title' => __('10 : Image Card', 'banca-core'),
                        'icon' => 'image10',
                    ],
                    '11' => [
                        'title' => __('11 : Multiple Image Parallax', 'banca-core'),
                        'icon' => 'image11',
                    ],
                ],
                'default' => '1'
            ]
        );

        $this->end_controls_section();


        //============================ Images Area ===========================//
        $this->start_controls_section(
            'images_sec', [
                'label' => __('Images', 'banca-core'),
            ]
        );

        $this->add_control(
            'advisor_schedule', [
                'label' => __('Advisor Schedule', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'All weekdays <span>10.00 - 18.00</span>',
                'condition' => [
                    'style' => '1',
                ]
            ]
        );

        $this->add_control(
            'f_image', [
                'label' => __('Featured Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['1', '2', '3'],
                    'style!' => ['4', '5', '6', '7']
                ]
            ]
        );

        //===================== Start Card Images ======================//
        $repeater = new Repeater();
        $repeater->add_control(
            'align_items', [
                'type' => Controls_Manager::HIDDEN,
            ]
        );

        $repeater->add_control(
            'image', [
                'label' => __('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_responsive_control(
            'max_width',
            [
                'label' => __('Max-Width', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'unit' => '%',
                ],
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'width',
            [
                'label' => __('Width', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'unit' => '%',
                ],
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'height',
            [
                'label' => __('Height', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'unit' => '%',
                ],
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_control(
            'position_style', [
                'label' => esc_html__('Image Position', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $repeater->add_responsive_control(
            'horizontal_position',
            [
                'label' => __('Horizontal', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'unit' => '%',
                ],
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $repeater->add_responsive_control(
            'vertical_position',
            [
                'label' => __('Vertical', 'banca-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'unit' => '%',
                ],
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'card_images', [
                'label' => __('Add Image', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ align_items }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => ['4', '5', '6', '7']
                ]
            ]
        ); //End Card Images


        $this->add_control(
            'shape', [
                'label' => __('Shape Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['1', '3', '4'],
                    'style!' => ['5', '6', '7']
                ]
            ]
        );

        $this->end_controls_section(); //End Featured Images


        //============================ Clients style 03 =================================//
        $this->start_controls_section(
            'clients_logo_sec', [
                'label' => __('Clients Logo', 'banca-core'),
                'condition' => [
                    'style' => '3'
                ]
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'align_items', [
                'type' => Controls_Manager::HIDDEN,
            ]
        );

        $repeater->add_control(
            'logo', [
                'label' => __('Logo', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'clients_logo', [
                'label' => __('Add Image', 'plugin-domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ align_items }}}',
            ]
        );

        $this->end_controls_section(); // End Clients Logo Style 03


        //============================ Alignment style 02 =================================//
        $this->start_controls_section(
            'sec_alignment', [
                'label' => __('Alignment', 'banca-core'),
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $this->add_responsive_control(
            'alignment', [
                'label' => __('Alignment', 'banca-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'banca-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'banca-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'banca-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .banca_images_animation2' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section(); //End Alignment


        $this->start_controls_section(
            'style_eight', [
                'label' => __('Parallax Image', 'banca-core'),
                'condition' => [
                    'style' => '8'
                ]
            ]
        );

        $this->add_control(
            'parallax_1', [
                'label' => __('Image 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'parallax_2', [
                'label' => __('Image 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'parallax_3', [
                'label' => __('Image 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section(); //End Alignment

        $this->start_controls_section(
            'style_eight_shape', [
                'label' => __('Parallax Shape', 'banca-core'),
                'condition' => [
                    'style' => '8'
                ]
            ]
        );

        $this->add_control(
            'parallax_shape_1', [
                'label' => __('Parallax Shape 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'parallax_shape_2', [
                'label' => __('Parallax Shape 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'parallax_shape_3', [
                'label' => __('Parallax Shape 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'parallax_shape_4', [
                'label' => __('Parallax Shape 04', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section(); //End Alignment

        $this->start_controls_section(
            'style_nine', [
                'label' => __('Map Image', 'banca-core'),
                'condition' => [
                    'style' => '9'
                ]
            ]
        );

        $this->add_control(
            'map_image', [
                'label' => __('Map Image', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater_map = new Repeater();

        $repeater_map->add_control(
            'map_flag', [
                'label' => __('Flag', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'map_flag_list', [
                'label' => __('Add Flag', 'plugin-domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater_map->get_controls(),
                'title_field' => '{{{ map_flag }}}',
            ]
        );

        $this->end_controls_section(); //End Image Map

        $this->start_controls_section(
            'style_10', [
                'label' => __('Image Card', 'banca-core'),
                'condition' => [
                    'style' => '10'
                ]
            ]
        );

        $this->add_control(
            'card_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'card_content', [
                'label' => __('Subtitle', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'card_image', [
                'label' => __('Image', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section(); //End Image

        $this->start_controls_section(
            'style_11', [
                'label' => __('Image Parallax', 'banca-core'),
                'condition' => [
                    'style' => '11'
                ]
            ]
        );

        $this->add_control(
            'parallax_image', [
                'label' => __('Image', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'parallax_img_01', [
                'label' => __('Shape 01', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'parallax_img_02', [
                'label' => __('Shape 02', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section(); //End Image

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {


        //============================ Shape Images style 02 =================================//
        $this->start_controls_section(
            'shape_images_sec', [
                'label' => __('Shape Images', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'align_items', [
                'type' => Controls_Manager::HIDDEN,
            ]
        );

        $repeater->add_control(
            'shape_image', [
                'label' => __('Image', 'plugin-domain'),
                'type' => Controls_Manager::MEDIA,
                'separator' => 'after'
            ]
        );

        $repeater->add_control(
            'is_parallax_number', [
                'label' => __('Parallax Number', 'plugin-domain'),
                'type' => Controls_Manager::POPOVER_TOGGLE,
                'label_on' => __('Custom', 'your-plugin'),
                'label_off' => __('None', 'your-plugin'),
                'return_value' => 'yes',
            ]
        );

        $repeater->add_control(
            'x_number', [
                'label' => __('Horizontal Number', 'plugin-domain'),
                'type' => Controls_Manager::NUMBER,
                'min' => -1000,
                'max' => 1000,
                'step' => 10,
                'default' => 10,
                'condition' => [
                    'is_parallax_number' => 'yes'
                ],
                'render_type' => 'ui',
            ]
        );

        $repeater->add_control(
            'y_number', [
                'label' => __('Vertical Number', 'plugin-domain'),
                'type' => Controls_Manager::NUMBER,
                'min' => -1000,
                'max' => 1000,
                'step' => 10,
                'default' => 10,
                'condition' => [
                    'is_parallax_number' => 'yes'
                ],
                'render_type' => 'ui',
            ]
        );

        $repeater->add_control(
            'z_rotate', [
                'label' => __('Rotate Number', 'plugin-domain'),
                'type' => Controls_Manager::NUMBER,
                'min' => -1000,
                'max' => 1000,
                'step' => 10,
                'default' => 0,
                'condition' => [
                    'is_parallax_number' => 'yes'
                ],
                'render_type' => 'ui',
            ]
        );

        $repeater->add_control(
            'is_class_layer',
            [
                'label' => __('Layer Class', 'plugin-domain'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'your-plugin'),
                'label_off' => __('Hide', 'your-plugin'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before'
            ]
        );

        $repeater->add_control(
            'data_depth', [
                'label' => __('Data Depth', 'plugin-domain'),
                'type' => Controls_Manager::NUMBER,
                'min' => -1000,
                'max' => 1000,
                'step' => 0.1,
                'default' => -0.06,
                'condition' => [
                    'is_class_layer' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'shape_images', [
                'label' => __('Add Image', 'plugin-domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ align_items }}}',
            ]
        );
        
        $this->end_controls_section(); // End Shape Images Style 02

        $this->start_controls_section(
            'card_image_10', [
                'label' => __('Card Section', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => '10'
                ]
            ]
        );

        // card style
        $this->add_control(
            'title_options', [
                'label' => __('Title', 'plugin-domain'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'style' => [ '10' ]
                ]
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => __('Text Color', 'plugin-domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'style' => [ '10' ]
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .__title',
                'condition' => [
                    'style' => [ '10' ]
                ]
            ]
        );

        $this->add_control(
            'content_options', [
                'label' => __('Content', 'plugin-domain'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'style' => [ '10' ]
                ]
            ]
        );

        $this->add_control(
            'content_color', [
                'label' => __('Text Color', 'plugin-domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__content' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'style' => [ '10' ]
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'content_typo',
                'selector' => '{{WRAPPER}} .__content',
                'condition' => [
                    'style' => [ '10' ]
                ]
            ]
        );

        $this->add_responsive_control(
            'card_padding', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .app-showcase-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'card_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .app-showcase-item',
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'round_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .app-showcase-item .round',
			]
		);

        $this->end_controls_section(); // End Shape Images Style 02

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        include "template/image/image-{$settings['style']}.php";

    }

}