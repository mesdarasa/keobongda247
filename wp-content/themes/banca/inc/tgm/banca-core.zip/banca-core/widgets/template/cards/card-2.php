<section class="feature-area-2">
    <div class="feature">
        <div class="row gy-lg-0 gy-4">
            <?php
            $data_delay_time = 0.1;
            if ( !empty($settings['cards2']) ) {
                foreach ( $settings['cards2'] as $card ) {
                    ?>
                    <div class="col-lg-4">
                        <div class="feature-widget-2 align-items-center wow fadeInRight feature-<?php echo esc_attr($card['style']) ?> elementor-repeater-item-<?php echo $card['_id'] ?>" data-wow-delay="<?php echo esc_attr($data_delay_time) ?>s">
                            <div class="shapes">
                                <?php
                                banca_el_image($card['shape1'], 'shape' );
                                banca_el_image($card['shape2'], 'shape' );
                                banca_el_image($card['shape3'], 'shape' );
                                banca_el_image($card['shape4'], 'shape' );
                                banca_el_image($card['shape5'], 'shape' );
                                banca_el_image($card['shape6'], 'shape' );
                                ?>
                            </div>
                            <div class="feature-img">
                                <?php banca_el_image($card['icon'], 'icon' ); ?>
                            </div>
                            <div class="feature-content">
                                <?php
                                if ( !empty( $card['title'] ) ) { ?>
                                    <p class="title"><?php echo esc_html($card['title']) ?></p>
                                    <?php
                                }
                                if ( !empty( $card['content'] ) ) { ?>
                                    <h6 class="_subtitle"><?php echo esc_html($card['content']) ?></h6>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                    $data_delay_time = $data_delay_time + 0.1;
                }
            }
            ?>
        </div>
    </div>



</section>