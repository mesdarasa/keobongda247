<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Repeater
};

use WP_Query;


/**
 * Class Blog
 * @package BancaCore\Widgets
 */
class Blog extends Widget_Base
{

    public function get_name()
    {
        return 'banca_blog';
    }

    public function get_title()
    {
        return __('Blog Posts (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-posts-masonry';
    }

    public function get_style_depends()
    {
        return ['slick', 'slick-theme'];
    }

    public function get_script_depends()
    {
        return ['slick'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {

        //============================= Style ================================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Border Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('Style 01', 'banca-core'),
                    '2' => __('Style 02', 'banca-core'),
                    '3' => __('Style 03', 'banca-core'),
                    '4' => __('Style 04', 'banca-core'),
                    '5' => __('05: Blog Grid', 'banca-core'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Style


        //============================= Filter Options ================================//
        $this->start_controls_section(
            'filter_sec', [
                'label' => __('Filter', 'banca-core'),
            ]
        );

        $this->add_control(
            'cats', [
                'label' => esc_html__('Category', 'banca-core'),
                'description' => esc_html__('Display blog by categories', 'banca-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => banca_cat_array(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'show_count', [
                'label' => esc_html__('Show Posts Count', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3
            ]
        );

        $this->add_control(
            'order', [
                'label' => esc_html__('Order', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => 'ASC',
                    'DESC' => 'DESC'
                ],
                'default' => 'ASC'
            ]
        );

        $this->add_control(
            'orderby', [
                'label' => esc_html__('Order By', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => 'None',
                    'ID' => 'ID',
                    'author' => 'Author',
                    'title' => 'Title',
                    'name' => 'Name (by post slug)',
                    'date' => 'Date',
                    'rand' => 'Random',
                ],
                'default' => 'none'
            ]
        );

        $this->add_control(
            'title_length', [
                'label' => esc_html__('Title Length', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
            ]
        );

        $this->add_control(
            'excerpt_length', [
                'label' => esc_html__('Excerpt Word Length', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
            ]
        );

        $this->add_control(
            'exclude', [
                'label' => esc_html__('Exclude Blog', 'banca-core'),
                'description' => esc_html__('Enter the portfolio post IDs to hide/exclude. Input the multiple ID with comma separated', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(), [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'include' => [],
                'default' => 'full',
            ]
        );

        // View Button
        $this->add_control(
            'read_more_btn', [
                'label' => esc_html__('Read More Button', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Read More',
                'condition' => [
                    'style' => ['1']
                ]
            ]
        );

        $this->end_controls_section();

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control() {


        //============================= Style Post Contents  ================================//
        $this->start_controls_section(
            'style_item_content', [
                'label' => __('Post Content', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'post_title_typo',
                'selector' => '{{WRAPPER}} .blog-widget-1 .blog-content h6 a',
            ]
        );

        $this->add_control(
            'post_title_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 .blog-content h6 a' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_control(
            'post_title_hover_color', [
                'label' => __('Hover Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 .blog-content h6 a:hover' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->end_controls_section(); //End Post Content Style


        //============================= Style Post Meta  ================================//
        $this->start_controls_section(
            'style_post_meta', [
                'label' => __('Post Meta', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'post_date_heading', [
                'label' => __('Post Date', 'plugin-name'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'post_date_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 .blog-content .cats' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'post_date_typo',
                'selector' => '
                    {{WRAPPER}} .blog-widget-1 .blog-content .cats',
            ]
        );

        $this->add_control(
            'post_cat_heading', [
                'label' => __('Post Category', 'plugin-name'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'post_cat_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 .blog-content .cats a' => 'color: {{VALUE}}',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'post_cat_typo',
                'selector' => '
                    {{WRAPPER}} .blog-widget-1 .blog-content .cats a',
            ]
        );


        $this->end_controls_section(); //End Post Meta


        //============================= Style Post Meta  ================================//
        $this->start_controls_section(
            'style_item_container', [
                'label' => __('Item Box Container', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // new control
        $this->add_responsive_control(
            'content_padding', [
                'label' => __('Content Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 .blog-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(), [
                'name' => 'content_shadow',
                'label' => __('Content Box Shadow', 'banca-core'),
                'selector' => '{{WRAPPER}} .blog-widget-1',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(), [
                'name' => 'content_hover_shadow',
                'label' => __('Hover Content Box Shadow', 'banca-core'),
                'selector' => '{{WRAPPER}} .blog-widget-1:hover',
            ]
        );

        $this->add_responsive_control(
            'border_radius', [
                'label' => __('Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'border_radius_img', [
                'label' => __('Image Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 img.attachment-full.size-full' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin', [
                'label' => __('Title Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 .blog-content h6' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'Author_margin', [
                'label' => __('Author Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .blog-widget-1 .blog-content .cats .fa-user-circle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'column', [
                'label' => __('Column', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '6' => __('Two Column', 'banca-core'),
                    '4' => __('Three Column', 'banca-core'),
                    '3' => __('Four Column', 'banca-core'),
                ],
                'default' => '4',
                'separator' => 'before',
            ]
        );


        $this->end_controls_section(); // End Post Content

    }

    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        extract($settings); // Array to Variable Conversation

        $args = [
            'post_type' => 'post',
            'post_status' => 'publish',
        ];

        if (!empty($show_count)) {
            $args['posts_per_page'] = $show_count;
        }

        if (!empty($order)) {
            $args['order'] = $order;
        }

        if (!empty($orderby)) {
            $args['orderby'] = $orderby;
        }

        if (!empty($exclude)) {
            $args['post__not_in'] = $exclude;
        }

        if (!empty($cats)) {
            $args['tax_query'] = [
                [
                    'taxonomy' => 'category',
                    'field' => 'slug',
                    'terms' => $cats

                ]
            ];
        }

        $posts = new WP_Query($args);

        //================== Template Parts =====================//
        include "template/blog/blog-{$settings['style']}.php";

    }

}