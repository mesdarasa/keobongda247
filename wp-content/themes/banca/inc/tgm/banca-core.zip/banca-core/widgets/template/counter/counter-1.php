<div class="d-flex justify-content-center">
    <div class="statistics-widget-1">
        <?php
        banca_el_image($settings['image'], 'icon');
        echo !empty($settings['title']) ? '<p class="title">' . esc_html($settings['title']) . '</p>' : '';
        if (!empty($settings['counter_text'])) { ?>
            <h2 class="counter">
                <span><?php echo esc_html($settings['counter_text']) ?></span><?php echo esc_html($settings['number_suffix']) ?>
            </h2>
            <?php
        }
        ?>
    </div>
</div>