<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Steps
 * @package BancaCore\Widgets
 */
class Steps extends Widget_Base
{

    public function get_name()
    {
        return 'banca_steps';
    }

    public function get_title()
    {
        return __('Steps (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-editor-list-ol';
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {


        //============================ Step Titles ===========================//
        $this->start_controls_section(
            'title_sec', [
                'label' => __('Step Title', 'banca-core'),
            ]
        );

        $this->add_control(
            'icon', [
                'label' => __('Image Icon', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Apply Online'
            ]
        );

        $this->add_control(
            'content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->end_controls_section(); //End Step Titles


        //============================ Step Items ===========================//
        $this->start_controls_section(
            'steps_contents', [
                'label' => __('Step contents', 'banca-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'list_item', [
                'label' => __('List Item', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => __('Highlighted text must be write in { }. Example : Welcome to { Our Website }', 'banca-core'),
            ]
        );

        $this->add_control(
            'steps', [
                'label' => __('Add Item', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ list_item }}}',
                'prevent_empty' => false
            ]
        );

        $this->end_controls_section();

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        //============================ Style Step Title =================================//
        $this->start_controls_section(
            'style_step_title', [
                'label' => __('Step Title', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //============== Step Title
        $this->add_control(
            'step_title_style', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'step_title_typo',
                'selector' => '{{WRAPPER}} .how-it-work .single-widget .widget-header .widget-title h4',
            ]
        );

        $this->add_control(
            'step_title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .how-it-work .single-widget .widget-header .widget-title h4' => 'color: {{VALUE}};',
                ]
            ]
        );

        //============== Step Sub Title
        $this->add_control(
            'step_sub_title_style', [
                'label' => esc_html__('Sub Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'step_sub_title_typo',
                'selector' => '{{WRAPPER}} .how-it-work .single-widget .widget-header .widget-title p',
            ]
        );

        $this->add_control(
            'step_sub_title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .how-it-work .single-widget .widget-header .widget-title p' => 'color: {{VALUE}};',
                ]
            ]
        );

        //============== Step Main Div
        $this->add_control(
            'step_bg_style', [
                'label' => esc_html__('Main Box', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'step_title_bg_color',
                'label' => __('Background', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .widget-header',
                'separator' => 'before'
            ]
        );

        $this->end_controls_section(); //End Step Title


        //============================ Style Step Item List =================================//
        $this->start_controls_section(
            'style_step_item_list', [
                'label' => __('Step Contents', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //============== Step Number
        $this->add_control(
            'step_number_heading', [
                'label' => __('Step Number', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'step_number_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .widget-content li .number' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'step_number_bg_color', [
                'label' => __('Background Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .widget-content li .number' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'step_number_active_bg_color', [
                'label' => __('Active Background Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .widget-content li.active .number' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(), [
                'name' => 'step_number_box_shadow',
                'label' => __('Box Shadow', 'banca-core'),
                'selector' => '{{WRAPPER}} .widget-content li.active .number',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'step_item_bg_color',
                'label' => __('Background', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .widget-content',
            ]
        );

        //============== Step Item
        $this->add_control(
            'step_normal_item_style', [
                'label' => esc_html__('Item Options', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'step_normal_item_typo',
                'selector' => '{{WRAPPER}} .how-it-work .single-widget .widget-content li .text',
            ]
        );

        $this->add_control(
            'step_normal_item_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .how-it-work .single-widget .widget-content li .text' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'step_active_item_color', [
                'label' => esc_html__('Active Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .how-it-work .single-widget .widget-content li.active .text' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->end_controls_section(); //End Style Step Item List

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="how-it-work">
            <div class="single-widget apply-online wow fadeInUp" data-wow-delay="0.1s">
                <div class="widget-header">
                    <div class="widget-img">
                        <?php echo wp_get_attachment_image($settings['icon']['id'], 'full') ?>
                    </div>
                    <div class="widget-title">
                        <h4><?php echo esc_html($settings['title']) ?></h4>
                        <p><?php echo esc_html($settings['content']) ?></p>
                    </div>
                </div>
                <ul class="widget-content">
                    <?php
                    if (!empty($settings['steps'])) {
                        foreach ($settings['steps'] as $index => $step) {
                            $active = $index == 0 ? ' class=active' : '';
                            $search = ['{', '}'];
                            $replace = ['<span class="number">', '</span>'];
                            ?>
                            <li<?php echo esc_attr($active) ?>><span
                                        class="text"><?php echo wp_kses_post(str_replace($search, $replace, $step['list_item'])) ?></span>
                            </li>
                            <?php
                        }
                    }
                    ?>
                </ul>
            </div>
        </section>
        <?php
    }
}