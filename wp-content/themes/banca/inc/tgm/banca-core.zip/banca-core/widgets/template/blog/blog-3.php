<div class="blog-post-widget">
    <div class="row gy-4">
        <?php
        $delay_time = 0.1;
        while ($posts->have_posts()) : $posts->the_post();
            ?>
            <div class="col-md-6">
                <div class="blog-widget-2 wow fadeInUp" data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                    <div class="blog-img">
                        <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                        <a href="<?php echo Banca_Core_Helper()->get_the_first_taxonomy_link(); ?>">
                            <div class="catagory bg_primary">
                                <?php echo Banca_Core_Helper()->get_the_first_taxonomy(); ?>
                            </div>
                        </a>
                    </div>
                    <div class="blog-content">
                        <h4>
                            <a href="<?php the_permalink(); ?>">
                                <?php echo Banca_Core_Helper()->get_the_title_length($settings, 'title_length') ?>
                            </a>
                        </h4>
                        <p><?php echo Banca_Core_Helper()->get_the_excerpt_length($settings, 'excerpt_length') ?></p>
                        <div class="post-info">
                            <div class="author">
                                <i class="far fa-user"></i>
                                <span><?php echo get_the_author_meta('display_name') ?></span>
                            </div>
                            <div class="post-date">
                                <i class="far fa-calendar-alt"></i>
                                <span><?php the_time(get_option('date_format')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $delay_time = $delay_time + 0.1;
        endwhile;
        wp_reset_postdata();
        ?>
    </div>
    <div class="row mt-55">
        <div class="col-12">
            <div class="pagination-widget">
                <?php
                $big = 999999999; // need an unlikely integer
                echo paginate_links(array(
                    'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format' => '?paged=%#%',
                    'current' => max(1, get_query_var('paged')),
                    'total' => $posts->max_num_pages,
                    'prev_text' => '',
                    'next_text' => '',
                ));
                ?>
            </div>
        </div>
    </div>
</div>