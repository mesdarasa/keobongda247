<div class="testimonial-slider">
    <?php
    if ( !empty($settings['testimonials3']) ) {
        foreach ( $settings['testimonials3'] as $testimonial ) {
            ?>
            <div class="single-slider">
                <div class="testimonial-widget">
                    <div class="row align-items-center">
                        <div class="col-4">
                            <?php if ( !empty( $testimonial['image']['id']) ) : ?>
                                <div class="author-img">
                                    <?php echo wp_get_attachment_image($testimonial['image']['id'], 'full') ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-8">
                            <div class="testimonial-content">
                                <?php
                                if ( !empty( $testimonial['video_title_url']) ) {
                                    ?>
                                    <div class="watch-button">
                                        <a data-fancybox href="<?php echo esc_url($testimonial['video_title_url']) ?>">
                                            <i class="fa fa-play"></i>
                                            <?php echo esc_html($testimonial['video_title']) ?>
                                        </a>
                                    </div>
                                    <?php
                                }
                                if ( !empty( $testimonial['title']) ) {
                                    ?>
                                    <h2><?php echo esc_html($testimonial['title']) ?></h2>
                                    <?php
                                }
                                if ( !empty( $testimonial['quote']) ) {
                                    ?>
                                    <p class="quote __review_content"><?php echo esc_html($testimonial['quote']) ?></p>
                                    <?php
                                }
                                if ( !empty( $testimonial['name']) ) {
                                    ?>
                                    <div class="author-info">
                                        <h4 class="name __name"><?php echo esc_html($testimonial['name']) ?></h4>
                                        <span class="designation __designation"><?php echo esc_html($testimonial['designation']) ?></span>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    }
    ?>
</div>
