<section class="client-area testimonial_style_five">
    <div class="client-slider" data-rtl="<?php echo esc_attr(banca_core_rtl()) ?>">
        <?php
        $delay_time = 0.1;
        if ( $testimonials5 ) {
            foreach ( $testimonials5 as $item ) {
                ?>
                <div class="single-client wow fadeInUp" data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                    <?php banca_el_image($item['image'], 'avatar', 'img-fluid rounded-circle' ); ?>
                    <div class="client-info">
                        <?php
                        if ( !empty( $item['testimonial_title'] ) ) { ?>
                            <h3 class="testimonial_title"><?php echo esc_html($item['testimonial_title']) ?></h3>
                            <?php
                        }
                        if ( !empty( $item['testimonial_content'] ) ) { ?>
                            <p class="testimonial_content"><?php echo esc_html($item['testimonial_content']) ?></p>
                            <?php
                        }
                        ?>
                    </div>
                </div>
                <?php
                $delay_time = $delay_time + 0.2;
            }
        }
        ?>
    </div>
</section>