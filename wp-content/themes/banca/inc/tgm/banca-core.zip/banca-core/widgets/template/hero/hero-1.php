<section class="banner-area hero_animation1 banca-hero dark_mode_sec_wrap">
    <div class="bubbles">
        <div data-parallax='{"x": 0, "y": -250, "rotateZ":0}'>
            <div class="bubble">
            </div>
        </div>
        <div data-parallax='{"x": 0, "y": -250, "rotateZ":0}'>
            <div class="bubble">
            </div>
        </div>
        <div data-parallax='{"x": 50, "y": -250, "rotateZ":0}'>
            <div class="bubble">
            </div>
        </div>
        <div data-parallax='{"x": 60, "y": -200, "rotateZ":0}'>
            <div class="bubble">
            </div>
        </div>
        <div data-parallax='{"x": 50, "y": -130, "rotateZ":0}'>
            <div class="bubble">
            </div>
        </div>
        <div data-parallax='{"x": 130, "y": 250, "rotateZ":0}'>
            <div class="bubble">
            </div>
        </div>
        <div data-parallax='{"x": 0, "y": -250, "rotateZ":0}'>
            <div class=" bubble">
            </div>
        </div>
        <div data-parallax='{"x": 100, "y": -250, "rotateZ":0}'>
            <div class="bubble">
            </div>
        </div>
    </div>
    <div class="logos">
        <?php
        if (!empty($settings['logos'])) {
            foreach ($settings['logos'] as $logo) {
                banca_el_image($logo['logo'], 'logo');
            }
        }
        ?>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="banner-content text-center pt-200">
                    <?php if (!empty($settings['title'])) : ?>
                        <h1 class="__title"><?php echo banca_core_kses_post(nl2br($settings['title'])) ?></h1>
                    <?php endif; ?>
                    <div class="img-area mt-35">
                        <?php echo wp_get_attachment_image($settings['f_img']['id'], 'full', false, array('class' => 'img-fluid', 'data-depth' => '0.6')); ?>
                    </div>
                    <div class="symbol-pulse">
                        <div class="pulse-1"></div>
                        <div class="pulse-2"></div>
                        <div class="pulse-x"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>