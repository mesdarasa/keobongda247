<div class="feature-job-tab">
    <ul class="feature-job-list">
        <?php
        $data_wow_delay = 0.1;
        if ($jobs->have_posts()) :
            while ($jobs->have_posts()) : $jobs->the_post();
                ?>
                <li class="mt-0">
                    <div class="single-feature-job wow fadeInUp"
                         data-wow-delay="<?php echo esc_attr($data_wow_delay) ?>s">
                        <h6 class="job-title">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                                <?php the_title() ?>
                            </a>
                        </h6>
                        <div class="d-flex flex-wrap">
                            <div class="job-location me-3"><i class="icon_pin_alt"></i>
                                <?php echo Banca_Core_Helper()->get_the_first_taxonomy('job_location'); ?>
                            </div>
                            <div class="job-catagory">
                                <span><?php echo Banca_Core_Helper()->get_the_first_taxonomy('job_cat'); ?></span>
                                | <?php echo Banca_Core_Helper()->get_the_first_taxonomy('job_type'); ?>
                            </div>
                        </div>
                    </div>
                </li>
                <?php
                $data_wow_delay = $data_wow_delay + 0.2;
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    </ul>
</div>
