<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Tabs
 * @package BancaCore\Widgets
 */
class Tabs extends Widget_Base
{

    public function get_name()
    {
        return 'banca_tabs';
    }

    public function get_title()
    {
        return __('Tabs (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-tabs';
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {


        //============================ Style ===========================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('01: Vertical Tab', 'banca-core'),
                    '2' => __('02: Horizontal Tab', 'banca-core'),
                    '3' => __('03: Tab', 'banca-core'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Style


        //============================ Tabs ===========================//
        $this->start_controls_section(
            'tabs_sec', [
                'label' => __('Tabs', 'banca-core'),
            ]
        );

        //==================== Tab 01
        $tab1 = new Repeater();
        $tab1->add_control(
            'tab_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $tab1->add_control(
            'tab_content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::WYSIWYG,
            ]
        );

        $this->add_control(
            'tabs', [
                'label' => __('Accordion Items', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $tab1->get_controls(),
                'title_field' => '{{{ tab_title }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => '1',
                ],
            ]
        );


        //==================== Tab 02
        $tab2 = new Repeater();
        $tab2->add_control(
            'tab_title', [
                'label' => __('Tab Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'separator' => 'after',
                'default' => __('Freelancers', 'banca-core'),
            ]
        );

        $tab2->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Access to secure <span class="underline-shape">banking</span>', 'banca-core'),
            ]
        );

        $tab2->add_control(
            'content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $tab2->add_control(
            'btn_label', [
                'label' => __('Button Label', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Get started now', 'banca-core'),
            ]
        );

        $tab2->add_control(
            'btn_url', [
                'label' => __('Button URL', 'banca-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $tab2->add_control(
            'image', [
                'label' => __('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $tab2->add_control(
            'image2', [
                'label' => __('Image Two', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'tabs2', [
                'label' => __('Accordion Items', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $tab2->get_controls(),
                'title_field' => '{{{ tab_title }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => ['2','3'],
                ],
            ]
        );

        $this->end_controls_section(); //End Tabs


        //============================ List Items ===========================//
        $this->start_controls_section(
            'list_item_sec', [
                'label' => __('List Items', 'banca-core'),
                'condition' => [
                    'style' => '1',
                ],
            ]
        );

        $this->add_control(
            'item_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Awards'
            ]
        );

        $this->add_control(
            'item_image', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'separator' => 'after'
            ]
        );

        $tab1 = new Repeater();
        $tab1->add_control(
            'item_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $tab1->add_control(
            'item_content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::WYSIWYG,
            ]
        );

        $this->add_control(
            'list_items', [
                'label' => __('Add List Item', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $tab1->get_controls(),
                'title_field' => '{{{ item_title }}}',
                'prevent_empty' => false,
            ]
        );

        $this->end_controls_section(); // End List Items

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        //============================ Tabs ===========================//
        $this->start_controls_section(
            'tab_style',
            [
                'label' => __('Tabs', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //=======Title
        $this->add_control(
            'tab_heading_style', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'tab_heading_typo',
                'selector' => '{{WRAPPER}} .recognition-widget .widget-navigation ul li a, .bank-card-tab .nav-item .bank-card-item .__title',
            ]
        );

        $this->add_control(
            'tab_title_color',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .recognition-widget .widget-navigation ul li a, .bank-card-tab .nav-item .bank-card-item .__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'tab_active_color',
            [
                'label' => __('Active Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .recognition-widget .widget-navigation ul li a.active' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .recognition-widget .tab-content h3' => 'color: {{VALUE}}',
                ],
            ]
        );


        //=======Description
        $this->add_control(
            'tab_des_style', [
                'label' => esc_html__('Description', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'tab_des_typo',
                'selector' => '{{WRAPPER}} .recognition-widget .tab-content P, .bank-card-tab .nav-item .bank-card-item .__content',
            ]
        );

        $this->add_control(
            'tab_des_color',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .recognition-widget .tab-content P, .bank-card-tab .nav-item .bank-card-item .__content' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .recognition-widget .tab-content P::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        // Tabs active
        $this->add_control(
            'tab_active_style', [
                'label' => esc_html__('Active Color', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'tab_title_active_color',
            [
                'label' => __('Title Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .recognition-widget .widget-navigation ul li a, .bank-card-tab .nav-item .bank-card-item.active .__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'tab_des_active_color',
            [
                'label' => __('Content Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .recognition-widget .tab-content P, .bank-card-tab .nav-item .bank-card-item.active .__content' => 'color: {{VALUE}}',
                ],
            ]
        );



        $this->end_controls_section(); //End

        //============================ List Items ===========================//
        $this->start_controls_section(
            'item_title_style',
            [
                'label' => __('List Items', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //=======Header
        $this->add_control(
            'items_heading_style', [
                'label' => esc_html__('Header', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'item_title_color',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accolades-header h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'item_heading_typo',
                'selector' => '{{WRAPPER}} .accolades-header h2',
            ]
        );

        //=======Single Item Title
        $this->add_control(
            'item_heading_style', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'single_title_color',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accolades-widget .accolades-content .subtitle' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'item_title_typo',
                'selector' => '{{WRAPPER}} .accolades-widget .accolades-content .subtitle',
            ]
        );


        //=======Single Item Description
        $this->add_control(
            'item_des_style', [
                'label' => esc_html__('Description', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'single_des_color',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accolades-widget .accolades-content ul li p + p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'item_des_typo',
                'selector' => '{{WRAPPER}} .accolades-widget .accolades-content ul li p + p',
            ]
        );

        $this->add_control(
            'item_bg_style', [
                'label' => esc_html__('Item Box', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'item_bg',
                'label' => __('Background', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .accolades-widget',
            ]
        );

        $this->end_controls_section(); //End




        // Tabs Two control
        $this->start_controls_section(
            'tabs_two', [
                'label' => __('Tabs Two', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        //=======Title
        $this->add_control(
            'items_heading_style_2', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'item_title_color_2',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title h1' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'item_heading_typo_2',
                'selector' => '{{WRAPPER}} .section-title h1',
            ]
        );

        //======= Description
        $this->add_control(
            'item_heading_style_2', [
                'label' => esc_html__('Description', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'single_title_color_2',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title P' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'item_title_typo_2',
                'selector' => '{{WRAPPER}} .section-title P',
            ]
        );


        //=======button
        $this->add_control(
            'item_des_style_2', [
                'label' => esc_html__('Button', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'single_des_color_2',
            [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-tab-area .tab-content .section-title .read-more' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'item_des_typo_2',
                'selector' => '{{WRAPPER}} .about-tab-area .tab-content .section-title .read-more',
            ]
        );



        $this->end_controls_section(); //End


    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        extract($settings); //Array to variables Conversion

        $tabs = $this->get_settings_for_display('tabs');
        $id_int = substr($this->get_id_int(), 0, 1);


        //======= Template Parts ========//
        include "template/tabs/tab-{$settings['style']}.php";

    }

}