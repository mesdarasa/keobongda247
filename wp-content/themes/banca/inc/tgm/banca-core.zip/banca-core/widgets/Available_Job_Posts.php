<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Repeater
};

/**
 * Class Available_Job_Posts
 * @package BancaCore\Widgets
 */
class Available_Job_Posts extends Widget_Base {

    public function get_name() {
        return 'banca_available_job_posts';
    }

    public function get_title() {
        return __('Available Job Posts (Banca)', 'banca-core');
    }

    public function get_icon() {
        return 'eicon-counter-circle';
    }

    public function get_categories() {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls() {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control() {
        //============================ Job Post Count Titles ===========================//
        $this->start_controls_section(
            'post_count_title_sec', [
                'label' => __('Step Title', 'banca-core'),
            ]
        );

        $this->add_control(
            'post_count_title', [
                'label' => __('Post Count Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Jobs Available'
            ]
        );

        $this->end_controls_section(); //End Step Titles

        /***
         *
         * @@@
         * Style Tab
         * @@@
         *
         **/

        //============================ Style Step Item List =================================//
        $this->start_controls_section(
            'style_step_item_list', [
                'label' => __('Step Contents', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => __('Typography', 'plugin-domain'),
                'selector' => '{{WRAPPER}} .title',
            ]
        );

        $this->end_controls_section(); //End Style Step Item List

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>
        <p class="title"><?php echo esc_html(bancaCore_count_posts()); ?><?php echo esc_html($settings['post_count_title']) ?></p>
        <?php
    }
}