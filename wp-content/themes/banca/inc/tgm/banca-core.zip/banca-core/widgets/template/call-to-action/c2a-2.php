<div class="cta cta-2 banca_sec">
    <div class="bubbles">
        <div class="bubble-1"></div>
        <div class="bubble-2"></div>
        <div class="bubble-3"></div>
        <div class="bubble-4"></div>
        <div class="bubble-5"></div>
        <div class="bubble-6"></div>
        <div class="bubble-7"></div>
        <div class="bubble-8"></div>
    </div>
    <div class="row gy-xl-0 gy-4">
        <div class="col-xl-5">
            <div class="cta-content wow fadeInLeft text-center text-xl-start">
                <h2><?php echo esc_html($settings['title']) ?></h2>
            </div>
        </div>
        <div class="col-xl-7 d-flex align-items-center flex-wrap justify-content-xl-end justify-content-center">
            <?php
            $delay_time = 0.1;
            if (!empty($settings['buttons'])) {
                foreach ($settings['buttons'] as $button) {
                    ?>
                    <a <?php Banca_Core_Helper()->the_button($button['btn_url']) ?>>
                        <div class="app-btn mt-3 mt-sm-0 wow fadeInRight"
                             data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                            <?php \Elementor\Icons_Manager::render_icon($button['btn_icon']); ?>
                            <div class="btn-text"><span><?php echo esc_html($button['btn_title1']) ?></span><p><?php echo esc_html($button['btn_title2']) ?></p>
                            </div>
                        </div>
                    </a>
                    <?php
                    $delay_time = $delay_time + 0.1;
                }
            }
            ?>
        </div>
    </div>
</div>