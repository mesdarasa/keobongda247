<div class="safe-deposit-area">
    <div class="card-img">
        <div class="logo">
            <?php
            if ( !empty($settings['clients_logo']) ) {
                foreach ( $settings['clients_logo'] as $clients_logo ) {
                    ?>
                    <?php echo wp_get_attachment_image($clients_logo['logo']['id'], 'full') ?>
                    <?php
                }
            }
            ?>
        </div>
        <?php echo wp_get_attachment_image($settings['shape']['id'], 'full', '', array( 'class' => 'bg-img' ) ) ?>
        <?php echo wp_get_attachment_image($settings['f_image']['id'], 'full', '', array( 'class' => 'img-fluid wow fadeInUp' ) ) ?>
    </div>
</div>