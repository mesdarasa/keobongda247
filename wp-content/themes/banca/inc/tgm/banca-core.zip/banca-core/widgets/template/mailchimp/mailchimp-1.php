<section class="cta-3">
    <div class="img-shapes">
        <div class="shape" data-parallax='{"x": 0, "y": 0, "rotateZ":20}'>
            <?php banca_el_image($settings['floating_obj1'], 'Object'); ?>
        </div>
        <div class="shape" data-parallax='{"x": 200, "y": 90, "rotateZ":0}'>
            <div class="fly-msg">
                <?php
                banca_el_image($settings['floating_obj2'], 'Object');
                banca_el_image($settings['floating_obj3'], 'Object');
                banca_el_image($settings['floating_obj4'], 'Object');
                ?>
            </div>
        </div>
        <div class="shape" data-parallax='{"x": 0, "y": 0, "rotateZ":-6}'>
            <?php echo wp_get_attachment_image($settings['floating_obj5']['id'], 'full', '', array('class' => 'wow fadeInRight')) ?>
        </div>
        <div class="shape" data-parallax='{"x": -200, "y": 0, "rotateZ":0}'>
            <?php banca_el_image($settings['floating_obj6'], 'Object'); ?>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="cta-content text-black wow fadeInLeft">
                    <?php
                    if (!empty($settings['upper_title'])) { ?>
                        <h5><?php echo esc_html($settings['upper_title']) ?></h5>
                    <?php
                    }
                    if (!empty($settings['title'])) { ?>
                        <h2><?php echo esc_html($settings['title']) ?></h2>
                    <?php
                    }
                    ?>
                    <form action="javascript:void(0)" class="mailchimp" data-action-url="<?php echo esc_url($settings['action_url']); ?>" method="post">
                        <div class="input-group mt-40">
                            <input type="email" class="form-control memail" name="EMAIL" placeholder="<?php echo esc_attr($settings['email_placeholder']) ?>">
                            <button type="submit" class="input-append theme-btn theme-btn-lg">
                                <?php echo esc_html($settings['btn_label']); ?>
                            </button>
                        </div>
                        <p class="mchimp-errmessage text-center mt-3" style="display: none;"></p>
                        <p class="mchimp-sucmessage text-center mt-3" style="display: none;"></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>