<section class="news-area-2 position-relative">
    <div class="row gy-lg-0 gy-4">
        <?php
        $delay_time = 0.1;
        while ($posts->have_posts()) : $posts->the_post();
            ?>
            <div class="col-lg-<?php echo esc_attr($column) ?> col-md-6">
                <div class="blog-widget-3 wow fadeInUp" data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                    <div class="blog-img">
                        <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                        <div class="catagory yellow-bg">Design</div>
                    </div>
                    <div class="blog-content">
                        <h4>
                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                                <?php echo Banca_Core_Helper()->get_the_title_length($settings, 'title_length') ?>
                            </a>
                        </h4>
                        <div class="post-info">
                            <div class="post-date">
                                <i class="far fa-calendar"></i>
                                <span><?php echo get_the_date() ?></span>
                            </div>
                            <div class="author">
                                <i class="far fa-user-circle"></i>
                                <span><?php echo Banca_Core_Helper()->get_the_first_taxonomy(); ?></span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <?php
            $delay_time = $delay_time + 0.2;
            wp_reset_postdata();
        endwhile;
        ?>

    </div>
</section>