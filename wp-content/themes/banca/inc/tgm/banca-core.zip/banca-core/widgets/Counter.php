<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Repeater
};

/**
 * Class Counter
 * @package BancaCore\Widgets
 */
class Counter extends Widget_Base
{
    public function get_name()
    {
        return 'banca_counter';
    }

    public function get_title()
    {
        return __('Banca Counter (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-counter';
    }

    public function get_style_depends()
    {
        return ['slick', 'slick-theme'];
    }

    public function get_script_depends()
    {
        return ['counterup', 'waypoints', 'slick'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control() {


        //============================== Section Style  ===============================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('Style 01', 'banca-core'),
                    '2' => __('Style 02', 'banca-core'),
                    '3' => __('Style 03 (Footer)', 'banca-core'),
                ],
                'default' => '1'
            ]
        );

        $this->end_controls_section(); // End Style


        //============================== Counter Style 01  ===============================//
        $this->start_controls_section(
            'counter_sec', [
                'label' => __('Counter', 'banca-core'),
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'image', [
                'label' => __('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Active user'
            ]
        );

        $this->add_control(
            'counter_text', [
                'label' => __('Counter Text', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '15,000'
            ]
        );

        $this->add_control(
            'number_suffix', [
                'label' => __('Number Suffix', 'banca-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $this->add_responsive_control(
            'alignment', [
                'label' => __('Alignment', 'banca-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'banca-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'banca-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'banca-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .statistics-widget-1' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section(); // End Counter Style 01


        //========================== Counter Style 02 =========================== //
        $this->start_controls_section(
            'counters_sec2', [
                'label' => __('Counters', 'banca-core'),
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'counter_text', [
                'label' => __('Counter Text', 'plugin-domain'),
                'type' => Controls_Manager::TEXT,
                'default' => '10,000',
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'title', [
                'label' => __('Title', 'plugin-domain'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('We employ 15,000 people around the world', 'plugin-domain'),
            ]
        );

        $this->add_control(
            'counters', [
                'label' => __('Add Counter', 'plugin-domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
                'prevent_empty' => false,
            ]
        );

        $this->end_controls_section(); // End Counter Style 02


        //============================== Counter Style 03  ===============================//
        $this->start_controls_section(
            'counter3_sec', [
                'label' => __('Counter', 'banca-core'),
                'condition' => [
                    'style' => '3'
                ]
            ]
        );

        $this->add_control(
            'counter_text_number', [
                'label' => __('Counter Number', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '$<span>35.105</span>'
            ]
        );

        $this->add_control(
            'counter_text_number_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h1.counter' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'counter_text_number_typo',
                'selector' => '{{WRAPPER}} h1.counter',
            ]
        );

        // Counter Percentage
        $this->add_control(
            'counter_text_percentage', [
                'label' => __('Counter Percentage', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '-<span>0.46</span>%',
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'counter_text_percentage_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h4.counter' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'counter_text_percentage_typo',
                'selector' => '{{WRAPPER}} h4.counter',
            ]
        );

        $this->end_controls_section(); // End Counter Style 03
    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control() {

        //============================ Style Title =================================//
        $this->start_controls_section(
            'style_title', [
                'label' => __('Title', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['1', '2']
                ]
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .statistics-widget-2 .widget-content p' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .statistics-widget-1 p' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '
                    {{WRAPPER}} .statistics-widget-2 .widget-content p,
                    {{WRAPPER}} {{WRAPPER}} .statistics-widget-1 p
                ',
            ]
        );

        $this->end_controls_section(); // End title


        //============================ Counter Style =============================//
        $this->start_controls_section(
            'style_counter', [
                'label' => __('Counter Text', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['1', '2']
                ]
            ]
        );

        $this->add_control(
            'counter_text_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .statistics-widget-2 .widget-content h1' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .statistics-widget-1 .counter' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'counter_text_typo',
                'selector' => '
                    {{WRAPPER}} .statistics-widget-2 .widget-content h1,
                    {{WRAPPER}} .statistics-widget-1 .counter
                ',
            ]
        );

        $this->end_controls_section(); // End Counter Style


        //============================ Section Background =============================//
        $this->start_controls_section(
            'sec_background', [
                'label' => __('Background', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['1', '2']
                ]
            ]
        );

        $this->add_responsive_control(
            'sec_margin', [
                'label' => __('Margin', 'plugin-domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .statistics-widget-2 .widget-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_responsive_control(
            'sec_padding', [
                'label' => __('Padding', 'plugin-domain'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .statistics-widget-2 .widget-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'sec_bg',
                'label' => __('Background', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .statistics-widget-2 .widget-content',
            ]
        );

        $this->end_controls_section(); // End Counter Style

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        extract($settings); // Array to Variable Conversation

        //============= Template Parts ==================//
        include "template/counter/counter-1.php";


    }

}