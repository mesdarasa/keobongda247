<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Video
 * @package BancaCore\Widgets
 */
class Video extends Widget_Base
{

    public function get_name()
    {
        return 'banca_video';
    }

    public function get_title()
    {
        return __('Video (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-person';
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {
        $this->start_controls_section(
            'video_sec', [
                'label' => __('Video', 'banca-core'),
            ]
        );
        $this->add_control(
            'video_url', [
                'label' => esc_html__('Video URL', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '#',
                'label_block' => true
            ]
        );
        $this->end_controls_section();

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control(){}

    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="video_section wow fadeInLeft">
            <div class="video">
                    <a class="play-btn" data-fancybox href="<?php echo esc_url($settings['video_url']) ?>">
                        <i class="fas fa-play"></i>
                    </a>
            </div>
        </div>
        <?php
    }
}