<div class="client-slider-2">
    <?php
    $delay_time = 0.1;
    if ($testimonials) {
        foreach ($testimonials as $item) {
            ?>
            <div class="single-client wow fadeInUp" data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                <div class="rating">
                    <?php
                    for ($i = 1; $i <= 5; $i++) {
                        if ($i > $item['ratting']) {
                            echo '<a href="#"><i class="icon_star_alt"></i></a>';
                        } else {
                            echo '<a href="#"><i class="icon_star"></i></a>';
                        }
                    }
                    ?>
                </div>
                <?php
                if (!empty($item['quote'])) { ?>
                    <p class="quote"><?php echo esc_html($item['quote']) ?></p>
                    <?php
                }
                if (!empty($item['designation'])) { ?>
                    <div class="client-info">
                        <?php banca_el_image($item['image'], 'avatar', 'img-fluid rounded-circle'); ?>
                        <div>
                            <p class="name"><?php echo esc_html($item['name']) ?></p>
                            <span class="role designation"><?php echo esc_html($item['designation']) ?></span>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <?php
            $delay_time = $delay_time + 0.2;
        }
    }
    ?>

</div>
