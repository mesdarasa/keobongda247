<div class="row gy-4">
    <?php
    $delay_time = 0.1;
    while ($posts->have_posts()) : $posts->the_post();
        ?>
        <div class="col-lg-<?php echo esc_attr($column) ?> col-md-6">
            <div class="blog-widget-1 wow fadeInUp" data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                <div class="blog-content">
                    <div class="cats">
                        <?php echo get_the_date() ?>
                        <span class="separator"> | </span>
                        <a href="<?php echo Banca_Core_Helper()->get_the_first_taxonomy_link(); ?>">
                            <?php echo Banca_Core_Helper()->get_the_first_taxonomy(); ?>
                        </a>
                    </div>
                    <h6>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                            <?php echo Banca_Core_Helper()->get_the_title_length($settings, 'title_length') ?>
                        </a>
                    </h6>
                </div>
            </div>
        </div>
        <?php
        $delay_time = $delay_time + 0.2;
        wp_reset_postdata();
    endwhile;
    ?>
</div>

