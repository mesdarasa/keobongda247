<section class="recognition-area">
    <div class="recognition-widget">
        <div class="row gy-4 gy-lg-0">
            <div class="col-lg-3 col-5">
                <div class="widget-navigation wow fadeInUp pe-lg-4" data-wow-delay="0.1s">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <?php
                        foreach ($tabs as $index => $item) {
                            $tab_count = $index + 1;
                            $active = $tab_count == 1 ? ' active' : '';
                            $tab_title_setting_key = $this->get_repeater_setting_key('tab_title', 'tabs', $index);

                            $this->add_render_attribute($tab_title_setting_key, [
                                'class' => ['nav-link', $active],
                                'id' => 'banca' . $id_int . $tab_count,
                                'data-bs-toggle' => 'tab',
                                'href' => '#twenty' . $id_int . $tab_count,
                                'role' => 'tab',
                                'aria-controls' => 'twenty' . $id_int . $tab_count,
                                'aria-selected' => $tab_count == 1 ? 'false' : 'true',
                            ]);
                            ?>
                            <li class="nav-item" role="presentation">
                                <a <?php echo $this->get_render_attribute_string($tab_title_setting_key); ?>>
                                    <?php echo esc_html($item['tab_title']) ?>
                                </a>
                            </li>
                            <?php
                        }
                        ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-7">
                <div class="tab-content wow fadeInUp" data-wow-delay="0.3s" id="myTabContent">
                    <?php
                    foreach ($tabs as $index => $item) {
                        $tab_count = $index + 1;
                        $active_show = $tab_count == 1 ? ' active show' : '';
                        $tab_content_setting_key = $this->get_repeater_setting_key('tab_content', 'tabs', $index);

                        $this->add_render_attribute($tab_content_setting_key, [
                            'class' => 'tab-pane fade' . $active_show,
                            'id' => 'twenty' . $id_int . $tab_count,
                            'role' => 'tabpanel',
                            'aria-labelledby' => 'banca' . $id_int . $tab_count,
                        ]);
                        ?>
                        <div <?php echo $this->get_render_attribute_string($tab_content_setting_key); ?>>
                            <?php echo !empty($item['tab_content']) ? banca_core_kses_post(wpautop($item['tab_content'])) : '' ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5 offset-xl-1 pr-lg-35 pl-lg-35">
                <div class="accolades-widget wow fadeInUp" data-wow-delay="0.5s">
                    <div class="accolades-header d-flex justify-content-between align-items-end">
                        <?php
                        if (!empty($settings['item_title'])) { ?>
                            <h2><?php echo esc_html($settings['item_title']) ?></h2>
                            <?php
                        }
                        if (!empty($settings['item_image']['id'])) {
                            echo wp_get_attachment_image($settings['item_image']['id'], 'full');
                        }
                        ?>
                    </div>
                    <div class="accolades-content">
                        <ul>
                            <?php
                            if (!empty($settings['list_items'])) {
                                foreach ($settings['list_items'] as $item) {
                                    ?>
                                    <li>
                                        <?php
                                        if (!empty($item['item_title'])) { ?>
                                            <p class="subtitle"><?php echo esc_html($item['item_title']) ?></p>
                                            <?php
                                        }
                                        if (!empty($item['item_content'])) {
                                            echo banca_core_kses_post(wpautop($item['item_content']));
                                        }
                                        ?>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>