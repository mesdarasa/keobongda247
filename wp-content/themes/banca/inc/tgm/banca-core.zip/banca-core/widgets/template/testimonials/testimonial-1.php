<section class="client-area">
    <div class="client-slider" data-rtl="<?php echo esc_attr(banca_core_rtl()) ?>">
        <?php
        $delay_time = 0.1;
        if ( $testimonials ) {
            foreach ( $testimonials as $item ) {
                ?>
                <div class="single-client wow fadeInUp" data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                    <?php banca_el_image($item['image'], 'avatar', 'img-fluid rounded-circle' ); ?>
                    <?php echo !empty($item['quote']) ? '<p class="quote __review_content">'. esc_html($item['quote']) .'</p>' : '' ?>
                    <div class="client-info">
                        <div>
                            <?php
                            if ( !empty( $item['name'] ) ) { ?>
                                <p class="name __name"><?php echo esc_html($item['name']) ?></p>
                                <?php
                            }
                            if ( !empty( $item['designation'] ) ) { ?>
                                <span class="role designation __designation"><?php echo esc_html($item['designation']) ?></span>
                                <?php
                            }
                            ?>
                        </div>
                        <div class="rating">
                            <?php
                            for ( $i = 1;  $i <= 5;  $i++ ) {
                                if ( $i > $item['ratting'] ) {
                                    echo '<a href="#"><i class="icon_star_alt"></i></a>';
                                }
                                else {
                                    echo '<a href="#"><i class="icon_star"></i></a>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <?php
                $delay_time = $delay_time + 0.2;
            }
        }
        ?>
    </div>
</section>