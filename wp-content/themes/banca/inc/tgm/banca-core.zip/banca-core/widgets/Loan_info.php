<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Loan_info
 * @package BancaCore\Widgets
 */
class Loan_info extends Widget_Base
{

    public function get_name()
    {
        return 'banca_loan_info';
    }

    public function get_title()
    {
        return __('Loan Info (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-info-box';
    }

    public function get_style_depends()
    {
        return ['nice-select', 'editable-select', 'slick-theme', 'slick'];
    }

    public function get_script_depends()
    {
        return ['nice-select', 'counterup', 'waypoints', 'fancybox', 'editable-select', 'smoothsroll', 'slick'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {


        //============================ Select Style ===========================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('01: Loan Info Card', 'banca-core'),
                    '2' => esc_html__('02: Loan Type', 'banca-core'),
                    '3' => esc_html__('03: Loan Type', 'banca-core'),
                    '4' => esc_html__('04: Loan Slider', 'banca-core'),
                ],
                'default' => '1'
            ]
        );

        $this->end_controls_section(); //End Style


        //============================ Info Boxes ===========================//
        $this->start_controls_section(
            'info_boxes_sec', [
                'label' => __('Info Boxes', 'banca-core'),
                'condition' => [
                    'style' => [ '1', '2', '3']
                ]
            ]
        );

        $this->add_control(
            'image1', [
                'label' => __('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'image2', [
                'label' => __('Hover Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'How much do you need?',
            ]
        );

        $this->add_control(
            'currency', [
                'label' => __('Currency', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '$',
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'loan_amount', [
                'label' => __('Loan Amount', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '5,000',
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        //Loan Type Style 02
        $loan_type = new Repeater();
        $loan_type->add_control(
            'loan_type', [
                'label' => __('Loan Types', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Home Loan',
            ]
        );

        $this->add_control(
            'loan_types', [
                'label' => __('Add Loan Type', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $loan_type->get_controls(),
                'title_field' => '{{{ loan_type }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => ['2', '3']
                ],
                'separator' => 'before'
            ]
        );

        $this->end_controls_section(); //End Info Boxes


        //============================ Slider Info Boxes ===========================//
        $this->start_controls_section(
            'sec_slider_info', [
                'label' => __('Slider', 'banca-core'),
                'condition' => [
                    'style' => [ '4' ]
                ]
            ]
        );

        //Loan Type Style 04
        $loan_type = new Repeater();
        $loan_type->add_control(
            'img', [
                'label' => __('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $loan_type->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Installment Loans',
            ]
        );

        $loan_type->add_control(
            'content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'loan_sliders', [
                'label' => __('Add Loan Type', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $loan_type->get_controls(),
                'title_field' => '{{{ title }}}',
                'prevent_empty' => false,
                'separator' => 'before'
            ]
        );

        $this->end_controls_section(); //End Slider


    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control() {

        //=================== Title =================
        $this->start_controls_section(
            'style_contents', [
                'label' => esc_html__( 'Contents', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => [ '4']
                ]
            ]
        );

        //==== Title Options
        $this->add_control(
            'title_heading', [
                'label' => esc_html__( 'Title Options', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .__title',
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => esc_html__( 'Text Color', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
                ],
            ]
        ); //End Title Options


        //==== Contents Options
        $this->add_control(
            'content_heading', [
                'label' => esc_html__( 'Content Options', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'content_typo',
                'selector' => '{{WRAPPER}} .__content',
            ]
        );

        $this->add_control(
            'content_color', [
                'label' => esc_html__( 'Text Color', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__content' => 'color: {{VALUE}}',
                ],
            ]
        ); //End Content

        $this->end_controls_section(); //End Title



    }

    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        extract($settings); //Array to variable conversion

        //================== Templates Parts ==================
        include "template/loan/loan-{$settings['style']}.php";

    }
}