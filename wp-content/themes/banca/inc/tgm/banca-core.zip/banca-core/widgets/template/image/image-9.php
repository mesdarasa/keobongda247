<section class="map_area">
    <div class="map_inner">
        <?php echo wp_get_attachment_image( $settings['map_image']['id'], 'full', ''); ?>
        <ul class="list-unstyled map_list">
        <?php
        if ( $settings['map_flag_list'] ) {
            foreach ( $settings['map_flag_list'] as $index => $image ) {
            
            ?>
            <li class="active wow zoomIn" data-wow-delay="0.2s">
                <?php echo wp_get_attachment_image( $image['map_flag']['id'], 'full', ''); ?>
            </li>

            <?php
                }
            }
            ?>
        </ul>
    </div>
</section>