<div class="loan-apply-widget wow fadeInRight" data-wow-delay="0.5s">
    <div class="icon">
        <?php
        echo !empty($settings['image1']['id']) ? wp_get_attachment_image($settings['image1']['id']) : '';
        echo !empty($settings['image2']['id']) ? wp_get_attachment_image($settings['image2']['id']) : '';
        ?>
    </div>
    <div class="apply-content">
        <?php
        if ( !empty($settings['title']) ) { ?>
            <span class="title"><?php echo esc_html($settings['title']) ?></span>
            <?php
        }

        if ( !empty($settings['loan_types']) ) { ?>
            <div class="select-location d-flex align-items-center"
                 id="locationSlectParent">
                <select class="w-100" name="select-location" id="locationSelect">
                    <?php
                    foreach ( $settings['loan_types'] as $loan_type ) {
                        ?>
                        <option value="<?php echo esc_attr($loan_type['loan_type']) ?>">
                            <?php echo esc_html($loan_type['loan_type']) ?>
                        </option>
                        <?php
                    }
                    ?>
                </select>
                <span class="close" id="readOnlyClose">
                    <i class="icon_close"></i>
                </span>
            </div>
            <?php
        }
        ?>
    </div>
</div>