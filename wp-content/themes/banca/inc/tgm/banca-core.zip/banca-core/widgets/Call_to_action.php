<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Group_Control_Background,
    Repeater
};

/**
 * Class Call_to_action
 * @package BancaCore\Widgets
 */
class Call_to_action extends Widget_Base {
    public function get_name() {
        return 'banca_call_to_action';
    }

    public function get_title() {
        return __('Call to Action (Banca)', 'banca-core');
    }

    public function get_icon() {
        return 'eicon-call-to-action';
    }

    public function get_categories() {
        return ['banca-elements'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls() {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control() {


        //============================= Style ================================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Border Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('Style 01', 'banca-core'),
                    '2' => __('Style 02', 'banca-core'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Style


        //============================== Section Title ===============================//
        $this->start_controls_section(
            'title_sec', [
                'label' => __('Title', 'banca-core'),
            ]
        );

        $this->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Have any question?',
            ]
        );

        $this->add_control(
            'subtitle', [
                'label' => __('Subtitle', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->end_controls_section(); // End Section Title


        //============================== Section Button ===============================//
        $this->start_controls_section(
            'button_sec', [
                'label' => __('Button', 'banca-core'),
            ]
        );

        $this->add_control(
            'btn_title', [
                'label' => __('Button Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Contact Us',
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'btn_url', [
                'label' => __('Button URL', 'banca-core'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ],
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        //===== Button Repeater
        $button = new Repeater();
        $button->add_control(
            'btn_title1', [
                'label' => __('Button Title 01', 'plugin-domain'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'GET IT ON'
            ]
        );

        $button->add_control(
            'btn_title2', [
                'label' => __('Button Title 02', 'plugin-domain'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Google Play'
            ]
        );

        $button->add_control(
            'btn_url', [
                'label' => __('Button URL', 'plugin-domain'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ]
            ]
        );

        $button->add_control(
            'btn_icon', [
                'label' => __('Icon', 'text-domain'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-google-play',
                    'library' => 'solid',
                ],
            ]
        );

        $this->add_control(
            'buttons', [
                'label' => __('Create Button', 'plugin-domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $button->get_controls(),
                'title_field' => '{{{ btn_title1 }}}',
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $this->end_controls_section(); // End Button Title

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control() {


        //========================== Title Section ============================//
        $this->start_controls_section(
            'title_style', [
                'label' => __('Title', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //=======Title
        $this->add_control(
            'title_heading', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .cta-content h2',
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-content h2' => 'color: {{VALUE}};',
                ]
            ]
        );

        //=======Sub Title
        $this->add_control(
            'sub_title_heading', [
                'label' => esc_html__('Sub Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'sub_title_typo',
                'selector' => '{{WRAPPER}} .cta-content p',
            ]
        );

        $this->add_control(
            'sub_title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-content p' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->end_controls_section(); //End Title Section


        //============================ Button Section =================================//
        $this->start_controls_section(
            'button_style', [
                'label' => __('Button', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'button_typo',
                'selector' => '{{WRAPPER}} .theme-btn.theme-btn-alt',
            ]
        );

        //Normal Tab
        $this->start_controls_tabs('button_tabs');
        $this->start_controls_tab(
            'button_normal_tab',
            [
                'label' => __('Normal', 'plugin-name'),
            ]
        );

        $this->add_control(
            'button_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn.theme-btn-alt' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'button_bg',
                'label' => __('Background', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .theme-btn.theme-btn-alt',
            ]
        );

        $this->end_controls_tab();

        //Hover Tab
        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => __('Hover', 'plugin-name'),
            ]
        );

        $this->add_control(
            'button_hover_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn.theme-btn-alt:hover' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'button_hove_bg',
                'label' => __('Background', 'banca-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .theme-btn::before',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();


        $this->end_controls_section(); //End Button Section


        //=========================== Shape Images ============================//
        $this->start_controls_section(
            'shape_images', [
                'label' => __('Shapes', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'shape1', [
                'label' => __('Shape 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape2', [
                'label' => __('Shape 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape3', [
                'label' => __('Shape 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape4', [
                'label' => __('Shape 04', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape5', [
                'label' => __('Shape 05', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape6', [
                'label' => __('Shape 06', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section(); // End Shape Images



        //============================ Section Background ==============================//
        $this->start_controls_section(
            'sec_background', [
                'label' => __('Section Background', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sec_margin', [
                'label' => esc_html__( 'Margin', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .banca_sec' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sec_padding', [
                'label' => esc_html__( 'Padding', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .banca_sec' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'style_bg',
                'label' => __('Background', 'plugin-domain'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .banca_sec',
            ]
        );

        $this->end_controls_section(); // End Section Background


    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        //Include Part
        include "template/call-to-action/c2a-{$settings['style']}.php";

    }

}