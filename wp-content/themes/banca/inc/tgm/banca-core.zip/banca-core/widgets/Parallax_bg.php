<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Parallax_bg
 * @package BancaCore\Widgets
 */
class Parallax_bg extends Widget_Base
{

    public function get_name()
    {
        return 'banca_parallax_bg';
    }

    public function get_title()
    {
        return __('Parallax Background (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-parallax';
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {

        //============================ Content ===========================//
        $this->start_controls_section(
            'content_sec', [
                'label' => __('Content', 'banca-core'),
            ]
        );

        $this->add_control(
            'image', [
                'label' => __('Image Icon', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'contents', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::WYSIWYG,
            ]
        );

        $this->end_controls_section();

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        //============================ Contents =================================//
        $this->start_controls_section(
            'para_bg_contents', [
                'label' => __('Contents', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Title
        $this->add_control(
            'para_bg_content_title', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'para_bg_content_title_typo',
                'selector' => '{{WRAPPER}} .security-area .security-priority h2',
            ]
        );

        $this->add_control(
            'para_bg_content_title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .security-area .security-priority h2' => 'color: {{VALUE}};',
                ]
            ]
        );


        // Contents
        $this->add_control(
            'para_bg_content_min', [
                'label' => esc_html__('Contents', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'para_bg_content_min_typo',
                'selector' => '{{WRAPPER}} .security-area .security-priority p',
            ]
        );

        $this->add_control(
            'para_bg_content_min_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .security-area .security-priority p' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->end_controls_section(); //End Contents


        //============================ Shape Images =================================//
        $this->start_controls_section(
            'shape_images', [
                'label' => __('Shape Images', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'shape1', [
                'label' => __('Shape 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape2', [
                'label' => __('Shape 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape3', [
                'label' => __('Shape 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape4', [
                'label' => __('Shape 04', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape5', [
                'label' => __('Shape 05', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape6', [
                'label' => __('Shape 06', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape7', [
                'label' => __('Shape 07', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape8', [
                'label' => __('Shape 08', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'shape9', [
                'label' => __('Shape 09', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section();


        //=========================== Section Background ===========================//
        $this->start_controls_section(
            'sec_bg_style', [
                'label' => __('Background', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'sec_bg',
                'label' => __('Background', 'plugin-domain'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .security-area .security-priority',
            ]
        );

        $this->end_controls_section();

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="security-area">
            <div class="security-priority pt-90 pb-95 text-center">
                <div class="shapes">
                    <?php
                    banca_el_image($settings['shape1'], 'shape');
                    banca_el_image($settings['shape2'], 'shape');
                    banca_el_image($settings['shape3'], 'shape');
                    banca_el_image($settings['shape4'], 'shape');
                    banca_el_image($settings['shape5'], 'shape');
                    banca_el_image($settings['shape6'], 'shape');
                    banca_el_image($settings['shape7'], 'shape');
                    echo wp_get_attachment_image($settings['shape8']['id'], 'full', false, array('data-parallax' => '{"x": -60, "y": 150, "rotateZ":-15}'));
                    echo wp_get_attachment_image($settings['shape9']['id'], 'full', false, array('data-parallax' => '{"x": 0, "y": -150, "rotateZ":0}'));
                    ?>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 mx-auto">
                            <?php banca_el_image($settings['image'], 'icon'); ?>
                            <h2 class="mt-4 mb-3"><?php echo esc_html($settings['title']) ?></h2>
                            <?php echo !empty($settings['contents']) ? banca_core_kses_post(wpautop($settings['contents'])) : '' ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }

}