<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Loan_calculator
 * @package BancaCore\Widgets
 */
class Loan_calculator extends Widget_Base
{

    public function get_name()
    {
        return 'banca_loan_calculator';
    }

    public function get_title()
    {
        return __('Loan Calculator (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-counter-circle';
    }

    public function get_style_depends() {
        return ['fancybox', 'editable-select', 'nouislider', 'flatpickr', 'slick', 'slick-theme'];
    }

    public function get_script_depends() {
        return ['fancybox', 'editable-select', 'nouislider', 'flatpickr', 'wNumb', 'slick'];
    }

    public function get_categories() {
        return ['banca-elements'];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control() {

        //============================ Select Style ===========================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Select Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('01: Loan Calculator', 'banca-core'),
                    '2' => __('02: Loan Calculator', 'banca-core'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Style


        //============================ Loan Amount ===========================//
        $this->start_controls_section(
            'loan_amount_sec', [
                'label' => __('Loan Amount', 'banca-core'),
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'loan_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Loan Amount',
            ]
        );

        $this->add_control(
            'loan_amount_currency', [
                'label' => __('Currency', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '$',
            ]
        );

        $this->add_control(
            'loan_amount_start_value', [
                'label' => __('Loan Amount Default', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => ' 15000',
            ]
        );

        $this->add_control(
            'loan_amount_value', [
                'label' => __('Loan Amount (Start-End)', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '5000, 25000, 50000, 75000, 100000, 125000, 150000',
                'description' => esc_html__('Enter the loan amount. Input the multiple value with comma and space separated', 'banca-core'),
            ]
        );

        $this->add_control(
            'loan_suffix', [
                'label' => __('Suffix', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'k',
            ]
        );

        $this->end_controls_section(); //End Loan Amount


        //============================ Loan Duration 01 ===========================//
        $this->start_controls_section(
            'loan_duration_sec', [
                'label' => __('Loan Duration & Interest Rate', 'banca-core'),
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'duration_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Loan Duration',
            ]
        );


        //Loan Duration Tabs
        $this->start_controls_tabs(
            'duration_tabs'
        );

        //================== Monthly Tab
        $this->start_controls_tab(
            'monthly_tabs_sec', [
                'label' => __('Monthly', 'plugin-name'),
            ]
        );

        $this->add_control(
            'monthly_tab_title', [
                'label' => __('Tab Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Month',
            ]
        );

        $this->add_control(
            'monthly_tab_start_mo_no', [
                'label' => __('Start Month Number', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '18',
            ]
        );

        $this->add_control(
            'monthly_tab_duration_label', [
                'label' => __('Duration Label', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Months',
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'number_of_month', [
                'label' => __('Month Number', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '12',
            ]
        );

        $repeater->add_control(
            'monthly_interest_rate', [
                'label' => __('Interest Rate (%)', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '4',
            ]
        );

        $this->add_control(
            'monthly_loan', [
                'label' => esc_html__('Add Monthly Loan', 'plugin-name'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ number_of_month }}}',
                'prevent_empty' => false,
                'separator' => 'before'
            ]
        );

        $this->end_controls_tab(); //End Monthly Tab


        //================== Yearly Tab
        $this->start_controls_tab(
            'yearly_tabs_sec', [
                'label' => __('Yearly', 'plugin-name'),
            ]
        );

        $this->add_control(
            'yearly_tab_title', [
                'label' => __('Tab Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Year',
            ]
        );

        $this->add_control(
            'yearly_tab_start_mo_no', [
                'label' => __('Start Yearly Number', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '2',
            ]
        );

        $this->add_control(
            'yearly_tab_duration_label', [
                'label' => __('Duration Label', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Years',
            ]
        );


        $repeater = new Repeater();
        $repeater->add_control(
            'number_of_year', [
                'label' => __('Number of Year', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '2',
            ]
        );

        $repeater->add_control(
            'yearly_interest_rate', [
                'label' => __('Interest Rate (%)', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '4',
            ]
        );

        $this->add_control(
            'yearly_loan', [
                'label' => esc_html__('Add Yearly Loan', 'plugin-name'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ number_of_year }}}',
                'prevent_empty' => false,
                'separator' => 'before'
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs(); //End Loan Duration Tabs

        $this->end_controls_section(); //Loan Duration Style 01



        //============================ Loan Duration Style 02 ===========================//
        $this->start_controls_section(
            'loan_duration_sec2', [
                'label' => __('Loan Duration & Interest Rate', 'banca-core'),
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $this->add_control(
            'loan_amount_currency2', [
                'label' => __('Currency', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '$',
            ]
        );

        //Loan Duration Tabs
        $this->start_controls_tabs(
            'duration_tabs2'
        );

        //================== Yearly Tab
        $this->start_controls_tab(
            'yearly_tabs_sec2', [
                'label' => __('Tab 01', 'plugin-name'),
            ]
        );

        $this->add_control(
            'yearly_tab_title1', [
                'label' => __('Tab Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Yearly',
            ]
        );

        $this->add_control(
            'yearly_tab_start_loan_duration', [
                'label' => __('Start Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '5',
            ]
        );


        $this->add_control(
            'yearly_tab_min_loan_duration', [
                'label' => __('Minimum Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '2',
            ]
        );


        $this->add_control(
            'yearly_tab_max_loan_duration', [
                'label' => __('Maximum Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '8',
            ]
        ); //End Loan Duration Options

        $this->end_controls_tab();//End Yearly Tab


        //================== Monthly Tab
        $this->start_controls_tab(
            'monthly_tabs_sec2', [
                'label' => __('Tab 02', 'plugin-name'),
            ]
        );

        $this->add_control(
            'monthly_tab_title1', [
                'label' => __('Tab Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Monthly',
            ]
        );

        $this->add_control(
            'monthly_tab_start_loan_duration', [
                'label' => __('Start Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '5',
            ]
        );

        $this->add_control(
            'monthly_tab_min_loan_duration', [
                'label' => __('Minimum Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '2',
            ]
        );

        $this->add_control(
            'monthly_tab_max_loan_duration', [
                'label' => __('Maximum Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '8',
            ]
        ); //End Loan Duration Options

        $this->end_controls_tab();//End Monthly Tab



        //================== Weekly Tab
        $this->start_controls_tab(
            'weekly_tabs_sec2', [
                'label' => __('Tab 03', 'plugin-name'),
            ]
        );

        $this->add_control(
            'weekly_tab_title1', [
                'label' => __('Tab Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Weekly',
            ]
        );

        $this->add_control(
            'weekly_tab_start_loan_duration', [
                'label' => __('Start Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '5',
            ]
        );

        $this->add_control(
            'weekly_tab_min_loan_duration', [
                'label' => __('Minimum Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '2',
            ]
        );

        $this->add_control(
            'weekly_tab_max_loan_duration', [
                'label' => __('Maximum Loan Duration', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '8',
            ]
        ); //End Loan Duration Options

        $this->end_controls_tab();//End Monthly Tab
        $this->end_controls_tabs(); //End Loan Duration Tabs

        //============== Loan Amount Options
        $this->add_control(
            'yearly_tab_loan_amount_heading', [
                'label' => __('Loan Amount Options', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'yearly_tab_start_loan2', [
                'label' => __('Start Loan Amount ', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'step' => 1000,
                'default' => '15000',
            ]
        );


        $this->add_control(
            'yearly_tab_min_loan2', [
                'label' => __('Minimum Loan Amount', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'step' => 1000,
                'default' => '5000',
            ]
        );

        $this->add_control(
            'yearly_tab_max_loan2', [
                'label' => __('Maximum Loan Amount', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'step' => 1000,
                'default' => '150000',
            ]
        ); //End Loan Amount Options


        //============== Interest Rate Options
        $this->add_control(
            'yearly_tab_interest_rate_heading', [
                'label' => __('Interest Rate Options', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'yearly_tab_start_interest_rate', [
                'label' => __('Start Interest Rate', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'step' => 1,
                'default' => '8',
            ]
        );

        $this->add_control(
            'yearly_tab_min_interest_rate', [
                'label' => __('Minimum Interest Rate', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'step' => 1,
                'default' => '5',
            ]
        );

        $this->add_control(
            'yearly_tab_max_interest_rate', [
                'label' => __('Maximum Interest Rate', 'banca-core'),
                'type' => Controls_Manager::NUMBER,
                'step' => 1,
                'default' => '30',
            ]
        ); //End Interest Rate Options

        $this->end_controls_section(); //Loan Duration Style 02


        //============================ Interest Rate ===========================//
        $this->start_controls_section(
            'interest_rate_sec', [
                'label' => __('Interest Rate', 'banca-core'),
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        $this->add_control(
            'interest_rate_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Rate of Interest',
            ]
        );

        $this->end_controls_section(); //End Interest Rate


        //============================ EMI Calculation ===========================//
        $this->start_controls_section(
            'emi_calculation_sec', [
                'label' => __('EMI Calculation', 'banca-core'),
                'condition' => [
                    'style' => '1'
                ]
            ]
        );

        //================ EMI Amount
        $this->add_control(
            'emi_amount_heading', [
                'label' => __('EMI Amount', 'banca-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'emi_amount_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'EMI Amount',
            ]
        );

        $this->add_control(
            'emi_amount_subtitle', [
                'label' => __('Subtitle', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Principal + Interest',
            ]
        );


        //================ Interest Payable
        $this->add_control(
            'emi_interest_heading', [
                'label' => __('EMI Interest', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'emi_interest_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Interest Payable',
            ]
        );


        //================ EMI Total Amount
        $this->add_control(
            'emi_total_amount_heading', [
                'label' => __('Total EMI Amount', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'emi_total_amount_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Your EMI Amount',
            ]
        );

        $this->end_controls_section(); //End EMI Calculation


        //============================ Button ===========================//
        $this->start_controls_section(
            'button_sec', [
                'label' => __('Button', 'banca-core'),
            ]
        );

        //================ EMI Amount
        $this->add_control(
            'btn_label', [
                'label' => __('Button Label', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Apply Now'
            ]
        );


        $this->add_control(
            'btn_url', [
                'label' => __('Button URL', 'banca-core'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ],
                'separator' => 'after'
            ]
        );


        // Button Style
        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
            ]
        );

        $this->start_controls_tabs(
            'style_btn_tabs'
        );

        // Normal Tab
        $this->start_controls_tab(
            'btn_normal_tab', [
                'label' => esc_html__('Normal', 'plugin-name'),
            ]
        );

        $this->add_control(
            'btn_normal_text_color', [
                'label' => esc_html__('Text Color', 'plugin-name'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_normal_bg_color', [
                'label' => esc_html__('Background Color', 'plugin-name'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab(
            'btn_hover_tab', [
                'label' => esc_html__('Hover', 'plugin-name'),
            ]
        );

        $this->add_control(
            'btn_hover_text_color', [
                'label' => esc_html__('Text Color', 'plugin-name'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_bg_color', [
                'label' => esc_html__('Background Color', 'plugin-name'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-btn::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs(); //End Button Style Tabs


        $this->end_controls_section(); //End Button


    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        //============================ Style Step Item List =================================//
        $this->start_controls_section(
            'style_step_item_list', [
                'label' => __('Step Contents', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => __('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => __('Typography', 'plugin-domain'),
                'selector' => '{{WRAPPER}} .title',
            ]
        );

        $this->end_controls_section(); //End Style Step Item List

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        extract($settings);


        $currency = !empty($settings['loan_amount_currency2']) ? $settings['loan_amount_currency2'] : '$';

        //=========================== Template Parts ===========================//
        include "template/calculator/calculator-{$settings['style']}.php";

    }
}