<section class="banner-area-5 banca-hero dark_mode_sec_wrap" id="banner_animation">
    <div class="bg-shapes">
        <?php
        if (!empty($settings['shape1']['id'])) {
            echo wp_get_attachment_image($settings['shape1']['id'], 'full', '', array('data-parallax' => '{ "x": -30,"y": 90,"rotateZ":50}', 'class' => 'shape'));
        }
        if (!empty($settings['shape2']['id'])) {
            echo wp_get_attachment_image($settings['shape2']['id'], 'full', '', array('data-parallax' => '{ "y": -250}', 'class' => 'shape'));
        }
        if (!empty($settings['shape3']['id'])) {
            echo wp_get_attachment_image($settings['shape3']['id'], 'full', '', array('data-parallax' => '{"x": -40, "y": -150}', 'class' => 'shape'));
        }
        if (!empty($settings['shape4']['id'])) {
            echo wp_get_attachment_image($settings['shape4']['id'], 'full', '', array('data-parallax' => '{"x": 300, "y": 370, "rotateZ":200}', 'class' => 'shape'));
        }
        ?>
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <div class="container">
        <div class="row align-items-end">
            <div class="col-lg-6">
                <div class="banner-content wow fadeInRight" data-wow-delay="0.1s">
                    <?php
                    if ($title != '') { ?>
                        <h1 class="__title"><?php echo Banca_Core_Helper()->kses_post($settings['title']) ?></h1>
                        <?php
                    }
                    if ($subtitle != '') { ?>
                        <p class="__subtitle"><?php echo esc_html($subtitle) ?></p>
                        <?php
                    }
                    if (!empty($settings['buttons'])) {
                        ?>
                        <div class="d-flex flex-wrap mt-40">
                            <?php
                            foreach ($settings['buttons'] as $index => $button) {
                                $btn_class = $index % 2 == 0 ? 'theme-btn me-4' : 'under_link';
                                ?>
                                <a <?php Banca_Core_Helper()->the_button($button['btn_url']) ?>
                                        class="<?php echo esc_attr($btn_class) ?> elementor-repeater-item-<?php echo $button['_id'] ?>">
                                    <?php echo esc_html($button['btn_label']) ?>
                                    <?php \Elementor\Icons_Manager::render_icon($button['btn_icon']); ?>
                                </a>

                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }
                    if ($logo_title != '') { ?>
                        <div class="co-operators">
                            <p class="mb-4 __logo_title"><?php echo esc_html($logo_title) ?></p>
                            <div class="d-flex flex-wrap">
                                <?php
                                if (!empty($logos)) {
                                    foreach ($logos as $item) {
                                        banca_el_image($item['logo'], 'logo');
                                    }
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="basic-loan-calculator wow fadeInLeft" data-wow-delay="0.1s">
                    <?php
                    if (!empty($settings['shape5']['id'])) {
                        echo wp_get_attachment_image($settings['shape5']['id'], 'full', '', array('class' => 'shape'));
                    }
                    if ($calculator_title != '') { ?>
                        <h4 class="__cal_title"><?php echo esc_html($calculator_title) ?></h4>
                        <?php
                    }
                    if ($calculator_form != '') {
                        echo do_shortcode($calculator_form);
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>