<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};



/**
 * Class Testimonials
 * @package BancaCore\Widgets
 */
class Testimonials extends Widget_Base
{
    public function get_name()
    {
        return 'banca_testimonials';
    }

    public function get_title()
    {
        return esc_html__('Testimonials (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-testimonial';
    }

    public function get_style_depends()
    {
        return ['slick', 'slick-theme', 'fancybox'];
    }

    public function get_script_depends()
    {
        return ['slick', 'fancybox'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    protected function register_controls() {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: register_controls
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @landpagy
     * Author: spider-themes
     */
    public function elementor_content_control()
    {

        //============================== Select Style ===============================//
        $this->start_controls_section(
            'select_style', [
                'label' => esc_html__('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => esc_html__('Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('01: Testimonials with Ratting', 'banca-core'),
                    '2' => esc_html__('02: Testimonials with Video', 'banca-core'),
                    '3' => esc_html__('03: Testimonials with Video', 'banca-core'),
                    '4' => esc_html__('04: Testimonials', 'banca-core'),
                    '5' => esc_html__('05: Testimonials Loan Slier (Deprecated Style)', 'banca-core'),
                ],
                'default' => '1'
            ]
        );

        $this->end_controls_section(); // End Style


        //============================== Section Title  ===============================//
        $this->start_controls_section(
            'sec_title', [
                'label' => esc_html__('Title', 'banca-core'),
                'condition' => [
                    'style' => ['1', '2']
                ]
            ]
        );

        $this->add_control(
            'title', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->end_controls_section(); // End Section Title


        //============================== Testimonials 01 ===============================//
        $this->start_controls_section(
            'testimonials_sec', [
                'label' => esc_html__('Testimonials', 'banca-core'),
            ]
        );

        // Testimonials 01, 04
        $testimonials = new Repeater();
        $testimonials->add_control(
            'image', [
                'label' => esc_html__('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $testimonials->add_control(
            'name', [
                'label' => esc_html__('Name', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Arif Rahman',
                'label_block' => true
            ]
        );

        $testimonials->add_control(
            'designation', [
                'label' => esc_html__('Designation', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $testimonials->add_control(
            'quote', [
                'label' => esc_html__('Quote', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $testimonials->add_control(
            'ratting', [
                'label' => esc_html__('Ratting', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1 Star', 'banca-core'),
                    '2' => esc_html__('2 Star', 'banca-core'),
                    '3' => esc_html__('3 Star', 'banca-core'),
                    '4' => esc_html__('4 Star', 'banca-core'),
                    '5' => esc_html__('5 Star', 'banca-core'),
                ],
                'default' => '5',
            ]
        );

        $this->add_control(
            'testimonials', [
                'label' => esc_html__('Add Testimonial', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $testimonials->get_controls(),
                'title_field' => '{{{ name }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => ['1', '4']
                ]
            ]
        ); //End Testimonials 01, 04


        $testimonials2 = new Repeater();
        $testimonials2->add_control(
            'image', [
                'label' => esc_html__('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $testimonials2->add_control(
            'video_url', [
                'label' => esc_html__('Video URL', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '#',
                'label_block' => true
            ]
        );

        $testimonials2->add_control(
            'name', [
                'label' => esc_html__('Name', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Arif Rahman',
                'label_block' => true
            ]
        );

        $testimonials2->add_control(
            'designation', [
                'label' => esc_html__('Designation', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $testimonials2->add_control(
            'quote', [
                'label' => esc_html__('Quote', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'testimonials2', [
                'label' => esc_html__('Add Testimonial', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $testimonials2->get_controls(),
                'title_field' => '{{{ name }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => '2'
                ]
            ]
        ); //End Testimonials 02


        // Testimonials 03
        $testimonials3 = new Repeater();
        $testimonials3->add_control(
            'title', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Making dreams a reality!',
                'label_block' => true
            ]
        );

        $testimonials3->add_control(
            'image', [
                'label' => esc_html__('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $testimonials3->add_control(
            'name', [
                'label' => esc_html__('Name', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Arif Rahman',
                'label_block' => true,
            ]
        );

        $testimonials3->add_control(
            'designation', [
                'label' => esc_html__('Designation', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Web Developer',
            ]
        );

        $testimonials3->add_control(
            'quote', [
                'label' => esc_html__('Quote', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $testimonials3->add_control(
            'video_title', [
                'label' => esc_html__('Video Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'watch the video',
                'separator' => 'before'
            ]
        );

        $testimonials3->add_control(
            'video_title_url', [
                'label' => esc_html__('Video URL', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '#'
            ]
        );

        $this->add_control(
            'testimonials3', [
                'label' => esc_html__('Add Testimonial', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $testimonials3->get_controls(),
                'title_field' => '{{{ name }}}',
                'prevent_empty' => false,
                'condition' => [
                    'style' => '3'
                ]
            ]
        ); //End Testimonials 03

         // Testimonials 05
         $testimonials5 = new Repeater();
         $testimonials5->add_control(
             'title', [
                 'label' => esc_html__('Title', 'banca-core'),
                 'type' => Controls_Manager::TEXT,
                 'default' => 'Making dreams a reality!',
                 'label_block' => true
             ]
         );
 
         $testimonials5->add_control(
             'image', [
                 'label' => esc_html__('Image', 'banca-core'),
                 'type' => Controls_Manager::MEDIA,
                 'default' => [
                     'url' => Utils::get_placeholder_image_src(),
                 ],
             ]
         );
 
         $testimonials5->add_control(
             'testimonial_title', [
                 'label' => esc_html__('Title', 'banca-core'),
                 'type' => Controls_Manager::TEXT,
                 'default' => 'Personal Loans',
                 'label_block' => true,
             ]
         );
 
         $testimonials5->add_control(
             'testimonial_content', [
                 'label' => esc_html__('Content', 'banca-core'),
                 'type' => Controls_Manager::TEXTAREA,
                 'label_block' => true,
                 'default' => 'Our team of experts uses methodology
                 identify the credit cards most.',
             ]
         );
         
 
         $this->add_control(
             'testimonials5', [
                 'label' => esc_html__('Add Testimonial', 'banca-core'),
                 'type' => Controls_Manager::REPEATER,
                 'fields' => $testimonials5->get_controls(),
                 'title_field' => '{{{ name }}}',
                 'prevent_empty' => false,
                 'condition' => [
                     'style' => '5'
                 ]
             ]
         ); //End Testimonials 05

 
 
         $this->end_controls_section(); // End Testimonials 01, 02, 03, 04, 05

    }


    /***
     *
     * @@@
     * Style Tabs
     * Developer by Arif Rahman
     * @@@
     *
     **/
    public function elementor_style_control() {

        //============================ Style Author Name =============================//
        $this->start_controls_section(
            'style_sec_title', [
                'label' => esc_html__('Title', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => [ '2' ]
                ]
            ]
        );

        $this->add_control(
            'sec_title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__sec_title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'sec_title_typo',
                'selector' => '{{WRAPPER}} .__sec_title',
            ]
        );


        $this->end_controls_section();//End Style Section Title


        //============================ Style Testimonials =============================//
        $this->start_controls_section(
            'testimonials_style', [
                'label' => esc_html__('Testimonials', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['1', '2', '3']
                ]
            ]
        );

        //============== Author Name
        $this->add_control(
            'style_author_name_options', [
                'label' => esc_html__('Author Name', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'author_name_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__name' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'author_active_color', [
                'label' => esc_html__('Active Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h6.__name' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'style' => [ '2', '3']
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'author_name_typo',
                'selector' => '{{WRAPPER}} .__name',
            ]
        );

        //============== Designation
        $this->add_control(
            'style_designation', [
                'label' => esc_html__('Designation', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'designation_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__designation' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'designation_active_color', [
                'label' => esc_html__('Active Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-widget-3 .client-info span' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'style' => [ '2', '3' ]
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'designation_typo',
                'selector' => '{{WRAPPER}} .__designation',
            ]
        );

        $this->end_controls_section(); // End author name section


        //============================ Style Quote Area =============================//
        $this->start_controls_section(
            'quote_style', [
                'label' => esc_html__('Quote Section', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //==================== Icon
        $this->add_control(
            'style_icon', [
                'label' => esc_html__('Icon', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_color', [
                'label' => esc_html__('Icon Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .quote::after' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .testimonial-widget::after' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .testimonial-widget-3 .client-img .play-btn i' => 'background: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(), [
                'name' => 'icon_shadow',
                'label' => __('Icon Shadow', 'banca-core'),
                'selector' => '{{WRAPPER}} .testimonial-widget-3 .client-img .play-btn i',
                'condition' => [
                    'style' => ['2']
                ]
            ]
        );

        //============== Quote
        $this->add_control(
            'style_quote', [
                'label' => esc_html__('Quote', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'quote_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__review_content' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'quote_typo',
                'selector' => '{{WRAPPER}} .__review_content',
            ]
        );

        $this->end_controls_section(); // End Quote Area


        //====================== Testimonial style 4 =========================//
        $this->start_controls_section(
            'testimonials_style_4', [
                'label' => esc_html__('Testimonials', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['4']
                ]
            ]
        );

        $this->add_control(
            'background_content_4', [
                'label' => esc_html__('Content Background', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client' => 'background: {{VALUE}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'main_margin_4', [
                'label' => __('Item Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'item_padding', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after'
            ]
        );

        $this->add_control(
            'rating_colors', [
                'label' => esc_html__('Rating Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client .rating a' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'rating_typo',
                'selector' => '{{WRAPPER}} .client-slider-2 .single-client .rating a',
            ]
        );

        $this->add_control(
			'content_styles',
			[
				'label' => esc_html__( 'Content', 'banca-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
            'content_color_4', [
                'label' => esc_html__('Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client .quote' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'content_typo_4',
                'selector' => '{{WRAPPER}} .client-slider-2 .single-client .quote',
            ]
        );
        $this->add_responsive_control(
            'content_margin_4', [
                'label' => __('Content Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client .quote' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );
        $this->add_control(
			'author_style_4',
			[
				'label' => esc_html__( 'Author Style', 'banca-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
            'name_color_4', [
                'label' => esc_html__('Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client .client-info .name' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'name_typo_4',
                'selector' => '{{WRAPPER}} .client-slider-2 .single-client .client-info .name',
            ]
        );
        $this->add_responsive_control(
            'title_margin', [
                'label' => __('Title Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client .client-info .name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
			'designation_style_4',
			[
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
            'designation_color_4', [
                'label' => esc_html__('Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .client-slider-2 .single-client .client-info .designation' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'designation_typo_4',
                'selector' => '{{WRAPPER}} .client-slider-2 .single-client .client-info .designation',
            ]
        );


        $this->end_controls_section(); // Testimonial style 4

        $this->start_controls_section(
            'testimonials_style_5', [
                'label' => esc_html__('Style', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['5']
                ]
            ]
        );
        $this->add_control(
            'item_options', [
                'label' => __('Item Style', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'item_padding_5', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_style_five .client-slider .single-client' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'title_options', [
                'label' => __('Title Style', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'title_color', [
                'label' => __('Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial_style_five .client-slider .single-client .client-info .testimonial_title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '{{WRAPPER}} .testimonial_style_five .client-slider .single-client .client-info .testimonial_title',
            ]
        );
        $this->add_responsive_control(
            'title_padding', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_style_five .client-slider .single-client .client-info .testimonial_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'content_options', [
                'label' => __('Content Style', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'content_color', [
                'label' => __('Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial_style_five .client-slider .single-client .client-info .testimonial_content' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'content_typo',
                'selector' => '{{WRAPPER}} .testimonial_style_five .client-slider .single-client .client-info .testimonial_content',
            ]
        );

        $this->end_controls_section(); // Testimonial style 5

    }


    /**
     * Name: render
     * Desc: Widgets Render
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @landpagy
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        extract($settings); // Array to Variable Conversation

        // Include Style
        include "template/testimonials/testimonial-{$settings['style']}.php";
    }

}