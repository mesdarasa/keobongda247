<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Hero
 * @package BancaCore\Widgets
 */
class Hero extends Widget_Base
{
    public function get_name()
    {
        return 'banca_hero';
    }

    public function get_title()
    {
        return __('Hero Section (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-device-desktop';
    }

    public function get_script_depends()
    {
        return ['parallax-scroll', 'parallax'];
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control() {

        //================================= Hero Style =================================//
        $this->start_controls_section(
            'hero_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'plugin-domain'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('01: Hero', 'plugin-domain'),
                    '2' => __('02: Hero', 'plugin-domain'),
                    '3' => __('03: Hero', 'plugin-domain'),
                    '4' => __('04: Hero With Calculator Form', 'plugin-domain'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); // End Hero Style


        //===========================  Hero Contents Section ===============================//
        $this->start_controls_section(
            'hero_contents', [
                'label' => __('Hero Contents', 'banca-core'),
            ]
        );

        $this->add_control(
            'title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'subtitle', [
                'label' => __('Subtitle', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'separator' => 'before',
                'condition' => [
                    'style' => ['2', '4']
                ]
            ]
        );

        $this->end_controls_section(); // End Hero Content


        //================================= Featured Image ==================================//
        $this->start_controls_section(
            'f_img_sec', [
                'label' => __('Featured Image', 'banca-core'),
                'condition' => [
                    'style' => ['1', '2', '3']
                ]
            ]
        );

        $this->add_control(
            'f_img', [
                'label' => __('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        $this->end_controls_section(); // End Featured Image


        //================================= Clients Logo ==================================//
        $this->start_controls_section(
            'clients_logo', [
                'label' => __('Logos', 'banca-core'),
                'condition' => [
                    'style' => ['1', '4']
                ]
            ]
        );

        $this->add_control(
            'logo_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('We are cooperating with:', 'banca-core'),
                'condition' => [
                    'style' => '4'
                ]
            ]
        );

        $this->add_control(
            'logo_title_color', [
                'label' => __('Text Color', 'plugin-domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__logo_title' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'style' => '4'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'logo_title_typo',
                'selector' => '{{WRAPPER}} .__logo_title',
                'condition' => [
                    'style' => '4'
                ]
            ]
        );


        $client_logo = new Repeater();
        $client_logo->add_control(
            'align_items', [
                'type' => Controls_Manager::HIDDEN,
            ]
        );

        $client_logo->add_control(
            'logo', [
                'label' => __('Logo', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'logos', [
                'label' => __('Add Logo', 'plugin-domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $client_logo->get_controls(),
                'title_field' => '{{{ align_items }}}',
                'prevent_empty' => false
            ]
        );

        $this->end_controls_section(); // End Clients Logo


        //============================ Button ===============================//
        $this->start_controls_section(
            'button_sec', [
                'label' => __('Button', 'banca-core'),
                'condition' => [
                    'style' => ['2', '3', '4']
                ]
            ]
        );

        $buttons = new Repeater();
        $buttons->add_control(
            'btn_label', [
                'label' => __('Button Label', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Get Started'
            ]
        );

        $buttons->add_control(
            'btn_url', [
                'label' => __('Button URL', 'banca-core'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ]
            ]
        );

        $buttons->add_control(
            'btn_icon', [
                'label' => __('Icon', 'banca-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'arrow_right',
                    'library' => 'solid',
                ],
            ]
        );

        //===== Button Style
        $buttons->start_controls_tabs(
            'btn_style_tabs'
        );

        /// Normal Button Style
        $buttons->start_controls_tab(
            'style_normal_btn',
            [
                'label' => __('Normal', 'banca-core'),
            ]
        );

        $buttons->add_control(
            'font_color', [
                'label' => __('Font Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}',
                )
            ]
        );

        $buttons->add_control(
            'bg_color', [
                'label' => __('Background Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'background-color: {{VALUE}}; border-color: {{VALUE}}',
                )
            ]
        );

        $buttons->add_control(
            'border_color', [
                'label' => __('Border Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'border: 1px solid {{VALUE}}',
                )
            ]
        );

        $buttons->end_controls_tab();

        /// Hover Button Style
        $buttons->start_controls_tab(
            'style_hover_btn',
            [
                'label' => __('Hover', 'banca-core'),
            ]
        );

        $buttons->add_control(
            'hover_font_color', [
                'label' => __('Font Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'color: {{VALUE}}',
                )
            ]
        );

        $buttons->add_control(
            'hover_bg_color', [
                'label' => __('Background Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'background: {{VALUE}}',
                )
            ]
        );

        $buttons->add_control(
            'hover_border_color', [
                'label' => __('Border Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'border: 1px solid {{VALUE}}',
                )
            ]
        );

        $buttons->end_controls_tab();
        $buttons->end_controls_tabs();

        $buttons->add_responsive_control(
            'btn_padding', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $buttons->add_responsive_control(
            'btn_margin',
            [
                'label' => __('Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $buttons->add_responsive_control(
            'btn_border_radius',
            [
                'label' => __('Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'separator' => 'after',
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $buttons->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'btn_box_shadow',
                'label' => __('Box Shadow', 'banca-core'),
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
            ]
        );

        $buttons->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_typo',
                'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
            ]
        );


        $this->add_control(
            'buttons', [
                'label' => __('Create Button', 'plugin-domain'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $buttons->get_controls(),
                'title_field' => '{{{ btn_label }}}',
                'prevent_empty' => false
            ]
        );

        $this->end_controls_section(); // End Button


        //================================= Calculator Form ==================================//
        $this->start_controls_section(
            'calculator_form_sec', [
                'label' => __('Calculator Form', 'banca-core'),
                'condition' => [
                    'style' => '4'
                ]
            ]
        );

        $this->add_control(
            'calculator_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Loan calculator'
            ]
        );

        $this->add_control(
            'calculator_form', [
                'label' => __('Shortcode', 'banca-core'),
                'type' => Controls_Manager::TEXTAREA,
                'placeholder' => __('Enter Your Shortcode', 'banca-core'),
            ]
        );

        $this->end_controls_section(); // End Calculator Form

    }

    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        //===========================  Hero Contents Section ===============================//
        $this->start_controls_section(
            'hero_contents_style', [
                'label' => __('Hero Contents', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Title Options
        $this->add_control(
            'title_options', [
                'label' => __('Title Options', 'plugin-domain'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'title_color', [
                'label' => __('Text Color', 'plugin-domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'title_typo',
                'selector' => '
                    {{WRAPPER}} .__title',
            ]
        );

        // Subtitle Options
        $this->add_control(
            'subtitle_options', [
                'label' => __('Subtitle Options', 'plugin-domain'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'style' => [ '2', '4' ]
                ]
            ]
        );

        $this->add_control(
            'subtitle_color', [
                'label' => __('Text Color', 'plugin-domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__subtitle' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'style' => [ '2', '4' ]
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'subtitle_typo',
                'selector' => '{{WRAPPER}} .__subtitle',
                'condition' => [
                    'style' => [ '2', '4' ]
                ]
            ]
        );

        $this->end_controls_section(); // End Hero Content













        //=========================== Calculator Form Button ===============================//
        $this->start_controls_section(
            'style_calculator', [
                'label' => __('Calculator Form', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => '4'
                ]
            ]
        );

        // Title Options
        $this->add_control(
            'cal_title_options', [
                'label' => __('Title Options', 'plugin-domain'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'cal_title_color', [
                'label' => __('Text Color', 'plugin-domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__cal_title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'cal_title_typo',
                'selector' => '
                    {{WRAPPER}} .__cal_title',
            ]
        );

        // Label Text Options
        $this->add_control(
            'cal_label_text_options', [
                'label' => __('Form Label Options', 'plugin-domain'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'cal_label_text_color', [
                'label' => __('Text Color', 'plugin-domain'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .banner-area-5 .basic-loan-calculator form.forminator-ui .forminator-field .forminator-label' => 'color: {{VALUE}} !important;',
                ],
            ]
        );// End Label Text Options


        // Button Options
        $this->add_control(
            'cal_btn_options', [
                'label' => __('Button Options', 'plugin-domain'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        //===== Button Style
        $this->start_controls_tabs(
            'cal_btn_style_tabs'
        );

        /// Normal Button Style
        $this->start_controls_tab(
            'style_normal_cal_btn', [
                'label' => __('Normal', 'banca-core'),
            ]
        );

        $this->add_control(
            'cal_btn_font_color', [
                'label' => __('Font Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .banner-area-5 .basic-loan-calculator form.forminator-ui .forminator-button' => 'color: {{VALUE}} !important;',
                )
            ]
        );

        $this->add_control(
            'cal_btn_bg_color', [
                'label' => __('Background Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .banner-area-5 .basic-loan-calculator form.forminator-ui .forminator-button' => 'background-color: {{VALUE}} !important;',
                )
            ]
        );

        $this->end_controls_tab();

        /// Hover Button Style
        $this->start_controls_tab(
            'style_hover_cal_btn', [
                'label' => __('Hover', 'banca-core'),
            ]
        );

        $this->add_control(
            'cal_btn_hover_font_color', [
                'label' => __('Font Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .banner-area-5 .basic-loan-calculator form.forminator-ui .forminator-button:hover' => 'color: {{VALUE}} !important;',
                )
            ]
        );

        $this->add_control(
            'cal_btn_hover_bg_color', [
                'label' => __('Background Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .banner-area-5 .basic-loan-calculator form.forminator-ui .forminator-button::before' => 'background: {{VALUE}} !important;',
                )
            ]
        );

        $this->end_controls_tab(); // End Hover Button Style
        $this->end_controls_tabs(); // End Button Style


        $this->end_controls_section(); // End Calculator Form














        //================================= Shape Images ==================================//
        $this->start_controls_section(
            'shape_images', [
                'label' => __('Shape Images', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => ['2', '3', '4']
                ]
            ]
        );

        $this->add_control(
            'shape1', [
                'label' => __('Shape 01', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['2', '3', '4']
                ]
            ]
        );

        $this->add_control(
            'shape2', [
                'label' => __('Shape 02', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['2', '3', '4']
                ]
            ]
        );

        $this->add_control(
            'shape3', [
                'label' => __('Shape 03', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['2', '3', '4']
                ]
            ]
        );

        $this->add_control(
            'shape4', [
                'label' => __('Shape 04', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['2', '4']
                ]
            ]
        );

        $this->add_control(
            'shape5', [
                'label' => __('Shape 05', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => ['2', '4']
                ]
            ]
        );

        $this->add_control(
            'shape6', [
                'label' => __('Shape 06', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $this->add_control(
            'shape7', [
                'label' => __('Shape 07', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'style' => '2'
                ]
            ]
        );

        $this->end_controls_section(); // End Shape Images


        //----------------------------------- Style Background Section --------------------------------------//
        $this->start_controls_section(
            'style_bg_sec', [
                'label' => __('Background', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sec_margin', [
                'label' => __('Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .banca-hero' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sec_padding', [
                'label' => __('Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .banca-hero' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(), [
                'name' => 'background',
                'label' => __('Background', 'plugin-domain'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .banca-hero',
            ]
        );

        $this->end_controls_section(); //End Background Section

    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        extract($settings); //Array to Variable Conversation

        include "template/hero/hero-{$settings['style']}.php";

    }
}