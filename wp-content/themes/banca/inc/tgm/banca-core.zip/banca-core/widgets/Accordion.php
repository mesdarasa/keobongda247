<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Repeater
};


/**
 * Class Accordion
 * @package BancaCore\Widgets
 */
class Accordion extends Widget_Base
{

    public function get_name() {
        return 'banca_accordion';
    }

    public function get_title() {
        return __('Accordion (Banca)', 'banca-core');
    }

    public function get_icon() {
        return 'eicon-accordion';
    }

    public function get_categories() {
        return ['banca-elements'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls() {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control() {

        //============================ Style ===========================//
        $this->start_controls_section(
            'select_style', [
                'label' => __('Style', 'banca-core'),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __('Style', 'banca-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('01: Style', 'banca-core'),
                    '2' => __('02: Style', 'banca-core'),
                    '3' => __('03: Style', 'banca-core'),
                    '4' => __('04: Style', 'banca-core'),
                    '5' => __('05: Style', 'banca-core'),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section(); //End Style


        //============================ Accordion ===========================//
        $this->start_controls_section(
            'accordion_sec', [
                'label' => __('Accordion', 'banca-core'),
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'tab_title', [
                'label' => __('Title', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Accordion Title', 'banca-core'),
                'dynamic' => [
                    'active' => true,
                ],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tab_content', [
                'label' => __('Content', 'banca-core'),
                'type' => Controls_Manager::WYSIWYG,
                'default' => __('Accordion Content', 'banca-core'),
            ]
        );

        $this->add_control(
            'tabs', [
                'label' => __('Accordion Items', 'banca-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ tab_title }}}',
                'prevent_empty' => false,
            ]
        );

        $this->add_control(
			'show_icon',
			[
				'label' => esc_html__( 'Icon On/Off', 'banca-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'banca-core' ),
				'label_off' => esc_html__( 'Hide', 'banca-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->end_controls_section(); //End Accordion
    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {
        //============================ Style Accordion =============================//
        $this->start_controls_section(
            'accordion_style', [
                'label' => esc_html__('Accordion', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //============== Accordion Title
        $this->add_control(
            'accordion_title_style', [
                'label' => esc_html__('Title', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'accordion_title_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-widget-2 .faq-header h6.collapsed' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .faq-widget-2 .faq-header h6.collapsed i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .faq-widget .faq-header h4.collapsed' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'accordion_active_color', [
                'label' => esc_html__('Active Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-widget-2 .faq-header h6' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .faq-widget-2 .faq-header h6 i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .faq-widget .faq-header h4' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'accordion_title_typo',
                'selector' => '
                    {{WRAPPER}} .faq-widget-2 .faq-header h6,
                    {{WRAPPER}} .faq-widget .faq-header h4
                ',
            ]
        );

        //============== Accordion Description
        $this->add_control(
            'accordion_des_style', [
                'label' => esc_html__('Description', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'accordion_des_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-widget-2 .faq-body p' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .faq-widget .faq-body p' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'accordion_des_typo',
                'selector' => '
                    {{WRAPPER}} .faq-widget-2 .faq-body p,
                    {{WRAPPER}} .faq-widget .faq-body p
                ',
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
                'label' => esc_html__('Box Shadow', 'banca-core'),
				'name' => 'box_shadow',
				'selector' => '{{WRAPPER}} .faq-widget .single-widget-one',
                'condition' => [
                    'style' => [ '5' ]
                ]
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
                'label' => esc_html__('Box Shadow Hover', 'banca-core'),
				'name' => 'box_hover_shadow',
				'selector' => '{{WRAPPER}} .faq-widget .single-widget-one:hover',
                'condition' => [
                    'style' => [ '5' ]
                ]
			]
		);

        $this->add_responsive_control(
            'item_padding',
            [
                'label' => __('Item Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .faq-widget .single-widget-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
                'condition' => [
                    'style' => [ '5' ]
                ]
            ]
        );

        $this->add_responsive_control(
            'contents_padding',
            [
                'label' => __('Content Padding', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .faq-widget .single-widget-one .faq-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
                'condition' => [
                    'style' => [ '5' ]
                ]
            ]
        );

        $this->add_control(
            'accordion_icon_color', [
                'label' => esc_html__('Icon Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-widget .single-widget-one i' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'style' => [ '5' ]
                ]
            ]
        );

        $this->end_controls_section(); // End Accordion


        //======================= Style Section Background =======================//
        $this->start_controls_section(
            'style_item_box', [
                'label' => esc_html__('BOX Container', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'style' => [ '1' ]
                ]
            ]
        );


        $this->add_control(
            'accordion_icon', [
                'label' => esc_html__('Accordion Icon', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'accordi_background', [
                'label' => esc_html__('Icon Background', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-header h6 i' => 'background: {{VALUE}};',
                ]
            ]
        );

        $this->add_responsive_control(
            'accordi_border_radius', [
                'label' => __('Border Radius', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .faq-header h6 i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_margin', [
                'label' => __('Content Margin', 'banca-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .faq-widget-2 .faq-body p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before'
            ]
        );

        $this->end_controls_section(); // End


    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $tabs = $this->get_settings_for_display('tabs');
        $id_int = substr($this->get_id_int(), 0, 1);


        //================= Include Parts
        include "template/accordion/accordion-{$settings['style']}.php";

    }

}