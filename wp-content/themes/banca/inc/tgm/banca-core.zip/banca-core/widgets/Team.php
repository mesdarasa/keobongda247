<?php
/**
 * Use namespace to avoid conflict
 */
namespace BancaCore\Widgets;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Typography,
    Group_Control_Box_Shadow,
    Group_Control_Image_Size,
    Icons_Manager,
    Group_Control_Border,
    Utils,
    Group_Control_Background,
    Group_Control_Text_Shadow,
    Repeater
};


/**
 * Class Team
 * @package BancaCore\Widgets
 */
class Team extends Widget_Base
{

    public function get_name()
    {
        return 'banca_team';
    }

    public function get_title()
    {
        return __('Team Member (Banca)', 'banca-core');
    }

    public function get_icon()
    {
        return 'eicon-person';
    }

    public function get_categories()
    {
        return ['banca-elements'];
    }


    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function register_controls()
    {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }

    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_content_control()
    {


        //============================ Accordion ===========================//
        $this->start_controls_section(
            'team_member_sec', [
                'label' => __('Team Member', 'banca-core'),
            ]
        );

        $this->add_control(
            'image', [
                'label' => __('Image', 'banca-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'name', [
                'label' => __('Name', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Arif Rahman'
            ]
        );

        $this->add_control(
            'designation', [
                'label' => __('Designation', 'banca-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Web Developer'
            ]
        );

        $this->add_control(
            'author_link', [
                'label' => __('Author Link', 'banca-core'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ]
            ]
        );

        $this->end_controls_section(); // End Team Member

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    public function elementor_style_control()
    {

        //============================ Style Team Member =============================//
        $this->start_controls_section(
            'team_style', [
                'label' => esc_html__('Team Member', 'banca-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //==============  Name
        $this->add_control(
            'team_name', [
                'label' => esc_html__('Name', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'team_name_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-leadership-widget a .leader-info h5' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'team_name_typo',
                'selector' => '{{WRAPPER}} .single-leadership-widget a .leader-info h5',
            ]
        );

        //============== Designation
        $this->add_control(
            'team_designation', [
                'label' => esc_html__('Designation', 'banca-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'team_designation_color', [
                'label' => esc_html__('Text Color', 'banca-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-leadership-widget a .leader-info p' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'team_designation_typo',
                'selector' => '{{WRAPPER}} .single-leadership-widget a .leader-info p',
            ]
        );


        $this->end_controls_section(); // End Team member section

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @banca
     * Author: spider-themes
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="leadership-area">
            <div class="single-leadership-widget wow fadeInUp " data-wow-delay="0.1s">
                <a <?php Banca_Core_Helper()->the_button($settings['author_link']) ?>>
                    <?php echo wp_get_attachment_image($settings['image']['id'], 'full') ?>
                    <div class="leader-info">
                        <?php
                        if (!empty($settings['name'])) { ?>
                            <h5><?php echo esc_html($settings['name']) ?></h5>
                            <?php
                        }
                        if (!empty($settings['designation'])) { ?>
                            <p><?php echo esc_html($settings['designation']) ?></p>
                            <?php
                        }
                        ?>
                    </div>
                </a>
            </div>
        </div>
        <?php
    }
}