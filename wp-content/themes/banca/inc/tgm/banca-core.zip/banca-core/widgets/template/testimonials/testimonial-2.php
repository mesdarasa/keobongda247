<section class="testimonial-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 pr-lg-35">
                <div class="testimonial-slider-3" data-rtl="<?php echo esc_attr(banca_core_rtl()) ?>">
                    <?php
                    if ( !empty($testimonials2) ) {
                        $i = 0;
                        foreach ($testimonials2 as $testimonial) {
                            if ($i == 0) {
                                $testimonial = end($testimonials2);
                            } else {
                                $testimonial = $testimonials2[$i - 1];
                            }
                            ?>
                            <div class="testimonial-widget-3 wow fadeInLeft">
                                <div class="client-img">
                                    <?php banca_el_image($testimonial['image'], 'client'); ?>
                                    <a class="play-btn" data-fancybox
                                       href="<?php echo esc_url($testimonial['video_url']) ?>">
                                        <i class="fas fa-play"></i>
                                    </a>
                                    <p class="caption __review_content"><?php echo esc_html($testimonial['quote']) ?></p>
                                </div>
                                <div class="client-info">
                                    <h6 class="__name"><?php echo esc_html($testimonial['name']) ?></h6>
                                    <span class="__designation"><?php echo esc_html($testimonial['designation']) ?></span>
                                </div>
                            </div>
                            <?php
                            $i++;
                        }
                    }
                    ?>
                </div>
            </div>
            <div class="col-lg-8 col-md-6 ">
                <div class="h-100 d-flex flex-column justify-content-between">
                    <?php if (!empty($settings['title'])) : ?>
                        <div class="section-title text-start d-none d-md-block">
                            <h2 class="wow fadeInRight __sec_title"><?php echo banca_core_kses_post($settings['title']) ?></h2>
                        </div>
                    <?php endif; ?>
                    <div class="testimonial-slider-2" data-rtl="<?php echo esc_attr(banca_core_rtl()) ?>">
                        <?php
                        $delay_time = 0.1;
                        if ($testimonials2) {
                            foreach ($testimonials2 as $testimonial) {
                                ?>
                                <div class="testimonial-widget-2 wow fadeInUp"
                                     data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                                    <?php banca_el_image($testimonial['image'], 'client'); ?>
                                    <div class="client-info">
                                        <p class="__name"><?php echo esc_html($testimonial['name']) ?></p>
                                        <span class="__designation"><?php echo esc_html($testimonial['designation']) ?></span>
                                    </div>
                                </div>
                                <?php
                                $delay_time = $delay_time + 0.2;
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
