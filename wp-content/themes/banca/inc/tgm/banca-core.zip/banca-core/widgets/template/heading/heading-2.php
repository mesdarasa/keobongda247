<?php
 if ('' === $settings['title']) {
            return;
        }

        $this->add_render_attribute('title', 'class', 'elementor-heading-title title-gradient');

        if (!empty($settings['size'])) {
            $this->add_render_attribute('title', 'class', 'elementor-size-' . $settings['size']);
        }

        $this->add_inline_editing_attributes('title');

        $title = $settings['title'];

        if (!empty($settings['link']['url'])) {
            $this->add_link_attributes('url', $settings['link']);

            $title = sprintf('<a %1$s>%2$s</a>', $this->get_render_attribute_string('url'), $title);
        }

        $title_html = sprintf('<%1$s %2$s>%3$s</%1$s>', \Elementor\Utils::validate_html_tag($settings['header_size']), $this->get_render_attribute_string('title'), $title);

        echo wp_kses_post(str_replace(['{', '}'], ['<span>', '</span>'], $title_html));
?>