<section class="faq-area-2">
    <div class="faq-widget">
        <div class="accordion" id="accordion<?php echo esc_attr($this->get_id()) ?>">
            <?php
            $delay_time = 0.1;
            foreach ($tabs as $index => $item) {
                $tab_count = $index + 1;
                $active_show = $tab_count == 1 ? ' show' : '';

                $tab_title_setting_key = $this->get_repeater_setting_key('tab_title', 'tabs', $index);
                $tab_content_setting_key = $this->get_repeater_setting_key('tab_content', 'tabs', $index);

                $this->add_render_attribute($tab_title_setting_key, [
                    'class' => ['mb-0', $tab_count == 1 ? '' : 'collapsed'],
                    'data-bs-toggle' => 'collapse',
                    'data-bs-target' => '#collapse' . $id_int . $tab_count,
                    'aria-expanded' => $tab_count == 1 ? 'false' : 'true',
                    'aria-controls' => 'collapse' . $id_int . $tab_count,
                ]);

                $this->add_render_attribute($tab_content_setting_key, [
                    'id' => 'collapse' . $id_int . $tab_count,
                    'class' => 'collapse' . $active_show,
                    'aria-labelledby' => 'heading' . $id_int . $tab_count,
                    'data-bs-parent' => '#accordion' . $this->get_id(),
                ]);
                ?>

                <div class="single-widget-one wow fadeInUp px-sm-5 px-4"
                     data-wow-delay="<?php echo esc_attr($delay_time) ?>s">
                    <div class="widget-icon">
                        <i class="icon_question_alt2 "></i>
                    </div>
                    <div class="w-100">
                        <div class="faq-header" id="heading<?php echo esc_attr($id_int . $tab_count) ?>">
                            <h4 <?php echo $this->get_render_attribute_string($tab_title_setting_key); ?>>
                                <?php echo esc_html($item['tab_title']) ?>
                                <i class="icon_plus"></i>
                                <i class=" icon_minus-06"></i>
                            </h4>
                        </div>
                        <div <?php echo $this->get_render_attribute_string($tab_content_setting_key) ?>>
                            <div class="faq-body pr-lg-130">
                                <?php echo !empty($item['tab_content']) ? banca_core_kses_post(wpautop($item['tab_content'])) : '' ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                $delay_time = $delay_time + 0.2;
            }
            ?>
        </div>
    </div>
</section>