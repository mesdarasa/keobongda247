<?php
$loan_amount_value = !empty($settings['loan_amount_value']) ? $settings['loan_amount_value'] : '';
$loan_amount_value_explode = explode(', ', $loan_amount_value);

// Monthly Loan interest
$monthly_loan = ($settings['monthly_loan']);
$loan_months = array();
if (is_array($monthly_loan)) {
    foreach ($monthly_loan as $allmonth) {
        $loan_months[] = $allmonth['number_of_month'];
    }
}
$loan_months = implode(', ', $loan_months);

// Yearly Loan interest
$yearly_loan = ($settings['yearly_loan']);
$loan_year = array();
if (is_array($yearly_loan)) {
    foreach ($yearly_loan as $allyear) {
        $loan_year[] = $allyear['number_of_year'];
    }
}
$loan_year = implode(', ', $loan_year);

?>
<div class="calculator-widget">
    <div class="row gy-lg-0 gy-3">
        <div class="col-lg-7">
            <div class="single-calculator-widget wow fadeInUp" data-wow-delay="0.1s">
                <?php if (!empty($loan_title)) : ?>
                    <div class="single-range">
                        <div class="range-header d-flex justify-content-between align-items-center mb-25">
                            <h6><?php echo esc_html($loan_title) ?></h6>
                            <input type="text" id="SetRange" data-loan="">
                        </div>
                        <div id="RangeSlider"></div>
                    </div>
                <?php endif; ?>
                <div class="single-range mt-85 mb-95">
                    <div class="range-header d-flex flex-wrap justify-content-between align-items-center mb-25">
                        <?php if (!empty($duration_title)) : ?>
                            <h6><?php echo esc_html($duration_title) ?></h6>
                        <?php endif; ?>
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li><span class="active_bar"></span></li>
                            <?php
                            if (!empty($monthly_tab_title)) { ?>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active month-tab" id="monthTab" data-bs-toggle="tab"
                                       href="#monthTabId" role="tab" aria-controls="monthTabId"
                                       aria-selected="true">
                                        <?php echo esc_html($monthly_tab_title) ?>
                                    </a>
                                </li>
                                <?php
                            }
                            if (!empty($yearly_tab_title)) { ?>
                                <li class="nav-item " role="presentation">
                                    <a class="nav-link year-tab" id="yearTab" data-bs-toggle="tab"
                                       href="#yearTabId" role="tab" aria-controls="yearTabId"
                                       aria-selected="false">
                                        <?php echo esc_html($yearly_tab_title) ?>
                                    </a>
                                </li>
                                <?php
                            }
                            ?>
                        </ul>
                        <input type="text" id="SetMonthRange">
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="monthTabId" role="tabpanel"
                             aria-labelledby="monthTab">
                            <div id="MonthRangeSlider"></div>
                        </div>
                        <div class="tab-pane fade" id="yearTabId" role="tabpanel" aria-labelledby="yearTab">
                            <div id="YearRangeSlider"></div>
                        </div>
                    </div>
                </div>
                <?php if (!empty($interest_rate_title)) : ?>
                    <div class="bg_disable px-4 py-2 mb-5 interestBox">
                        <p><?php echo esc_html($interest_rate_title) ?></p>
                        <span id="InterestAmount"></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="calculator-result-widget bg_disable wow fadeInUp" data-wow-delay="0.3s">

                <div class="row align-items-center">
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <div class="emi-amount">
                            <?php
                            if (!empty($emi_amount_title)) { ?>
                                <h6><?php echo esc_html($emi_amount_title) ?></h6>
                                <?php
                            }
                            if (!empty($emi_amount_subtitle)) { ?>
                                <span><?php echo esc_html($emi_amount_subtitle) ?></span>
                                <?php
                            }
                            ?>
                            <p class="mt-10" id="TotalAmount"></p>
                        </div>
                        <?php if (!empty($emi_interest_title)) : ?>
                            <div class="interest-payable mt-20">
                                <h6><?php echo esc_html($emi_interest_title) ?></h6>
                                <p class="mt-10" id="InterestPayable"></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-5 col-md-4 col-sm-5 col-7 mx-auto">
                        <svg class="radial-progress" id="LoanGraph" viewBox="0 0 80 80">
                            <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                            <circle class="complete" cx="40" cy="40" r="30"></circle>
                        </svg>
                    </div>
                </div>
                <div class="row mt-lg-60 mt-25 text-center">
                    <div class="col-12">
                        <?php
                        if (!empty($emi_total_amount_title)) { ?>
                            <h4 class="mb-1"><?php echo esc_html($emi_total_amount_title) ?></h4>
                            <h1 class="m-0" id="emiAmount"></h1>
                            <?php
                        }
                        if (!empty($btn_label)) { ?>
                            <a <?php Banca_Core_Helper()->the_button($settings['btn_url']) ?> class="theme-btn theme-btn-lg mt-40">
                                <?php echo esc_html($btn_label) ?>
                                <i class="arrow_right"></i>
                            </a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    (function ($) {
        'use strict';

        $(document).ready(function () {

            // ------- Emi Calculator --------- //
            var SelectedAmount,
                selectedTime = {},
                RateOfInterestTime,
                RateOfInterestAmount;

            if (typeof wNumb !== "undefined") {
                var AmountFormat = wNumb({
                    decimals: 0,
                    thousand: ",",
                    prefix: "<?php echo esc_js($settings['loan_amount_currency']) ?>",
                });

                var TimeFormatMonths = wNumb({
                    prefix: " months",
                });
                var TimeFormatYears = wNumb({
                    prefix: " months",
                });
            }

            //Slider Elements
            var mySlider = document.getElementById("RangeSlider");
            var mySliderMonth = document.getElementById("MonthRangeSlider");
            var mySliderYear = document.getElementById("YearRangeSlider");
            //-----home page 2
            var SliderAmount = document.getElementById("SliderAmount");
            var SliderPeriod = document.getElementById("SliderPeriod");

            function clickOnPip(sliderName, This) {
                var value = Number(This.getAttribute("data-value"));
                sliderName.noUiSlider.set(value);
            }

            function SetPipsOnSlider(PipsName, sliderName) {
                for (var i = 0; i < PipsName.length; i++) {
                    PipsName[i].style.cursor = "pointer";
                    PipsName[i].addEventListener("click", function () {
                        clickOnPip(sliderName, this);
                    });
                }
            }

            //   Activate Range Sliders
            if (mySlider && mySliderMonth && mySliderYear) {
                noUiSlider.create(mySlider, {
                    start: [<?php echo esc_js($settings['loan_amount_start_value']) ?>],
                    connect: "lower",
                    range: {
                        min: <?php echo esc_js($loan_amount_value_explode[0]) ?>,
                        max: <?php echo esc_js(end($loan_amount_value_explode)) ?>,
                    },
                    format: wNumb({
                        decimals: 0,
                        thousand: ",",
                        prefix: "<?php echo esc_js($settings['loan_amount_currency']) ?> ",
                    }),
                    pips: {
                        mode: "values",
                        density: 100,

                        values: [<?php echo esc_js($loan_amount_value) ?>],
                        stepped: true,
                        format: wNumb({
                            encoder: function (a) {
                                return a / 1000;
                            },
                            decimals: 0,
                            prefix: "<?php echo esc_js($settings['loan_amount_currency']) ?>",
                            suffix: "<?php echo esc_js($settings['loan_suffix']) ?>",
                        }),
                    },
                });
                noUiSlider.create(mySliderMonth, {
                    start: [<?php echo esc_js($settings['monthly_tab_start_mo_no']) ?>],
                    connect: "lower",
                    range: {
                        min: <?php echo esc_js($monthly_loan[0]['number_of_month']) ?>,
                        max: <?php echo esc_js(end($monthly_loan)['number_of_month']) ?>,
                    },
                    format: wNumb({
                        decimals: 0,
                        suffix: " <?php echo esc_js($settings['monthly_tab_duration_label']) ?>",
                    }),
                    pips: {
                        mode: "values",
                        density: 100,

                        values: [<?php echo esc_js($loan_months) ?>],
                        stepped: true,
                        format: wNumb({
                            decimals: 0,
                        }),
                    },
                });
                noUiSlider.create(mySliderYear, {
                    start: [<?php echo esc_js($settings['yearly_tab_start_mo_no']) ?>],
                    connect: "lower",
                    range: {
                        min: <?php echo esc_js($yearly_loan[0]['number_of_year']) ?>,
                        max: <?php echo esc_js(end($yearly_loan)['number_of_year']) ?>,
                    },
                    format: wNumb({
                        decimals: 0,
                        suffix: " <?php echo esc_js($settings['yearly_tab_duration_label']) ?>",
                    }),
                    pips: {
                        mode: "values",
                        density: 100,
                        values: [<?php echo esc_js($loan_year) ?>],
                        stepped: true,
                        format: wNumb({
                            decimals: 0,
                        }),
                    },
                });
                //Slider Pips
                var pips = mySlider.querySelectorAll(".noUi-value");
                var pipsMonth = mySliderMonth.querySelectorAll(".noUi-value");
                var pipsYear = mySliderYear.querySelectorAll(".noUi-value");

                //Slider Input Element
                var inputMonthFormat = document.getElementById("SetMonthRange");
                var inputFormat = document.getElementById("SetRange");

                SetPipsOnSlider(pips, mySlider);
                SetPipsOnSlider(pipsMonth, mySliderMonth);
                SetPipsOnSlider(pipsYear, mySliderYear);
                mySlider.noUiSlider.on("update", function (values, handle) {
                    inputFormat.value = values[handle];
                    SelectedAmount = AmountFormat.from(values[handle]);
                    CalculateAmount();
                });

                inputFormat.addEventListener("change", function () {
                    mySlider.noUiSlider.set(this.value);
                });

                if ($("#monthTab.active").length > 0) {
                    mySliderMonth.noUiSlider.on("update", function (values, handle) {
                        inputMonthFormat.value = values[handle];
                        selectedTime = {
                            type: "month",
                            value: TimeFormatMonths.from(values[handle]),
                        };

                        CalculateAmount();
                    });

                    inputMonthFormat.addEventListener("change", function () {
                        mySliderMonth.noUiSlider.set(this.value);
                    });
                } else if ($("#yearTab.active").length > 0) {
                    mySliderYear.noUiSlider.on("update", function (values, handle) {
                        inputMonthFormat.value = values[handle];

                        selectedTime = {
                            type: "year",
                            value: TimeFormatYears.from(values[handle]),
                        };
                        CalculateAmount();
                    });
                }

                inputMonthFormat.addEventListener("change", function () {
                    if ($("#monthTab.active").length > 0) {
                        mySliderMonth.noUiSlider.set(this.value);
                    } else if ($("#yearTab.active").length > 0) {
                        mySliderYear.noUiSlider.set(this.value);
                    }
                });

                $("#yearTab").click(function () {
                    mySliderMonth.noUiSlider.off("update", function (values, handle) {
                        inputMonthFormat.value = values[handle];
                        selectedTime = {
                            type: "month",
                            value: TimeFormatMonths.from(values[handle]),
                        };
                        CalculateAmount();
                    });
                    mySliderYear.noUiSlider.on("update", function (values, handle) {
                        inputMonthFormat.value = values[handle];
                        selectedTime = {
                            type: "year",
                            value: TimeFormatYears.from(values[handle]),
                        };
                        CalculateAmount();
                    });
                });
                $("#monthTab").click(function () {
                    mySliderYear.noUiSlider.off("update", function (values, handle) {
                        inputMonthFormat.value = values[handle];
                        selectedTime = {
                            type: "year",
                            value: TimeFormatYears.from(values[handle]),
                        };
                        CalculateAmount();
                    });
                    mySliderMonth.noUiSlider.on("update", function (values, handle) {
                        inputMonthFormat.value = values[handle];
                        selectedTime = {
                            type: "month",
                            value: TimeFormatMonths.from(values[handle]),
                        };
                        CalculateAmount();
                    });
                });
            }

            if (SliderAmount && SliderPeriod) {
                noUiSlider.create(SliderAmount, {
                    start: [100000],
                    connect: "lower",
                    range: {
                        min: 5000,
                        max: 250000,
                    },
                    format: wNumb({
                        decimals: 0,
                        thousand: ",",
                        prefix: "<?php echo esc_js($loan_amount_currency) ?> ",
                    }),
                });
                noUiSlider.create(SliderPeriod, {
                    start: [3],
                    connect: "lower",
                    range: {
                        min: 1,
                        max: 5,
                    },
                    format: wNumb({
                        decimals: 0,
                        suffix: " year",
                    }),
                });

                var SliderAmountFormat = document.getElementById("SetSliderAmount");
                var SliderPeriodFormat = document.getElementById("SetSliderPeriod");

                SliderAmount.noUiSlider.on("update", function (values, handle) {
                    SliderAmountFormat.value = values[handle];
                });
                SliderPeriod.noUiSlider.on("update", function (values, handle) {
                    SliderPeriodFormat.value = values[handle];
                });

                SliderAmountFormat.addEventListener("change", function () {
                    SliderAmount.noUiSlider.set(this.value);
                });
                SliderPeriodFormat.addEventListener("change", function () {
                    SliderPeriod.noUiSlider.set(this.value);
                });
            }

            function CalculateAmount() {


                // Monthly Loan
                if (selectedTime.type === "month") {
                    var LoanTime = selectedTime.value;

                    let monthlyLoan = <?php echo json_encode($monthly_loan) ?>;
                    monthlyLoan.forEach(function (elements) {
                        if (LoanTime >= elements.number_of_month) {
                            RateOfInterestTime = elements.monthly_interest_rate;
                        }
                    })

                }


                // Yearly loan
                if (selectedTime.type === "year") {
                    var LoanTime = selectedTime.value;

                    let yearly_loan = <?php echo json_encode($yearly_loan) ?>;
                    yearly_loan.forEach(function (elements) {
                        if (LoanTime >= elements.number_of_year) {
                            RateOfInterestTime = elements.yearly_interest_rate;
                        }
                    });

                    selectedTime = {
                        value: selectedTime.value * 12
                    }

                }


                if (typeof SelectedAmount === "number") {
                    RateOfInterestAmount = 0;
                }

                var TotalRateOfInterest = (RateOfInterestAmount + RateOfInterestTime) / 100;
                var TotalInterest = SelectedAmount * TotalRateOfInterest;
                var InterestAndPrincipal = TotalInterest + SelectedAmount;

                $("#TotalAmount").text(AmountFormat.to(InterestAndPrincipal) + "*");
                $("#emiAmount").text(
                    AmountFormat.to(InterestAndPrincipal / selectedTime.value) + "*"
                );
                $("#InterestPayable").text(AmountFormat.to(TotalInterest) + "*");
                $("#InterestAmount").text((TotalRateOfInterest * 100).toFixed(2) + " %");

                var percent, graphRadius, circumference, strokeDashOffset;
                var GraphEl = $("#LoanGraph");
                percent = (100 * TotalInterest) / InterestAndPrincipal;
                graphRadius = GraphEl.find($("circle.complete")).attr("r");
                circumference = 2 * Math.PI * graphRadius;
                strokeDashOffset = circumference - (percent * circumference) / 100;
                GraphEl.find($("circle.complete"))
                    .css({"stroke-dashoffset": "0", opacity: "0.1"})
                    .animate({"stroke-dashoffset": strokeDashOffset, opacity: "1"}, 1250);

                if ($("#monthTab").hasClass("active")) {
                    $(".active_bar").addClass("left");
                } else {
                    $(".active_bar").removeClass("left");
                }
            }

            // End of Calculator


        })
    })(jQuery);
</script>
