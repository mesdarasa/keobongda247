<div class="footer_counter">
    <?php
    if (!empty($settings['counter_text_number'])) { ?>
        <h1 class="counter"><?php echo banca_core_kses_post($settings['counter_text_number']) ?></h1>
        <?php
    }
    if (!empty($settings['counter_text_percentage'])) { ?>
        <h4 class="counter"><?php echo banca_core_kses_post($settings['counter_text_percentage']) ?></h4>
        <?php
    }
    ?>
</div>