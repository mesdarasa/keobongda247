<?php
// Require widget files
require plugin_dir_path(__FILE__) . 'Widget_Search_Form.php';
require plugin_dir_path(__FILE__) . 'Widget_Recent_Posts.php';
require plugin_dir_path(__FILE__) . 'Widget_Categories.php';
require plugin_dir_path(__FILE__) . 'Widget_Tag_Cloud.php';
require plugin_dir_path(__FILE__) . 'Widget_Counters.php';
require plugin_dir_path(__FILE__) . 'Widget_Job_Search_Form.php';
require plugin_dir_path(__FILE__) . 'Widget_Job_Categories.php';
require plugin_dir_path(__FILE__) . 'Widget_Job_Schedule.php';
require plugin_dir_path(__FILE__) . 'Widget_Job_locations.php';


// Register Widgets
add_action('widgets_init', function () {

    register_widget('BancaCore\WpWidgets\Widget_Search_Form');
    register_widget('BancaCore\WpWidgets\Widget_Counter');
    register_widget('BancaCore\WpWidgets\Widget_Recent_Posts');
    register_widget('BancaCore\WpWidgets\Widget_Categories');
    register_widget('BancaCore\WpWidgets\Widget_Tag_Cloud');
    register_widget('BancaCore\WpWidgets\Widget_Job_Search_Form');
    register_widget('BancaCore\WpWidgets\Widget_Job_Categories');
    register_widget('BancaCore\WpWidgets\Widget_Job_Schedule');
    register_widget('BancaCore\WpWidgets\Widget_Job_locations');

});