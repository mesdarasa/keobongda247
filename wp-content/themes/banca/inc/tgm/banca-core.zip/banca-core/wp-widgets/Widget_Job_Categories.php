<?php
namespace BancaCore\WpWidgets;
use WP_Widget;
use WP_Query;

/**
 * Widget API: Banca_Widget_Categories class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */

/**
 * Core class used to implement a Categories widget.
 *
 * @since 2.8.0
 *
 * @see WP_Widget
 */
class Widget_Job_Categories extends WP_Widget {

    /**
     * Sets up a new Categories widget instance.
     *
     * @since 2.8.0
     */
    public function __construct() {
        $widget_ops = array(
            'classname'                   => 'mt-30 widget-border',
            'description'                 => __( 'A list or dropdown of categories.' ),
            'customize_selective_refresh' => true,
        );
        parent::__construct( 'banca_widgets_job_categories', esc_html__( 'Categories (Job)', 'banca-core' ), $widget_ops );

    }

    /**
     * Outputs the content for the current Categories widget instance.
     *
     * @since 2.8.0
     * @since 4.2.0 Creates a unique HTML ID for the `<select>` element
     *              if more than one instance is displayed on the page.
     *
     * @param array $args     Display arguments including 'before_title', 'after_title',
     *                        'before_widget', and 'after_widget'.
     * @param array $instance Settings for the current Categories widget instance.
     */
    public function widget( $args, $instance ) {

        $default_title = __( 'Job Categories' );
        $title         = ! empty( $instance['title'] ) ? $instance['title'] : $default_title;

        /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

        $count  = ! empty( $instance['count'] ) ? '1' : '';
        $number =  ! empty( $instance['cats_num_banca'] )  ? absint( $instance['cats_num_banca'] ) : -1;

        echo $args['before_widget'];

        if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }

        ?>
            <div class="catagory-list-widget">
                <div class="widget-content">
                    <ul class="catagory-list">

                        <li class="catagory-item ">
                            <a href="#" class="catagory-link active">
                                <span class="text"><?php esc_html_e( 'All Category', 'banca-core' ); ?></span>
                                <span class="number">(<?php echo banca_get_cats_count_all( 'job_cat' )  ?>)</span>
                            </a>
                        </li>

                        <?php
                        $cat_args = array(
                            'taxonomy' => 'job_cat',
                            'hide_empty' => true,
                            'orderby'      => 'name',
                            'show_count'   => $count,
                            'number'       => $number
                        );

                        $cats = get_categories( $cat_args );
                        foreach ( $cats as $cat ) {
                            ?>
                            <li class="catagory-item">
                                <a href="<?php echo get_category_link($cat->term_id) ?>" class="catagory-link">
                                    <span class="text"><?php echo esc_html($cat->name); ?></span>
                                    <?php if ( $count ) : ?>
                                        <span class="number">(<?php echo esc_html($cat->count) ?>)</span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <?php
                        }
                        ?>
                    </ul>

                </div>
            </div>

        <?php

        echo $args['after_widget'];
    }

    /**
     * Handles updating settings for the current Categories' widget instance.
     *
     * @since 2.8.0
     *
     * @param array $new_instance New settings for this instance as input by the user via
     *                            WP_Widget::form().
     * @param array $old_instance Old settings for this instance.
     * @return array Updated settings to save.
     */
    public function update( $new_instance, $old_instance ) {
        $instance                 = $old_instance;
        $instance['title']        = sanitize_text_field( $new_instance['title'] );
        $instance['count']        = ! empty( $new_instance['count'] ) ? 1 : 0;
        $instance['hierarchical'] = ! empty( $new_instance['hierarchical'] ) ? 1 : 0;
        $instance['dropdown']     = ! empty( $new_instance['dropdown'] ) ? 1 : 0;
        $instance['cats_num_banca']  = sanitize_text_field($new_instance['cats_num_banca']);
        return $instance;
    }

    /**
     * Outputs the settings form for the Categories widget.
     *
     * @since 2.8.0
     *
     * @param array $instance Current settings.
     */
    public function form( $instance ) {

        // Defaults.
        $instance     = wp_parse_args( (array) $instance, array( 'title' => '' ) );
        $count        = isset( $instance['count'] ) ? (bool) $instance['count'] : false;
        $number       = isset( $instance['cats_num_banca'] ) ? $instance['cats_num_banca'] : 5;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'cats_num_banca' ); ?>"><?php _e( 'Number of Category to show:' ); ?></label>
            <input class="tiny-text" id="<?php echo $this->get_field_id( 'cats_num_banca' ); ?>" name="<?php echo $this->get_field_name( 'cats_num_banca' ); ?>" type="number" step="1" min="1" value="<?php echo esc_attr($number); ?>" />
        </p>

        <p>

            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'count' ); ?>" name="<?php echo $this->get_field_name( 'count' ); ?>"<?php checked( $count ); ?> />
            <label for="<?php echo $this->get_field_id( 'count' ); ?>"><?php _e( 'Show post counts' ); ?></label>
            <br />
        </p>
        <?php
    }

}
