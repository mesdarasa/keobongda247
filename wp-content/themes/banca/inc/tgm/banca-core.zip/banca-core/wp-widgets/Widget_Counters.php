<?php

namespace BancaCore\WpWidgets;

use WP_Widget;


// Footer Counter
class Widget_Counter extends WP_Widget
{

    /**
     * Sets up a new Counter widget instance.
     *
     * @since 2.8.0
     */
    public function __construct()
    {
        $widget_ops = array(
            'classname' => 'widget_counters wow fadeInLeft',
            'description' => __('A list or dropdown of categories.'),
            'customize_selective_refresh' => true,
            'show_instance_in_rest' => true,
        );
        parent::__construct('banca_wp_widget_counters', esc_html__('Counter (Theme)', 'banca-core'), $widget_ops);

    }

    /**
     * Outputs the content for the current Categories widget instance.
     *
     * @param array $args Display arguments including 'before_title', 'after_title',
     *                        'before_widget', and 'after_widget'.
     * @param array $instance Settings for the current Categories widget instance.
     * @since 2.8.0
     * @since 4.2.0 Creates a unique HTML ID for the `<select>` element
     *              if more than one instance is displayed on the page.
     *
     */
    public function widget($args, $instance)
    {

        wp_enqueue_script('counterup');
        wp_enqueue_script('waypoints');

        echo $args['before_widget'];

        $contents = !empty($instance['contents']) ? $instance['contents'] : '';
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $counter_num = !empty($instance['counter_num']) ? $instance['counter_num'] : '';
        $counter_per = !empty($instance['counter_per']) ? $instance['counter_per'] : '';
        $subtitle = !empty($instance['subtitle']) ? $instance['subtitle'] : '';

        ?>

        <?php
        if ($contents) { ?>
            <div class="footer-text mb-20">
                <p><?php echo esc_html($contents) ?></p>
            </div>
            <?php
        }
        if ($title) { ?>
            <span class="overline"><?php echo esc_html($title) ?></span>
            <?php
        }
        if ($counter_num) { ?>
            <div class="footer-bold">
                <h1 class="counter"><?php echo banca_core_kses_post($counter_num) ?></h1>
                <h4 class="counter"><?php echo banca_core_kses_post($counter_per) ?></h4>
            </div>
            <?php
        }
        if ($subtitle) { ?>
            <p class="time"><?php echo esc_html($subtitle) ?></p>
            <?php
        }
        ?>

        <script>
            (function ($) {
                'use strict';
                $(document).ready(function () {

                    let $counter = $('.counter span');
                    let $stat_counter = $('stat-counter');

                    //initialize counterUp
                    if ($counter.length > 0) {
                        $counter.counterUp()
                    }

                    if ($stat_counter.length > 0) {
                        $stat_counter.counterUp()
                    }

                })
            })(jQuery);
        </script>

        <?php

        echo $args['after_widget'];

    }


    /**
     * Handles updating settings for the current Counter widget instance.
     *
     * @param array $new_instance New settings for this instance as input by the user via WP_Widget::form().
     * @param array $old_instance Old settings for this instance.
     * @return array Updated settings to save.
     */
    public function update($new_instance, $old_instance)
    {

        $instance = array();

        if (!empty($new_instance['contents'])) {
            $instance['contents'] = ($new_instance['contents']);
        }

        if (!empty($new_instance['title'])) {
            $instance['title'] = ($new_instance['title']);
        }

        if (!empty($new_instance['counter_num'])) {
            $instance['counter_num'] = ($new_instance['counter_num']);
        }

        if (!empty($new_instance['counter_per'])) {
            $instance['counter_per'] = ($new_instance['counter_per']);
        }

        if (!empty($new_instance['subtitle'])) {
            $instance['subtitle'] = ($new_instance['subtitle']);
        }

        return $instance;
    }


    /**
     * Outputs the settings form for the Categories widget.
     *
     * @param array $instance Current settings.
     * @since 2.8.0
     *
     */
    public function form($instance)
    {

        $content = isset($instance['contents']) ? $instance['contents'] : '';
        $title = isset($instance['title']) ? $instance['title'] : '';
        $counter_num = isset($instance['counter_num']) ? $instance['counter_num'] : '';
        $counter_per = isset($instance['counter_per']) ? $instance['counter_per'] : '';
        $subtitle = isset($instance['subtitle']) ? $instance['subtitle'] : '';
        ?>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('contents')); ?>"><?php esc_html_e('Content:', 'banca-core'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('contents'); ?>"
                   name="<?php echo $this->get_field_name('contents'); ?>" value="<?php echo esc_attr($content); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'banca-core'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('counter_num')); ?>"><?php esc_html_e('Counter Number:', 'banca-core'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('counter_num'); ?>"
                   name="<?php echo $this->get_field_name('counter_num'); ?>"
                   value="<?php echo esc_attr($counter_num); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('counter_per')); ?>"><?php esc_html_e('Counter Percentage:', 'banca-core'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('counter_per'); ?>"
                   name="<?php echo $this->get_field_name('counter_per'); ?>"
                   value="<?php echo esc_attr($counter_per); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('subtitle')); ?>"><?php esc_html_e('Subtitle:', 'banca-core'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('subtitle'); ?>"
                   name="<?php echo $this->get_field_name('subtitle'); ?>" value="<?php echo esc_attr($subtitle); ?>">
        </p>
        <?php

    }

}