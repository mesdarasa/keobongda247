<?php
namespace BancaCore\WpWidgets;
use WP_Widget;
use WP_Query;

/**
 * Widget API: Banca_Widget_Categories class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */

/**
 * Core class used to implement a Categories widget.
 *
 * @since 2.8.0
 *
 * @see WP_Widget
 */
class Widget_Job_locations extends WP_Widget {

    /**
     * Sets up a new Categories widget instance.
     *
     * @since 2.8.0
     */
    public function __construct() {
        $widget_ops = array(
            'classname'                   => 'mt-30 widget-shadow',
            'description'                 => __( 'A list or dropdown of Job locations.' ),
            'customize_selective_refresh' => true,
        );
        parent::__construct( 'widgets_job_locations', esc_html__( 'Job Locations', 'banca-core' ), $widget_ops );

    }

    /**
     * Outputs the content for the current Categories widget instance.
     *
     * @since 2.8.0
     * @since 4.2.0 Creates a unique HTML ID for the `<select>` element
     *              if more than one instance is displayed on the page.
     *
     * @param array $args     Display arguments including 'before_title', 'after_title',
     *                        'before_widget', and 'after_widget'.
     * @param array $instance Settings for the current Categories widget instance.
     */
    public function widget( $args, $instance ) {

        echo $args['before_widget'];

        ?>
        <div class="select-location">
            <form action="<?php echo esc_url( home_url( '/' ) ) ?>" method="get">
                <span class="arrow-icon"><i class="arrow_carrot-down"></i></span>
                <select id="locationSelect" class="form-control">
                    <?php
                    $location_args = array(
                        'taxonomy' => 'job_location',
                        'orderby'      => 'name',
                        'show_option_none' => __( 'Select Location', 'banca-core' ),
                    );

                    $locations = get_terms( $location_args );
                    echo '<option value="Select Location" selected>'.esc_html__( 'Select Location', 'banca-core' ).'</option>';
                    foreach ( $locations as $location ) {
                        ?>
                        <option value="<?php echo get_category_link($location->term_id) ?>"><?php echo esc_html($location->name) ?></option>
                        <?php
                    }
                    ?>
                </select>
            </form>
        </div>

        <script>
            document.getElementById("locationSelect").onchange = function() {
                if (this.selectedIndex !== 0) {
                    window.location.href = this.value;
                }
            };
        </script>
        <?php

        echo $args['after_widget'];
    }

    /**
     * Handles updating settings for the current Categories' widget instance.
     *
     * @since 2.8.0
     *
     * @param array $new_instance New settings for this instance as input by the user via
     *                            WP_Widget::form().
     * @param array $old_instance Old settings for this instance.
     * @return array Updated settings to save.
     */
    public function update( $new_instance, $old_instance ) {
        $instance                 = $old_instance;
        return $instance;
    }

    /**
     * Outputs the settings form for the Categories widget.
     *
     * @since 2.8.0
     *
     * @param array $instance Current settings.
     */
    public function form( $instance ) {

        //
    }

}
