<?php
/**
 * Plugin Name: Banca Core
 * Plugin URI: https://themeforest.net/user/spider-themes/portfolio
 * Description: This plugin adds the core features to the Banca WordPress theme. You must have to install this plugin to get all the features included with the Banca theme.
 * Version: 1.8.0
 * Requires at least: 5.0
 * Tested up to: 6.3
 * Requires PHP: 7.4
 * Author: spider-themes
 * Author URI: https://themeforest.net/user/spider-themes/portfolio
 * Text domain: banca-core
 */

use Elementor\Plugin;

if (!defined('ABSPATH'))
    die('-1');

// Banca Core Directories
define('BANCA_CORE_VERSION', '1.8.0');
define('BANCA_CORE__FILE__', __FILE__);
define('BANCA_CORE_DIR_PATH', plugin_dir_path(BANCA_CORE__FILE__));
define('BANCA_CORE_IMAGES', plugins_url('assets/images/', __FILE__));
define('BANCA_CORE_DIR_CSS', plugins_url('assets/css/', __FILE__));
define('BANCA_CORE_DIR_JS', plugins_url('assets/js/', __FILE__));
define('BANCA_CORE_DIR_VEND', plugins_url('assets/vendors/', __FILE__));

// Make sure the same class is not loaded twice in free/premium versions.
if (!class_exists('Banca_core')) {
    /**
     * Main Banca Core Class
     *
     * The main class that initiates and runs the Banca Core plugin.
     *
     * @since 1.7.0
     */
    class Banca_core {
        /**
         * Banca Core Version
         *
         * Holds the version of the plugin.
         *
         * @since 1.7.0
         * @since 1.7.1 Moved from property with that name to a constant.
         *
         * @var string The plugin version.
         */
        const VERSION = '1.8.0';

        /**
         * Minimum Elementor Version
         *
         * Holds the minimum Elementor version required to run the plugin.
         *
         * @since 1.7.0
         * @since 1.7.1 Moved from property with that name to a constant.
         *
         * @var string Minimum Elementor version required to run the plugin.
         */
        const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

        /**
         * Minimum PHP Version
         *
         * Holds the minimum PHP version required to run the plugin.
         *
         * @since 1.7.0
         * @since 1.7.1 Moved from property with that name to a constant.
         *
         * @var string Minimum PHP version required to run the plugin.
         */
        const  MINIMUM_PHP_VERSION = '7.4';

        /**
         * Plugin's directory paths
         * @since 1.0
         */
        const CSS = null;
        const JS = null;
        const IMG = null;
        const VEND = null;

        /**
         * Instance
         *
         * Holds a single instance of the `Banca_Core` class.
         *
         * @since 1.7.0
         *
         * @access private
         * @static
         *
         * @var Banca_Core A single instance of the class.
         */
        private static $_instance = null;

        /**
         * Instance
         *
         * Ensures only one instance of the class is loaded or can be loaded.
         *
         * @return Banca_Core An instance of the class.
         * @since 1.7.0
         *
         * @access public
         * @static
         *
         */
        public static function instance()
        {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        /**
         * Clone
         *
         * Disable class cloning.
         *
         * @return void
         * @since 1.7.0
         *
         * @access protected
         *
         */
        public function __clone()
        {
            // Cloning instances of the class is forbidden
            _doing_it_wrong(__FUNCTION__, esc_html__('Cheatin&#8217; huh?', 'banca-core'), '1.7.0');
        }

        /**
         * Wakeup
         *
         * Disable unserializing the class.
         *
         * @return void
         * @since 1.7.0
         *
         * @access protected
         *
         */
        public function __wakeup()
        {
            // Unserializing instances of the class is forbidden.
            _doing_it_wrong(__FUNCTION__, esc_html__('Cheatin&#8217; huh?', 'banca-core'), '1.7.0');
        }

        /**
         * Constructor
         *
         * Initialize the Banca Core plugins.
         *
         * @since 1.7.0
         *
         * @access public
         */
        public function __construct()
        {
            $opt = get_option('banca_opt');
            $this->init_hooks();
            $this->core_includes();
            do_action('banca_core_loaded');

            add_filter('elementor/icons_manager/additional_tabs', [$this, 'banca_elegant_icons']);
            //self :: generate_custom_font_icons();
        }


        public function banca_elegant_icons($custom_fonts) {

            $css_data = function_exists('banca_setup') ? BANCA_DIR_VEND . '/elegant-icon/style.css' : '';
            $json_data = plugins_url('assets/fonts/elegant.json', __FILE__);

            $custom_fonts['elegant_icons'] = [
                'name' => 'elegant_icons',
                'label' => esc_html__('Elegant Icons', 'banca-core'),
                'url' => $css_data,
                'prefix' => '',
                'displayPrefix' => '',
                'labelIcon' => 'icon_star_alt',
                'ver' => '',
                'fetchJson' => $json_data,
                'native' => true,
            ];

            return $custom_fonts;
        }


        public static function generate_custom_font_icons()
        {
            $css_source = '';
            global $wp_filesystem;
            require_once(ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
            $css_file = BANCA_CORE_DIR_PATH . '/assets/fonts/style.css';
            if ($wp_filesystem->exists($css_file)) {
                $css_source = $wp_filesystem->get_contents($css_file);
            }
            preg_match_all("/\.(arrow_.*?):\w*?\s*?{/", $css_source, $matches, PREG_SET_ORDER, 0);
            $iconList = [];
            foreach ($matches as $match) {
                $icon = str_replace('', '', $match[1]);
                $icons = explode(' ', $icon);
                $iconList[] = current($icons);
            }

            preg_match_all("/\.(icon_.*?):\w*?\s*?{/", $css_source, $matches1, PREG_SET_ORDER, 0);
            foreach ($matches1 as $match) {
                $icon = str_replace('', '', $match[1]);
                $icons = explode(' ', $icon);
                $iconList[] = current($icons);
            }

            preg_match_all("/\.(social_.*?):\w*?\s*?{/", $css_source, $matches1, PREG_SET_ORDER, 0);
            foreach ($matches1 as $match) {
                $icon = str_replace('', '', $match[1]);
                $icons = explode(' ', $icon);
                $iconList[] = current($icons);
            }

            $icons = new stdClass();
            $icons->icons = $iconList;
            $icon_data = json_encode($icons);
            $file = BANCA_CORE_DIR_PATH . '/assets/fonts/elegant.json';
            global $wp_filesystem;
            require_once(ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
            if ($wp_filesystem->exists($file)) {
                $content = $wp_filesystem->put_contents($file, $icon_data);
            }
        }


        /**
         * Include Files
         *
         * Load core files required to run the plugin.
         *
         * @since 1.7.0
         *
         * @access public
         */
        public function core_includes()
        {
            $opt = get_option('banca_opt');

            // Extra functions
            require_once __DIR__ . '/inc/extra.php';

            require_once __DIR__ . '/inc/el_advance_section.php';

            //Custom post types
            require_once __DIR__ . '/post-type/portfolio.pt.php';

            require_once __DIR__ . '/post-type/job.pt.php';

            require_once __DIR__ . '/post-type/footer.pt.php';

            require_once __DIR__ . '/post-type/none.pt.php';

            /**
             * Register widget area.
             *
             * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
             */
            require_once __DIR__ . '/wp-widgets/widgets.php';

            // Class helper functions
            require_once __DIR__ . '/inc/classes/class-helper-plugin.php';

            /**
             * Saving automatically the ACF group fields json files
             */
            add_filter('acf/settings/save_json', function ($path) {

                // update path
                $path = BANCA_CORE_DIR_PATH . 'inc/acf-json';

                // return
                return $path;

            });


            /**
             * Loading the saved ACF fields
             */
            add_filter('acf/settings/load_json', function ($paths) {

                // append path
                $paths[] = BANCA_CORE_DIR_PATH . 'inc/acf-json';

                // return
                return $paths;
            });

        }

        /**
         * Init Hooks
         *
         * Hook into actions and filters.
         *
         * @since 1.7.0
         *
         * @access private
         */
        private function init_hooks()
        {
            add_action('init', [$this, 'i18n']);
            add_action('plugins_loaded', [$this, 'init']);
        }

        /**
         * Load Textdomain
         *
         * Load plugin localization files.
         *
         * @since 1.7.0
         *
         * @access public
         */
        public function i18n()
        {
            load_plugin_textdomain('banca-core', false, plugin_basename(dirname(__FILE__)) . '/languages');
        }

        /**
         * Init Banca Core
         *
         * Load the plugin after Elementor (and other plugins) are loaded.
         *
         * @since 1.0.0
         * @since 1.7.0 The logic moved from a standalone function to this class method.
         *
         * @access public
         */
        public function init()
        {

            if (!did_action('elementor/loaded')) {
                add_action('admin_notices', [$this, 'admin_notice_missing_main_plugin']);
                return;
            }

            // Check for required Elementor version
            if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
                add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
                return;
            }

            // Check for required PHP version
            if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
                add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
                return;
            }

            // Add new Elementor Categories
            add_action('elementor/init', [$this, 'add_elementor_category']);

            // Register Widget Scripts
            add_action('elementor/frontend/after_register_scripts', [$this, 'register_widget_scripts']);
            add_action('elementor/editor/before_enqueue_scripts', [$this, 'register_widget_scripts']);

            // Enqueue Widgets Script
            add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueue_elementor_scripts'], 5);
            add_action('elementor/frontend/after_enqueue_scripts', [$this, 'enqueue_elementor_scripts'], 5);

            // Register Widget Scripts
            add_action('elementor/editor/before_enqueue_scripts', [$this, 'enqueue_elementor_editor_styles']);
            add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_widget_styles']);

            // Register New Widgets
            add_action('elementor/widgets/widgets_registered', [$this, 'on_widgets_registered']);

        }

        /**
         * Admin notice
         *
         * Warning when the site doesn't have Elementor installed or activated.
         *
         * @since 1.1.0
         * @since 1.7.0 Moved from a standalone function to a class method.
         *
         * @access public
         */
        public function admin_notice_missing_main_plugin()
        {
            $message = sprintf(
            /* translators: 1: Banca Core 2: Elementor */
                esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'banca-core'),
                '<strong>' . esc_html__('Banca core', 'banca-core') . '</strong>',
                '<strong>' . esc_html__('Elementor', 'banca-core') . '</strong>'
            );
            printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
        }

        /**
         * Admin notice
         *
         * Warning when the site doesn't have a minimum required PHP version.
         *
         * @since 1.7.0
         *
         * @access public
         */
        public function admin_notice_minimum_php_version()
        {
            $message = sprintf(
            /* translators: 1: Banca Core 2: PHP 3: Required PHP version */
                esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'banca-core'),
                '<strong>' . esc_html__('Banca Core', 'banca-core') . '</strong>',
                '<strong>' . esc_html__('PHP', 'banca-core') . '</strong>',
                self::MINIMUM_PHP_VERSION
            );
            printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
        }

        /**
         * Add new Elementor Categories
         *
         * Register new widget categories for Banca Core widgets.
         *
         * @since 1.0.0
         * @since 1.7.1 The method moved to this class.
         *
         * @access public
         */
        public function add_elementor_category()
        {
            Plugin::instance()->elements_manager->add_category('banca-elements', [
                'title' => __('Banca Elements', 'banca-core'),
            ], 1);
        }


        /**
         * Register Widget Scripts
         *
         * Register custom scripts required to run Banca Core.
         *
         * @since 1.6.0
         * @since 1.7.1 The method moved to this class.
         *
         * @access public
         */
        public function register_widget_scripts()
        {
            wp_register_script('counterup', BANCA_CORE_DIR_VEND . 'counter/jquery.counterup.min.js', 'jquery', '1.0', true);
            wp_register_script('waypoints', BANCA_CORE_DIR_VEND . 'counter/jquery.waypoints.min.js', 'jquery', '1.0', true);
            wp_register_script('slick', BANCA_CORE_DIR_VEND . 'slick/js/slick.min.js', 'jquery', '1.0.0', true);
            wp_register_script('parallax-scroll', BANCA_CORE_DIR_VEND . 'parallax/jquery.parallax-scroll.js', 'jquery', BANCA_CORE_VERSION, true);
            wp_register_script('parallax', BANCA_CORE_DIR_VEND . 'parallax/parallax.js', 'jquery', BANCA_CORE_VERSION, true);
            wp_register_script('fancybox', BANCA_CORE_DIR_VEND . 'fancybox/jquery.fancybox.min.js', 'jquery', '3.5.7', true);
            wp_register_script('nice-select', BANCA_CORE_DIR_VEND . 'nice-select/jquery.nice-select.min.js', 'jquery', '1.0', true);
            wp_register_script('smoothsroll', BANCA_CORE_DIR_VEND . 'smoothsroll/jquery.smoothscroll.min.js', 'jquery', '1.5.2', true);
            wp_register_script('editable-select', BANCA_CORE_DIR_VEND . 'editable-select/jquery-editable-select.js', 'jquery', BANCA_CORE_VERSION, true);
            wp_register_script('nouislider', BANCA_CORE_DIR_VEND . 'nouislider/nouislider.min.js', 'jquery', BANCA_CORE_VERSION, true);
            wp_register_script('wNumb', BANCA_CORE_DIR_VEND . 'wNumb/wNumb.js', 'jquery', BANCA_CORE_VERSION, true);
            wp_register_script('flatpickr', BANCA_CORE_DIR_VEND . 'flatpickr/flatpickr.min.js', 'jquery', '4.6.9', true);
        }

        /**
         * Register Widget Styles
         *
         * Register custom styles required to run Banca Core.
         *
         * @since 1.7.0
         * @since 1.7.1 The method moved to this class.
         *
         * @access public
         */

        public function enqueue_widget_styles()
        {
            wp_register_style('flatpickr', BANCA_CORE_DIR_VEND . 'flatpickr/flatpickr.min.css');
            wp_register_style('slick', BANCA_CORE_DIR_VEND . 'slick/css/slick.css');
            wp_register_style('slick-theme', BANCA_CORE_DIR_VEND . 'slick/css/slick-theme.css');
            wp_register_style('fancybox', BANCA_CORE_DIR_VEND . 'fancybox/jquery.fancybox.min.css');
            wp_register_style('editable-select', BANCA_CORE_DIR_VEND . 'editable-select/jquery-editable-select.css');
            wp_register_style('nouislider', BANCA_CORE_DIR_VEND . 'nouislider/nouislider.min.css');
            wp_register_style('nice-select', BANCA_CORE_DIR_VEND . 'nice-select/nice-select.css');
            wp_register_style('banca-button', BANCA_CORE_DIR_CSS . 'button.css');
            wp_enqueue_style('banca-elementor-override', BANCA_CORE_DIR_CSS . 'elementor-override.css');
            wp_enqueue_style('banca-custom', BANCA_CORE_DIR_CSS . 'custom.css');
        }

        /**
         * Enqueue stylesheets in the Elementor editor
         */
        public function enqueue_elementor_editor_styles()
        {
            wp_enqueue_style('banca-elementor-editor', plugins_url('assets/css/elementor-editor.css', __FILE__));
        }


        /**
         * Enqueue and dequeue scripts and styles
         */
        public function enqueue_elementor_scripts()
        {
            wp_enqueue_script('banca-elementor', BANCA_CORE_DIR_JS . 'banca-elementor.js', ['jquery', 'elementor-frontend'], BANCA_CORE_VERSION, true);
        }

        /**
         * Register New Widgets
         *
         * Include Banca Core widgets files and register them in Elementor.
         *
         * @since 1.0.0
         * @since 1.7.1 The method moved to this class.
         *
         * @access public
         */
        public function on_widgets_registered()
        {
            $this->include_widgets();
            $this->register_widgets();
        }

        /**
         * Include Widgets Files
         *
         * Load Banca Core widgets files.
         *
         * @since 1.0.0
         * @since 1.7.1 The method moved to this class.
         *
         * @access private
         */
        private function include_widgets()
        {
            require_once __DIR__ . '/vendor/autoload.php';
        }

        /**
         * Register Widgets
         *
         * Register Banca Core widgets.
         *
         * @since 1.0.0
         * @since 1.7.1 The method moved to this class.
         *
         * @access private
         */
        private function register_widgets()
        {

            // Site Elements
            $widgets = array(
                'Hero', 'Testimonials', 'Counter', 'Blog', 'Cards', 'Icon_list', 'Heading', 'Accordion', 'Image', 'Button', 'Steps', 'Parallax_bg',
                'Call_to_action', 'Mailchimp', 'Tabs', 'Team', 'Search_form', 'Jobs', 'Available_Job_Posts', 'Loan_calculator', 'Loan_info','Video', 'Pricing_table_switcher' ,
            );

            foreach ($widgets as $widget) {
                $classname = "\\BancaCore\\Widgets\\$widget";
                Plugin::instance()->widgets_manager->register(new $classname());
            }
        }
    }
}

// Make sure the same function is not loaded twice in free/premium versions.

if (!function_exists('banca_core_load')) {
    /**
     * Load Banca Core
     *
     * Main instance of Banca_Core.
     *
     * @since 1.0.0
     * @since 1.7.0 The logic moved from this function to a class method.
     */
    function banca_core_load()
    {
        return Banca_core::instance();
    }

    // Run Banca Core
    banca_core_load();
}